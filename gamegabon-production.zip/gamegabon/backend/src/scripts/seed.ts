import 'dotenv/config';
import mongoose from 'mongoose';
import { connectDB } from '../config/database';
import { User } from '../models/User';
import { Game, Pack, Promo } from '../models/index';
import { logger } from '../utils/logger';

const GAMES_SEED = [
  {
    name: 'Roblox', slug: 'roblox', currency: 'Robux', icon: '🎮', color: '#FF5252',
    active: true, featured: true, sortOrder: 1,
    packs: [
      { label: '400 Robux',  amount: 400,  bonusAmount: 0,   priceXAF: 2500,  priceUSD: 4.99,  priceEUR: 4.59,  popular: false, sortOrder: 1 },
      { label: '800 Robux',  amount: 800,  bonusAmount: 0,   priceXAF: 4900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: false, sortOrder: 2 },
      { label: '1700 Robux', amount: 1700, bonusAmount: 100, priceXAF: 9900,  priceUSD: 19.99, priceEUR: 18.39, popular: true,  sortOrder: 3 },
      { label: '4500 Robux', amount: 4500, bonusAmount: 500, priceXAF: 24900, priceUSD: 49.99, priceEUR: 45.99, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'Fortnite', slug: 'fortnite', currency: 'V-Bucks', icon: '⚡', color: '#00D4FF',
    active: true, featured: true, sortOrder: 2,
    packs: [
      { label: '1000 V-Bucks',  amount: 1000,  bonusAmount: 0,    priceXAF: 4900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: false, sortOrder: 1 },
      { label: '2800 V-Bucks',  amount: 2800,  bonusAmount: 300,  priceXAF: 9900,  priceUSD: 19.99, priceEUR: 18.39, popular: true,  sortOrder: 2 },
      { label: '5000 V-Bucks',  amount: 5000,  bonusAmount: 1000, priceXAF: 19900, priceUSD: 39.99, priceEUR: 36.79, popular: false, sortOrder: 3 },
      { label: '13500 V-Bucks', amount: 13500, bonusAmount: 3500, priceXAF: 49900, priceUSD: 99.99, priceEUR: 91.99, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'Call of Duty', slug: 'call-of-duty', currency: 'CP', icon: '💀', color: '#FF6B00',
    active: true, featured: false, sortOrder: 3,
    packs: [
      { label: '200 CP',  amount: 200,  bonusAmount: 0,   priceXAF: 1200,  priceUSD: 1.99,  priceEUR: 1.79,  popular: false, sortOrder: 1 },
      { label: '500 CP',  amount: 500,  bonusAmount: 0,   priceXAF: 2900,  priceUSD: 4.99,  priceEUR: 4.59,  popular: false, sortOrder: 2 },
      { label: '1000 CP', amount: 1000, bonusAmount: 100, priceXAF: 5900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: true,  sortOrder: 3 },
      { label: '2000 CP', amount: 2000, bonusAmount: 400, priceXAF: 11900, priceUSD: 19.99, priceEUR: 18.39, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'Free Fire', slug: 'free-fire', currency: 'Diamants', icon: '💎', color: '#FF4500',
    active: true, featured: true, sortOrder: 4,
    packs: [
      { label: '100 Diamants',  amount: 100,  bonusAmount: 0,  priceXAF: 900,  priceUSD: 1.49, priceEUR: 1.39, popular: false, sortOrder: 1 },
      { label: '310 Diamants',  amount: 310,  bonusAmount: 10, priceXAF: 2500, priceUSD: 4.99, priceEUR: 4.59, popular: false, sortOrder: 2 },
      { label: '520 Diamants',  amount: 520,  bonusAmount: 20, priceXAF: 4900, priceUSD: 9.99, priceEUR: 9.19, popular: true,  sortOrder: 3 },
      { label: '1060 Diamants', amount: 1060, bonusAmount: 60, priceXAF: 9900, priceUSD: 19.99,priceEUR:18.39, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'PUBG Mobile', slug: 'pubg-mobile', currency: 'UC', icon: '🎯', color: '#F5A623',
    active: true, featured: false, sortOrder: 5,
    packs: [
      { label: '60 UC',   amount: 60,   bonusAmount: 0,   priceXAF: 600,   priceUSD: 0.99,  priceEUR: 0.89,  popular: false, sortOrder: 1 },
      { label: '325 UC',  amount: 325,  bonusAmount: 25,  priceXAF: 2900,  priceUSD: 4.99,  priceEUR: 4.59,  popular: true,  sortOrder: 2 },
      { label: '660 UC',  amount: 660,  bonusAmount: 60,  priceXAF: 5900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: false, sortOrder: 3 },
      { label: '1800 UC', amount: 1800, bonusAmount: 300, priceXAF: 14900, priceUSD: 24.99, priceEUR: 22.99, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'EA Sports FC 25', slug: 'ea-sports-fc-25', currency: 'FC Points', icon: '⚽', color: '#00E676',
    active: true, featured: false, sortOrder: 6,
    packs: [
      { label: '500 FCP',  amount: 500,  bonusAmount: 0,   priceXAF: 2900,  priceUSD: 4.99,  priceEUR: 4.59,  popular: false, sortOrder: 1 },
      { label: '1050 FCP', amount: 1050, bonusAmount: 50,  priceXAF: 5900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: true,  sortOrder: 2 },
      { label: '2200 FCP', amount: 2200, bonusAmount: 200, priceXAF: 11900, priceUSD: 19.99, priceEUR: 18.39, popular: false, sortOrder: 3 },
      { label: '5900 FCP', amount: 5900, bonusAmount: 900, priceXAF: 29900, priceUSD: 49.99, priceEUR: 45.99, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'League of Legends', slug: 'league-of-legends', currency: 'RP', icon: '🏆', color: '#C89B3C',
    active: true, featured: false, sortOrder: 7,
    packs: [
      { label: '1380 RP',  amount: 1380,  bonusAmount: 0,    priceXAF: 4900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: false, sortOrder: 1 },
      { label: '2800 RP',  amount: 2800,  bonusAmount: 200,  priceXAF: 9900,  priceUSD: 19.99, priceEUR: 18.39, popular: true,  sortOrder: 2 },
      { label: '5000 RP',  amount: 5000,  bonusAmount: 500,  priceXAF: 14900, priceUSD: 29.99, priceEUR: 27.59, popular: false, sortOrder: 3 },
      { label: '11120 RP', amount: 11120, bonusAmount: 1120, priceXAF: 29900, priceUSD: 59.99, priceEUR: 54.99, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'Valorant', slug: 'valorant', currency: 'VP', icon: '🔫', color: '#FF4655',
    active: true, featured: false, sortOrder: 8,
    packs: [
      { label: '475 VP',  amount: 475,  bonusAmount: 0,   priceXAF: 2900,  priceUSD: 4.99,  priceEUR: 4.59,  popular: false, sortOrder: 1 },
      { label: '1000 VP', amount: 1000, bonusAmount: 0,   priceXAF: 5900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: true,  sortOrder: 2 },
      { label: '2050 VP', amount: 2050, bonusAmount: 0,   priceXAF: 11900, priceUSD: 19.99, priceEUR: 18.39, popular: false, sortOrder: 3 },
      { label: '5350 VP', amount: 5350, bonusAmount: 350, priceXAF: 29900, priceUSD: 49.99, priceEUR: 45.99, popular: false, sortOrder: 4 },
    ],
  },
  {
    name: 'Genshin Impact', slug: 'genshin-impact', currency: 'Cristaux', icon: '✨', color: '#90CAF9',
    active: true, featured: false, sortOrder: 9,
    packs: [
      { label: '60 Cristaux',   amount: 60,   bonusAmount: 0,   priceXAF: 900,   priceUSD: 0.99,  priceEUR: 0.89,  popular: false, sortOrder: 1 },
      { label: '330 Cristaux',  amount: 330,  bonusAmount: 30,  priceXAF: 4900,  priceUSD: 9.99,  priceEUR: 9.19,  popular: true,  sortOrder: 2 },
      { label: '1090 Cristaux', amount: 1090, bonusAmount: 90,  priceXAF: 14900, priceUSD: 29.99, priceEUR: 27.59, popular: false, sortOrder: 3 },
      { label: '3280 Cristaux', amount: 3280, bonusAmount: 280, priceXAF: 44900, priceUSD: 89.99, priceEUR: 82.99, popular: false, sortOrder: 4 },
    ],
  },
];

async function seed(): Promise<void> {
  await connectDB();
  logger.info('🌱 Starting database seed...');

  // ── Admin user ─────────────────────────────────────────────
  const adminEmail = process.env.ADMIN_EMAIL || 'admin@gamegabon.com';
  const existing   = await User.findOne({ email: adminEmail });
  if (!existing) {
    await User.create({
      name: 'Administrateur GameTopUp',
      email: adminEmail,
      phone: '+241 011 000 000',
      password: process.env.ADMIN_PASSWORD || 'Admin@Gabon2026!',
      role: 'admin',
      status: 'active',
      emailVerified: true,
    });
    logger.info(`✅ Admin created: ${adminEmail}`);
  } else {
    logger.info(`ℹ️  Admin already exists: ${adminEmail}`);
  }

  // ── Games & packs ──────────────────────────────────────────
  let gamesCreated = 0;
  let packsCreated = 0;

  for (const gData of GAMES_SEED) {
    const { packs, ...gameData } = gData;
    let game = await Game.findOne({ slug: gameData.slug });
    if (!game) {
      game = await Game.create(gameData);
      gamesCreated++;
      logger.info(`  ✅ Game: ${game.name}`);
    }

    for (const pData of packs) {
      const exists = await Pack.findOne({ gameId: game._id, label: pData.label });
      if (!exists) {
        await Pack.create({ ...pData, gameId: game._id, active: true });
        packsCreated++;
      }
    }
  }

  logger.info(`✅ Games seeded: ${gamesCreated} new, ${packsCreated} packs`);

  // ── Demo promos ────────────────────────────────────────────
  const admin = await User.findOne({ role: 'admin' });
  if (admin) {
    const promoData = [
      { code: 'GABON10', discountType: 'percent' as const, discountValue: 10, minAmount: 0, maxUses: 500, applicableGames: 'all', active: true },
      { code: 'BIENVENUE', discountType: 'fixed' as const, discountValue: 500, minAmount: 2000, maxUses: 200, applicableGames: 'all', active: true },
    ];
    for (const p of promoData) {
      const exists = await Promo.findOne({ code: p.code });
      if (!exists) {
        await Promo.create({ ...p, uses: 0, createdBy: admin._id, expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) });
        logger.info(`  ✅ Promo: ${p.code}`);
      }
    }
  }

  logger.info('🎉 Seed completed successfully!');
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch((err) => {
  logger.error('Seed failed:', err);
  process.exit(1);
});
