import { Response } from 'express';
import { AuthRequest } from '../types';
import { paymentService } from '../services/payment.service';
import { AppError } from '../utils/AppError';

export class PaymentController {
  // Initiate Mobile Money payment for an existing order
  initiatePayment = async (req: AuthRequest, res: Response): Promise<void> => {
    const { orderId, provider, phoneNumber } = req.body;

    if (!['pvit_airtel', 'pvit_moov'].includes(provider)) {
      throw new AppError('Invalid provider. Use pvit_airtel or pvit_moov', 400);
    }
    if (!phoneNumber) throw new AppError('Phone number required for Mobile Money', 400);

    const payment = await paymentService.initiateMobileMoneyPayment({
      orderId,
      userId: req.user!.userId,
      provider,
      phoneNumber,
    });

    res.json({
      success: true,
      message: 'Payment initiated. Please confirm on your phone.',
      data: { payment },
    });
  };

  // Check status (client polling)
  checkStatus = async (req: AuthRequest, res: Response): Promise<void> => {
    const payment = await paymentService.checkStatus(req.params.id, req.user!.userId);
    res.json({ success: true, data: { payment } });
  };

  // Get user payment history
  getMyPayments = async (req: AuthRequest, res: Response): Promise<void> => {
    const page  = parseInt(req.query.page  as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const result = await paymentService.getUserPayments(req.user!.userId, page, limit);
    res.json({
      success: true,
      data: result.payments,
      pagination: { page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages },
    });
  };

  // ── ADMIN ──────────────────────────────────────────────────
  adminGetPayments = async (req: AuthRequest, res: Response): Promise<void> => {
    const result = await paymentService.getAllPayments({
      page:     parseInt(req.query.page     as string) || 1,
      limit:    parseInt(req.query.limit    as string) || 20,
      status:   req.query.status   as string,
      provider: req.query.provider as string,
    });
    res.json({
      success: true,
      data: result.payments,
      pagination: { page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages },
      stats: result.stats,
    });
  };

  adminRefundPayment = async (req: AuthRequest, res: Response): Promise<void> => {
    await paymentService.refundPayment(req.params.id, req.user!.userId);
    res.json({ success: true, message: 'Payment refunded successfully' });
  };
}

export const paymentController = new PaymentController();
