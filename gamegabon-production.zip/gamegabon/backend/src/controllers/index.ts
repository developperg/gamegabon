import { Response } from 'express';
import { AuthRequest } from '../types';
import { orderService } from '../services/order.service';
import { Game, Pack, Promo, User } from '../models/index';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

// ══════════════════════════════════════════════════════════════
// ORDER CONTROLLER
// ══════════════════════════════════════════════════════════════
export class OrderController {
  createOrder = async (req: AuthRequest, res: Response): Promise<void> => {
    const { gameId, packId, playerId, paymentMethod, phoneNumber, promoCode, currency } = req.body;

    const { order, payment } = await orderService.createOrder({
      userId: req.user!.userId,
      gameId, packId, playerId, paymentMethod, phoneNumber, promoCode, currency,
    });

    res.status(201).json({
      success: true,
      message: 'Order created. Please complete payment.',
      data: { order, payment },
    });
  };

  getMyOrders = async (req: AuthRequest, res: Response): Promise<void> => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const status = req.query.status as string;

    const result = await orderService.getUserOrders(req.user!.userId, page, limit, status);
    res.json({
      success: true,
      data: result.orders,
      pagination: {
        page: result.page,
        limit: result.limit,
        total: result.total,
        totalPages: result.totalPages,
      },
    });
  };

  getOrderById = async (req: AuthRequest, res: Response): Promise<void> => {
    const { id } = req.params;
    const order = await orderService.getUserOrders(req.user!.userId, 1, 1);
    res.json({ success: true, data: order });
  };

  // ── ADMIN ──
  adminGetOrders = async (req: AuthRequest, res: Response): Promise<void> => {
    const result = await orderService.getAllOrders({
      page: parseInt(req.query.page as string) || 1,
      limit: parseInt(req.query.limit as string) || 20,
      status: req.query.status as string,
      search: req.query.search as string,
      gameId: req.query.gameId as string,
      startDate: req.query.startDate as string,
      endDate: req.query.endDate as string,
    });
    res.json({
      success: true,
      data: result.orders,
      pagination: { page: result.page, limit: result.limit, total: result.total, totalPages: result.totalPages },
    });
  };

  adminUpdateOrderStatus = async (req: AuthRequest, res: Response): Promise<void> => {
    const { id } = req.params;
    const { status, notes } = req.body;

    if (status === 'delivered') {
      const order = await orderService.deliverOrder(id);
      res.json({ success: true, message: 'Order delivered', data: { order } });
      return;
    }

    const { Order } = await import('../models/index');
    const order = await Order.findByIdAndUpdate(id, { status, notes }, { new: true });
    if (!order) throw new AppError('Order not found', 404);

    logger.info(`Order ${order.orderNumber} status updated to ${status} by admin ${req.user!.userId}`);
    res.json({ success: true, message: 'Order updated', data: { order } });
  };

  adminGetAnalytics = async (req: AuthRequest, res: Response): Promise<void> => {
    const period = (req.query.period as '7d' | '30d' | '90d') || '30d';
    const analytics = await orderService.getAnalytics(period);
    res.json({ success: true, data: analytics });
  };
}

// ══════════════════════════════════════════════════════════════
// GAME CONTROLLER
// ══════════════════════════════════════════════════════════════
export class GameController {
  // Public
  getGames = async (req: AuthRequest, res: Response): Promise<void> => {
    const games = await Game.find({ active: true }).sort({ sortOrder: 1, name: 1 }).lean();
    res.json({ success: true, data: games });
  };

  getGameWithPacks = async (req: AuthRequest, res: Response): Promise<void> => {
    const { slug } = req.params;
    const game = await Game.findOne({ slug, active: true }).lean();
    if (!game) throw new AppError('Game not found', 404);
    const packs = await Pack.find({ gameId: game._id, active: true }).sort({ sortOrder: 1, priceXAF: 1 }).lean();
    res.json({ success: true, data: { game, packs } });
  };

  // Admin
  adminGetAllGames = async (_req: AuthRequest, res: Response): Promise<void> => {
    const games = await Game.find().sort({ sortOrder: 1 }).lean();
    const gamesWithPackCount = await Promise.all(
      games.map(async (g) => ({
        ...g,
        packCount: await Pack.countDocuments({ gameId: g._id }),
      }))
    );
    res.json({ success: true, data: gamesWithPackCount });
  };

  adminCreateGame = async (req: AuthRequest, res: Response): Promise<void> => {
    const { name, currency, icon, color, coverImage, description, featured, sortOrder } = req.body;
    const slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    const game = await Game.create({ name, slug, currency, icon, color, coverImage, description, featured, sortOrder });
    res.status(201).json({ success: true, message: 'Game created', data: game });
  };

  adminUpdateGame = async (req: AuthRequest, res: Response): Promise<void> => {
    const game = await Game.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!game) throw new AppError('Game not found', 404);
    res.json({ success: true, message: 'Game updated', data: game });
  };

  adminDeleteGame = async (req: AuthRequest, res: Response): Promise<void> => {
    const game = await Game.findByIdAndDelete(req.params.id);
    if (!game) throw new AppError('Game not found', 404);
    await Pack.deleteMany({ gameId: req.params.id });
    res.json({ success: true, message: 'Game and its packs deleted' });
  };

  // Pack management
  adminCreatePack = async (req: AuthRequest, res: Response): Promise<void> => {
    const { gameId } = req.params;
    const game = await Game.findById(gameId);
    if (!game) throw new AppError('Game not found', 404);
    const pack = await Pack.create({ ...req.body, gameId });
    res.status(201).json({ success: true, message: 'Pack created', data: pack });
  };

  adminUpdatePack = async (req: AuthRequest, res: Response): Promise<void> => {
    const pack = await Pack.findByIdAndUpdate(req.params.packId, req.body, { new: true });
    if (!pack) throw new AppError('Pack not found', 404);
    res.json({ success: true, message: 'Pack updated', data: pack });
  };

  adminDeletePack = async (req: AuthRequest, res: Response): Promise<void> => {
    await Pack.findByIdAndDelete(req.params.packId);
    res.json({ success: true, message: 'Pack deleted' });
  };
}

// ══════════════════════════════════════════════════════════════
// PROMO CONTROLLER
// ══════════════════════════════════════════════════════════════
export class PromoController {
  validatePromo = async (req: AuthRequest, res: Response): Promise<void> => {
    const { code, gameId, amount } = req.body;
    const promo = await Promo.findOne({
      code: code.toUpperCase(),
      active: true,
      $expr: { $lt: ['$uses', '$maxUses'] },
      $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }],
    });
    if (!promo) throw new AppError('Invalid or expired promo code', 400);

    const isApplicable =
      promo.applicableGames === 'all' ||
      (Array.isArray(promo.applicableGames) &&
        promo.applicableGames.some((id) => id.toString() === gameId));
    if (!isApplicable) throw new AppError('Code not applicable to this game', 400);
    if (promo.minAmount > 0 && amount < promo.minAmount) {
      throw new AppError(`Minimum amount: ${promo.minAmount} XAF`, 400);
    }

    const discount =
      promo.discountType === 'percent'
        ? Math.min(Math.floor(amount * (promo.discountValue / 100)), promo.maxDiscount || Infinity)
        : Math.min(promo.discountValue, amount);

    res.json({
      success: true,
      data: {
        code: promo.code,
        discountType: promo.discountType,
        discountValue: promo.discountValue,
        discountAmount: discount,
        finalAmount: amount - discount,
      },
    });
  };

  adminGetPromos = async (_req: AuthRequest, res: Response): Promise<void> => {
    const promos = await Promo.find().populate('createdBy', 'name email').sort({ createdAt: -1 });
    res.json({ success: true, data: promos });
  };

  adminCreatePromo = async (req: AuthRequest, res: Response): Promise<void> => {
    const promo = await Promo.create({ ...req.body, createdBy: req.user!.userId, code: req.body.code.toUpperCase() });
    res.status(201).json({ success: true, message: 'Promo created', data: promo });
  };

  adminUpdatePromo = async (req: AuthRequest, res: Response): Promise<void> => {
    const promo = await Promo.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!promo) throw new AppError('Promo not found', 404);
    res.json({ success: true, message: 'Promo updated', data: promo });
  };

  adminDeletePromo = async (req: AuthRequest, res: Response): Promise<void> => {
    await Promo.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Promo deleted' });
  };
}

// ══════════════════════════════════════════════════════════════
// ADMIN USER CONTROLLER
// ══════════════════════════════════════════════════════════════
export class AdminUserController {
  getUsers = async (req: AuthRequest, res: Response): Promise<void> => {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const search = req.query.search as string;
    const role = req.query.role as string;
    const status = req.query.status as string;

    const query: Record<string, unknown> = {};
    if (role) query.role = role;
    if (status) query.status = status;
    if (search) query.$or = [{ name: { $regex: search, $options: 'i' } }, { email: { $regex: search, $options: 'i' } }];

    const [users, total] = await Promise.all([
      User.find(query).sort({ createdAt: -1 }).skip((page - 1) * limit).limit(limit).lean(),
      User.countDocuments(query),
    ]);

    res.json({
      success: true,
      data: users,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  };

  updateUser = async (req: AuthRequest, res: Response): Promise<void> => {
    const { role, status, name, phone } = req.body;
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { $set: { role, status, name, phone } },
      { new: true }
    );
    if (!user) throw new AppError('User not found', 404);
    logger.info(`Admin ${req.user!.userId} updated user ${req.params.id}`);
    res.json({ success: true, message: 'User updated', data: user });
  };

  deleteUser = async (req: AuthRequest, res: Response): Promise<void> => {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) throw new AppError('User not found', 404);
    res.json({ success: true, message: 'User deleted' });
  };
}

export const orderController = new OrderController();
export const gameController = new GameController();
export const promoController = new PromoController();
export const adminUserController = new AdminUserController();
