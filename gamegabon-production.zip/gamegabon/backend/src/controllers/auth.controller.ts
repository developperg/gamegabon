import { Request, Response } from 'express';
import { authService } from '../services/auth.service';
import { AuthRequest } from '../types';

export class AuthController {
  register = async (req: Request, res: Response): Promise<void> => {
    const { name, email, phone, password, referralCode } = req.body;
    const { user, accessToken, refreshToken } = await authService.register({
      name, email, phone, password, referralCode,
    });

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.status(201).json({
      success: true,
      message: 'Account created successfully',
      data: { user, accessToken },
    });
  };

  login = async (req: Request, res: Response): Promise<void> => {
    const { email, password } = req.body;
    const { user, accessToken, refreshToken } = await authService.login(email, password, req.ip);

    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    res.json({
      success: true,
      message: 'Login successful',
      data: { user, accessToken },
    });
  };

  refreshToken = async (req: Request, res: Response): Promise<void> => {
    const token = req.cookies?.refreshToken || req.body.refreshToken;
    if (!token) {
      res.status(401).json({ success: false, message: 'No refresh token provided' });
      return;
    }
    const tokens = await authService.refreshToken(token);
    res.cookie('refreshToken', tokens.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });
    res.json({ success: true, data: { accessToken: tokens.accessToken } });
  };

  logout = async (req: AuthRequest, res: Response): Promise<void> => {
    if (req.user) await authService.logout(req.user.userId);
    res.clearCookie('refreshToken');
    res.json({ success: true, message: 'Logged out successfully' });
  };

  getProfile = async (req: AuthRequest, res: Response): Promise<void> => {
    const user = await authService.getProfile(req.user!.userId);
    res.json({ success: true, data: { user } });
  };

  updateProfile = async (req: AuthRequest, res: Response): Promise<void> => {
    const { name, phone } = req.body;
    const user = await authService.updateProfile(req.user!.userId, { name, phone });
    res.json({ success: true, message: 'Profile updated', data: { user } });
  };

  forgotPassword = async (req: Request, res: Response): Promise<void> => {
    const token = await authService.forgotPassword(req.body.email);
    // In production, send email with token
    res.json({
      success: true,
      message: 'Password reset instructions sent to your email',
      ...(process.env.NODE_ENV === 'development' && { token }),
    });
  };

  resetPassword = async (req: Request, res: Response): Promise<void> => {
    await authService.resetPassword(req.body.token, req.body.password);
    res.json({ success: true, message: 'Password reset successful' });
  };
}

export const authController = new AuthController();
