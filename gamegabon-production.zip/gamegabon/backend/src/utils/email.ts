import nodemailer from 'nodemailer';
import { logger } from './logger';

interface EmailOptions {
  to:      string;
  subject: string;
  html:    string;
}

const createTransporter = () =>
  nodemailer.createTransport({
    host:   process.env.SMTP_HOST   || 'smtp.gmail.com',
    port:   parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_PORT === '465',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

export const sendEmail = async (options: EmailOptions): Promise<void> => {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    logger.warn(`[EMAIL MOCK] To: ${options.to} | Subject: ${options.subject}`);
    return;
  }

  try {
    const transporter = createTransporter();
    await transporter.sendMail({
      from:    process.env.EMAIL_FROM || 'GameTopUp Gabon <noreply@gamegabon.com>',
      to:      options.to,
      subject: options.subject,
      html:    options.html,
    });
    logger.info(`Email sent to ${options.to}: ${options.subject}`);
  } catch (err) {
    logger.error(`Failed to send email to ${options.to}:`, err);
    // Don't throw — email failures shouldn't break business logic
  }
};

// ── Email templates ───────────────────────────────────────────
export const passwordResetEmail = (name: string, resetUrl: string): string => `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body{font-family:sans-serif;background:#07090f;color:#dde6f8;margin:0;padding:20px;}
  .container{max-width:480px;margin:0 auto;background:#0d1420;border-radius:16px;padding:32px;border:1px solid #1c2840;}
  .logo{font-size:24px;font-weight:900;color:#00e5ff;margin-bottom:24px;}
  .btn{display:inline-block;padding:12px 28px;background:#00e5ff;color:#060d10;font-weight:800;border-radius:10px;text-decoration:none;}
  .footer{margin-top:24px;font-size:12px;color:#526080;}
</style></head>
<body>
  <div class="container">
    <div class="logo">🎮 GameTopUp Gabon</div>
    <h2 style="margin-bottom:12px;">Réinitialisation du mot de passe</h2>
    <p style="color:#8896b0;margin-bottom:24px;">Bonjour ${name},<br/><br/>
      Vous avez demandé la réinitialisation de votre mot de passe. Cliquez sur le bouton ci-dessous.
      Ce lien expire dans <strong>10 minutes</strong>.</p>
    <a href="${resetUrl}" class="btn">Réinitialiser mon mot de passe</a>
    <div class="footer">Si vous n'avez pas fait cette demande, ignorez cet email.<br/>
      © ${new Date().getFullYear()} GameTopUp Gabon</div>
  </div>
</body>
</html>`;

export const orderDeliveredEmail = (name: string, orderNumber: string, gameName: string, packLabel: string): string => `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body{font-family:sans-serif;background:#07090f;color:#dde6f8;margin:0;padding:20px;}
  .container{max-width:480px;margin:0 auto;background:#0d1420;border-radius:16px;padding:32px;border:1px solid #1c2840;}
  .logo{font-size:24px;font-weight:900;color:#00e5ff;margin-bottom:24px;}
  .success{color:#00e676;font-size:18px;font-weight:700;}
  .info{background:#111827;border-radius:10px;padding:16px;margin:16px 0;}
  .footer{margin-top:24px;font-size:12px;color:#526080;}
</style></head>
<body>
  <div class="container">
    <div class="logo">🎮 GameTopUp Gabon</div>
    <div class="success">✅ Commande livrée !</div>
    <p style="color:#8896b0;margin:12px 0;">Bonjour ${name}, votre recharge a été livrée avec succès !</p>
    <div class="info">
      <div><strong>N° Commande :</strong> ${orderNumber}</div>
      <div><strong>Jeu :</strong> ${gameName}</div>
      <div><strong>Pack :</strong> ${packLabel}</div>
    </div>
    <p style="color:#8896b0;font-size:13px;">Merci pour votre confiance. N'hésitez pas à nous contacter si vous avez le moindre problème.</p>
    <div class="footer">© ${new Date().getFullYear()} GameTopUp Gabon — support@gamegabon.com</div>
  </div>
</body>
</html>`;
