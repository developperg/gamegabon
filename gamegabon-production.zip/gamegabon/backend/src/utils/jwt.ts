import jwt from 'jsonwebtoken';
import { AuthPayload } from '../types';

export const generateAccessToken = (payload: AuthPayload): string => {
  const secret = process.env.JWT_SECRET!;
  const expiresIn = process.env.JWT_EXPIRES_IN || '15m';
  return jwt.sign(payload, secret, { expiresIn } as jwt.SignOptions);
};

export const generateRefreshToken = (payload: AuthPayload): string => {
  const secret = process.env.JWT_REFRESH_SECRET!;
  const expiresIn = process.env.JWT_REFRESH_EXPIRES_IN || '7d';
  return jwt.sign(payload, secret, { expiresIn } as jwt.SignOptions);
};

export const verifyRefreshToken = (token: string): AuthPayload => {
  const secret = process.env.JWT_REFRESH_SECRET!;
  return jwt.verify(token, secret) as AuthPayload;
};

export const generateOrderNumber = (): string => {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `GTG-${timestamp}-${random}`;
};

export const calculateCashback = (amount: number, rate = 0.02): number => {
  return Math.floor(amount * rate);
};

export const calculateDiscount = (
  amount: number,
  type: 'percent' | 'fixed',
  value: number,
  maxDiscount?: number
): number => {
  let discount = type === 'percent' ? Math.floor(amount * (value / 100)) : value;
  if (maxDiscount && discount > maxDiscount) discount = maxDiscount;
  return Math.min(discount, amount);
};
