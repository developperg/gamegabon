import { Request } from 'express';
import { Document, Types } from 'mongoose';

// ── AUTH ─────────────────────────────────────────────────────
export interface AuthPayload {
  userId: string;
  role: 'admin' | 'reseller' | 'client';
  email: string;
}

export interface AuthRequest extends Request {
  user?: AuthPayload;
}

// ── USER ─────────────────────────────────────────────────────
export interface IUser extends Document {
  _id: Types.ObjectId;
  name: string;
  email: string;
  phone: string;
  password: string;
  role: 'admin' | 'reseller' | 'client';
  status: 'active' | 'suspended' | 'pending';
  emailVerified: boolean;
  referralCode: string;
  referredBy?: Types.ObjectId;
  cashback: number;
  totalSpent: number;
  totalOrders: number;
  refreshToken?: string;
  passwordResetToken?: string;
  passwordResetExpires?: Date;
  emailVerificationToken?: string;
  createdAt: Date;
  updatedAt: Date;
  comparePassword(candidatePassword: string): Promise<boolean>;
}

// ── GAME ─────────────────────────────────────────────────────
export interface IGame extends Document {
  _id: Types.ObjectId;
  name: string;
  slug: string;
  currency: string;
  icon: string;
  color: string;
  coverImage?: string;
  description?: string;
  active: boolean;
  featured: boolean;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}

// ── PACK ─────────────────────────────────────────────────────
export interface IPack extends Document {
  _id: Types.ObjectId;
  gameId: Types.ObjectId;
  label: string;
  amount: number;
  bonusAmount: number;
  priceXAF: number;
  priceUSD: number;
  priceEUR: number;
  active: boolean;
  popular: boolean;
  sortOrder: number;
  createdAt: Date;
  updatedAt: Date;
}

// ── PROMO ─────────────────────────────────────────────────────
export interface IPromo extends Document {
  _id: Types.ObjectId;
  code: string;
  discountType: 'percent' | 'fixed';
  discountValue: number;
  minAmount: number;
  maxDiscount?: number;
  applicableGames: Types.ObjectId[] | 'all';
  active: boolean;
  uses: number;
  maxUses: number;
  expiresAt?: Date;
  createdBy: Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

// ── ORDER ─────────────────────────────────────────────────────
export type OrderStatus = 'pending' | 'processing' | 'delivered' | 'failed' | 'refunded';

export interface IOrder extends Document {
  _id: Types.ObjectId;
  orderNumber: string;
  userId: Types.ObjectId;
  gameId: Types.ObjectId;
  packId: Types.ObjectId;
  playerId: string;
  promoId?: Types.ObjectId;
  originalAmount: number;
  discountAmount: number;
  finalAmount: number;
  currency: string;
  status: OrderStatus;
  paymentMethod: string;
  paymentId?: Types.ObjectId;
  cashbackEarned: number;
  notes?: string;
  deliveredAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// ── PAYMENT ─────────────────────────────────────────────────
export type PaymentStatus = 'pending' | 'processing' | 'success' | 'failed' | 'refunded';
export type PaymentProvider = 'pvit_airtel' | 'pvit_moov' | 'card' | 'paypal' | 'usdt';

export interface IPayment extends Document {
  _id: Types.ObjectId;
  orderId: Types.ObjectId;
  userId: Types.ObjectId;
  provider: PaymentProvider;
  amount: number;
  currency: string;
  status: PaymentStatus;
  transactionId?: string;
  pvitTransactionId?: string;
  pvitReference?: string;
  phoneNumber?: string;
  callbackData?: Record<string, unknown>;
  failureReason?: string;
  processedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

// ── TRANSACTION ──────────────────────────────────────────────
export interface ITransaction extends Document {
  _id: Types.ObjectId;
  userId: Types.ObjectId;
  type: 'credit' | 'debit' | 'cashback' | 'refund';
  amount: number;
  currency: string;
  description: string;
  referenceId?: Types.ObjectId;
  referenceModel?: string;
  balanceBefore: number;
  balanceAfter: number;
  createdAt: Date;
}

// ── API RESPONSES ─────────────────────────────────────────────
export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  errors?: Record<string, string>;
  pagination?: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// ── PVIT ─────────────────────────────────────────────────────
export interface PvitPaymentRequest {
  amount: number;
  currency: string;
  phoneNumber: string;
  provider: 'airtel' | 'moov';
  orderId: string;
  description: string;
  callbackUrl: string;
  merchantRef: string;
}

export interface PvitPaymentResponse {
  success: boolean;
  transactionId: string;
  reference: string;
  status: string;
  message: string;
}

export interface PvitWebhookPayload {
  transactionId: string;
  merchantRef: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING';
  amount: number;
  currency: string;
  phoneNumber: string;
  timestamp: string;
  signature: string;
}
