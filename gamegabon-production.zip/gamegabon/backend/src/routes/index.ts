import 'express-async-errors';
import { Router, Request, Response } from 'express';
import { authenticate, adminOnly } from '../middleware/auth';
import { validate }               from '../middleware/validate';
import { authLimiter, paymentLimiter } from '../middleware/rateLimiter';

import { authController }        from '../controllers/auth.controller';
import {
  orderController,
  gameController,
  promoController,
  adminUserController,
} from '../controllers/index';
import { paymentController }     from '../controllers/payment.controller';

import {
  registerSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from '../validations/auth.validation';
import {
  createOrderSchema,
  updateOrderStatusSchema,
} from '../validations/order.validation';
import {
  createGameSchema,
  updateGameSchema,
  createPackSchema,
  createPromoSchema,
  updatePromoSchema,
  validatePromoSchema,
  adminUpdateUserSchema,
} from '../validations/game.validation';

import { handlePvitWebhook } from '../webhooks/pvit.webhook';

const router = Router();

// ── Health ────────────────────────────────────────────────────
router.get('/health', (_req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'GameTopUp Gabon API ✅',
    timestamp: new Date().toISOString(),
    env: process.env.NODE_ENV,
  });
});

// ── Webhooks ──────────────────────────────────────────────────
router.post('/webhooks/pvit', handlePvitWebhook);

// ── AUTH ──────────────────────────────────────────────────────
const auth = Router();
auth.post('/register',        authLimiter, validate(registerSchema),       authController.register);
auth.post('/login',           authLimiter, validate(loginSchema),           authController.login);
auth.post('/refresh',                                                        authController.refreshToken);
auth.post('/logout',          authenticate,                                  authController.logout);
auth.get ('/me',              authenticate,                                  authController.getProfile);
auth.patch('/me',             authenticate,                                  authController.updateProfile);
auth.post('/forgot-password', authLimiter, validate(forgotPasswordSchema),  authController.forgotPassword);
auth.post('/reset-password',              validate(resetPasswordSchema),    authController.resetPassword);
router.use('/auth', auth);

// ── GAMES (public) ────────────────────────────────────────────
const games = Router();
games.get('/',      gameController.getGames);
games.get('/:slug', gameController.getGameWithPacks);
router.use('/games', games);

// ── PROMOS (authenticated) ────────────────────────────────────
const promos = Router();
promos.post('/validate', authenticate, validate(validatePromoSchema), promoController.validatePromo);
router.use('/promos', promos);

// ── ORDERS (authenticated) ────────────────────────────────────
const orders = Router();
orders.post('/',     authenticate, validate(createOrderSchema), orderController.createOrder);
orders.get ('/',     authenticate,                               orderController.getMyOrders);
orders.get ('/:id',  authenticate,                               orderController.getOrderById);
router.use('/orders', orders);

// ── PAYMENTS (authenticated) ──────────────────────────────────
const payments = Router();
payments.post('/initiate',   authenticate, paymentLimiter, paymentController.initiatePayment);
payments.get ('/status/:id', authenticate,                  paymentController.checkStatus);
payments.get ('/',           authenticate,                  paymentController.getMyPayments);
router.use('/payments', payments);

// ── ADMIN (admin only) ────────────────────────────────────────
const admin = Router();
admin.use(authenticate, adminOnly);

admin.get   ('/analytics',                                                         orderController.adminGetAnalytics);
admin.get   ('/orders',                                                            orderController.adminGetOrders);
admin.patch ('/orders/:id/status',    validate(updateOrderStatusSchema),           orderController.adminUpdateOrderStatus);
admin.get   ('/games',                                                             gameController.adminGetAllGames);
admin.post  ('/games',                validate(createGameSchema),                  gameController.adminCreateGame);
admin.patch ('/games/:id',            validate(updateGameSchema),                  gameController.adminUpdateGame);
admin.delete('/games/:id',                                                         gameController.adminDeleteGame);
admin.post  ('/games/:gameId/packs',  validate(createPackSchema),                  gameController.adminCreatePack);
admin.patch ('/games/:gameId/packs/:packId',                                       gameController.adminUpdatePack);
admin.delete('/games/:gameId/packs/:packId',                                       gameController.adminDeletePack);
admin.get   ('/promos',                                                            promoController.adminGetPromos);
admin.post  ('/promos',               validate(createPromoSchema),                 promoController.adminCreatePromo);
admin.patch ('/promos/:id',           validate(updatePromoSchema),                 promoController.adminUpdatePromo);
admin.delete('/promos/:id',                                                        promoController.adminDeletePromo);
admin.get   ('/users',                                                             adminUserController.getUsers);
admin.patch ('/users/:id',            validate(adminUpdateUserSchema),             adminUserController.updateUser);
admin.delete('/users/:id',                                                         adminUserController.deleteUser);
admin.get   ('/payments',                                                          paymentController.adminGetPayments);
admin.post  ('/payments/:id/refund',                                               paymentController.adminRefundPayment);

router.use('/admin', admin);

export default router;
