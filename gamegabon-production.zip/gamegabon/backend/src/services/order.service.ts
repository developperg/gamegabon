import mongoose from 'mongoose';
import { Order, Payment, Promo, Pack, Game, User, Transaction } from '../models/index';
import { IOrder, IPayment } from '../types';
import { pvitService } from './pvit.service';
import { generateOrderNumber, calculateCashback, calculateDiscount } from '../utils/jwt';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

export class OrderService {
  // ── CREATE ORDER ─────────────────────────────────────────
  async createOrder(params: {
    userId: string;
    gameId: string;
    packId: string;
    playerId: string;
    paymentMethod: string;
    phoneNumber?: string;
    promoCode?: string;
    currency?: string;
  }): Promise<{ order: IOrder; payment: IPayment }> {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Validate game & pack
      const game = await Game.findById(params.gameId).session(session);
      if (!game || !game.active) throw new AppError('Game not found or inactive', 404);

      const pack = await Pack.findOne({ _id: params.packId, gameId: params.gameId, active: true }).session(session);
      if (!pack) throw new AppError('Pack not found or inactive', 404);

      // Get price in selected currency
      const currency = params.currency || 'XAF';
      const originalAmount =
        currency === 'USD' ? pack.priceUSD :
        currency === 'EUR' ? pack.priceEUR :
        pack.priceXAF;

      // Apply promo code
      let discountAmount = 0;
      let promoId;
      if (params.promoCode) {
        const promo = await Promo.findOne({
          code: params.promoCode.toUpperCase(),
          active: true,
          $expr: { $lt: ['$uses', '$maxUses'] },
          $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }],
        }).session(session);

        if (!promo) throw new AppError('Invalid or expired promo code', 400);

        const isApplicable =
          promo.applicableGames === 'all' ||
          (Array.isArray(promo.applicableGames) &&
            promo.applicableGames.some((id) => id.toString() === params.gameId));

        if (!isApplicable) throw new AppError('Promo code not applicable to this game', 400);

        if (originalAmount < promo.minAmount) {
          throw new AppError(`Minimum order amount for this promo is ${promo.minAmount} ${currency}`, 400);
        }

        discountAmount = calculateDiscount(
          originalAmount,
          promo.discountType,
          promo.discountValue,
          promo.maxDiscount
        );
        promoId = promo._id;

        // Increment promo uses
        await Promo.findByIdAndUpdate(promo._id, { $inc: { uses: 1 } }, { session });
      }

      const finalAmount = Math.max(0, originalAmount - discountAmount);
      const cashbackEarned = calculateCashback(finalAmount);

      // Create order
      const [order] = await Order.create(
        [
          {
            orderNumber: generateOrderNumber(),
            userId: params.userId,
            gameId: params.gameId,
            packId: params.packId,
            playerId: params.playerId.trim(),
            promoId: promoId || null,
            originalAmount,
            discountAmount,
            finalAmount,
            currency,
            status: 'pending',
            paymentMethod: params.paymentMethod,
            cashbackEarned,
          },
        ],
        { session }
      );

      // Create payment record
      const [payment] = await Payment.create(
        [
          {
            orderId: order._id,
            userId: params.userId,
            provider: params.paymentMethod,
            amount: finalAmount,
            currency,
            status: 'pending',
            phoneNumber: params.phoneNumber,
          },
        ],
        { session }
      );

      // Link payment to order
      await Order.findByIdAndUpdate(order._id, { paymentId: payment._id }, { session });

      // Initiate payment with PVit (Mobile Money)
      if (params.paymentMethod === 'pvit_airtel' || params.paymentMethod === 'pvit_moov') {
        if (!params.phoneNumber) throw new AppError('Phone number required for Mobile Money', 400);

        const provider = params.paymentMethod === 'pvit_airtel' ? 'airtel' : 'moov';
        const pvitResponse = await pvitService.initiatePayment({
          amount: finalAmount,
          currency,
          phoneNumber: params.phoneNumber,
          provider,
          orderId: order._id.toString(),
          merchantRef: order.orderNumber,
          description: `GameTopUp - ${game.name} - ${pack.label}`,
          callbackUrl: process.env.PVIT_CALLBACK_URL!,
        });

        await Payment.findByIdAndUpdate(
          payment._id,
          {
            pvitTransactionId: pvitResponse.transactionId,
            pvitReference: pvitResponse.reference,
            status: 'processing',
          },
          { session }
        );

        await Order.findByIdAndUpdate(order._id, { status: 'processing' }, { session });
      }

      await session.commitTransaction();
      logger.info(`Order created: ${order.orderNumber} by user ${params.userId}`);

      return { order, payment };
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      session.endSession();
    }
  }

  // ── DELIVER ORDER (called after payment confirmed) ────────
  async deliverOrder(orderId: string): Promise<IOrder> {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const order = await Order.findById(orderId).session(session);
      if (!order) throw new AppError('Order not found', 404);
      if (order.status === 'delivered') throw new AppError('Order already delivered', 400);

      // Update order
      order.status = 'delivered';
      order.deliveredAt = new Date();
      await order.save({ session });

      // Credit cashback to user
      if (order.cashbackEarned > 0) {
        await User.findByIdAndUpdate(
          order.userId,
          {
            $inc: {
              cashback: order.cashbackEarned,
              totalSpent: order.finalAmount,
              totalOrders: 1,
            },
          },
          { session }
        );

        // Transaction record
        const user = await User.findById(order.userId).session(session);
        if (user) {
          await Transaction.create(
            [
              {
                userId: order.userId,
                type: 'cashback',
                amount: order.cashbackEarned,
                currency: order.currency,
                description: `Cashback for order ${order.orderNumber}`,
                referenceId: order._id,
                referenceModel: 'Order',
                balanceBefore: user.cashback - order.cashbackEarned,
                balanceAfter: user.cashback,
              },
            ],
            { session }
          );
        }
      }

      await session.commitTransaction();
      logger.info(`Order delivered: ${order.orderNumber}`);
      return order;
    } catch (error) {
      await session.abortTransaction();
      throw error;
    } finally {
      session.endSession();
    }
  }

  // ── GET USER ORDERS ──────────────────────────────────────
  async getUserOrders(
    userId: string,
    page = 1,
    limit = 10,
    status?: string
  ) {
    const query: Record<string, unknown> = { userId };
    if (status) query.status = status;

    const [orders, total] = await Promise.all([
      Order.find(query)
        .populate('gameId', 'name icon color currency')
        .populate('packId', 'label amount bonusAmount')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Order.countDocuments(query),
    ]);

    return { orders, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  // ── GET ALL ORDERS (ADMIN) ────────────────────────────────
  async getAllOrders(params: {
    page?: number;
    limit?: number;
    status?: string;
    search?: string;
    gameId?: string;
    startDate?: string;
    endDate?: string;
  }) {
    const { page = 1, limit = 20, status, search, gameId, startDate, endDate } = params;
    const query: Record<string, unknown> = {};

    if (status) query.status = status;
    if (gameId) query.gameId = gameId;
    if (startDate || endDate) {
      query.createdAt = {};
      if (startDate) (query.createdAt as Record<string, unknown>)['$gte'] = new Date(startDate);
      if (endDate) (query.createdAt as Record<string, unknown>)['$lte'] = new Date(endDate);
    }

    let pipeline: unknown[] = [{ $match: query }];

    if (search) {
      pipeline = [
        {
          $lookup: { from: 'users', localField: 'userId', foreignField: '_id', as: 'user' },
        },
        { $unwind: '$user' },
        {
          $match: {
            ...query,
            $or: [
              { orderNumber: { $regex: search, $options: 'i' } },
              { 'user.name': { $regex: search, $options: 'i' } },
              { 'user.email': { $regex: search, $options: 'i' } },
            ],
          },
        },
      ];
    }

    const [result] = await Order.aggregate([
      ...pipeline,
      {
        $facet: {
          orders: [
            { $sort: { createdAt: -1 } },
            { $skip: (page - 1) * limit },
            { $limit: limit },
            {
              $lookup: { from: 'games', localField: 'gameId', foreignField: '_id', as: 'game' },
            },
            {
              $lookup: { from: 'packs', localField: 'packId', foreignField: '_id', as: 'pack' },
            },
            {
              $lookup: { from: 'users', localField: 'userId', foreignField: '_id', as: 'user' },
            },
            { $unwind: { path: '$game', preserveNullAndEmpty: true } },
            { $unwind: { path: '$pack', preserveNullAndEmpty: true } },
            { $unwind: { path: '$user', preserveNullAndEmpty: true } },
          ],
          total: [{ $count: 'count' }],
        },
      },
    ]);

    return {
      orders: result?.orders || [],
      total: result?.total?.[0]?.count || 0,
      page,
      limit,
      totalPages: Math.ceil((result?.total?.[0]?.count || 0) / limit),
    };
  }

  // ── ANALYTICS ────────────────────────────────────────────
  async getAnalytics(period: '7d' | '30d' | '90d' = '30d') {
    const days = period === '7d' ? 7 : period === '30d' ? 30 : 90;
    const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const [
      totalRevenue,
      totalOrders,
      revenueByDay,
      topGames,
      statusBreakdown,
      newUsers,
    ] = await Promise.all([
      Order.aggregate([
        { $match: { status: 'delivered', createdAt: { $gte: startDate } } },
        { $group: { _id: null, total: { $sum: '$finalAmount' }, count: { $sum: 1 } } },
      ]),
      Order.countDocuments({ createdAt: { $gte: startDate } }),
      Order.aggregate([
        { $match: { createdAt: { $gte: startDate } } },
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
            revenue: { $sum: '$finalAmount' },
            orders: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),
      Order.aggregate([
        { $match: { status: 'delivered', createdAt: { $gte: startDate } } },
        { $group: { _id: '$gameId', revenue: { $sum: '$finalAmount' }, orders: { $sum: 1 } } },
        { $sort: { revenue: -1 } },
        { $limit: 5 },
        { $lookup: { from: 'games', localField: '_id', foreignField: '_id', as: 'game' } },
        { $unwind: '$game' },
      ]),
      Order.aggregate([
        { $match: { createdAt: { $gte: startDate } } },
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
      User.countDocuments({ createdAt: { $gte: startDate }, role: { $ne: 'admin' } }),
    ]);

    const convRate =
      totalOrders > 0
        ? (((totalRevenue[0]?.count || 0) / totalOrders) * 100).toFixed(1)
        : '0';

    return {
      totalRevenue: totalRevenue[0]?.total || 0,
      totalDelivered: totalRevenue[0]?.count || 0,
      totalOrders,
      conversionRate: convRate,
      newUsers,
      revenueByDay,
      topGames,
      statusBreakdown,
      period,
    };
  }
}

export const orderService = new OrderService();
