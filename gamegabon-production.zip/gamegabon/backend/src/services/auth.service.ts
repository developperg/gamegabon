import crypto from 'crypto';
import { User } from '../models/User';
import { IUser } from '../types';
import { generateAccessToken, generateRefreshToken, verifyRefreshToken } from '../utils/jwt';
import { AppError } from '../utils/AppError';
import { securityLogger, logger } from '../utils/logger';

export class AuthService {
  // ── REGISTER ─────────────────────────────────────────────
  async register(data: {
    name: string;
    email: string;
    phone: string;
    password: string;
    referralCode?: string;
  }): Promise<{ user: IUser; accessToken: string; refreshToken: string }> {
    const existing = await User.findOne({ email: data.email });
    if (existing) throw new AppError('Email already registered', 409);

    let referredBy;
    if (data.referralCode) {
      const referrer = await User.findOne({ referralCode: data.referralCode });
      if (referrer) referredBy = referrer._id;
    }

    const user = await User.create({
      name: data.name,
      email: data.email,
      phone: data.phone,
      password: data.password,
      referredBy,
    });

    const payload = { userId: user._id.toString(), role: user.role, email: user.email };
    const accessToken = generateAccessToken(payload);
    const refreshToken = generateRefreshToken(payload);

    user.refreshToken = refreshToken;
    await user.save({ validateBeforeSave: false });

    logger.info(`New user registered: ${user.email} [${user._id}]`);
    return { user, accessToken, refreshToken };
  }

  // ── LOGIN ────────────────────────────────────────────────
  async login(
    email: string,
    password: string,
    ip?: string
  ): Promise<{ user: IUser; accessToken: string; refreshToken: string }> {
    const user = await User.findOne({ email }).select('+password +refreshToken');
    if (!user) {
      securityLogger.warn('Failed login attempt - user not found', { email, ip });
      throw new AppError('Invalid email or password', 401);
    }

    if (user.status === 'suspended') {
      securityLogger.warn('Suspended user login attempt', { email, ip });
      throw new AppError('Account suspended. Contact support.', 403);
    }

    const valid = await user.comparePassword(password);
    if (!valid) {
      securityLogger.warn('Failed login attempt - wrong password', { email, ip });
      throw new AppError('Invalid email or password', 401);
    }

    const payload = { userId: user._id.toString(), role: user.role, email: user.email };
    const accessToken = generateAccessToken(payload);
    const refreshToken = generateRefreshToken(payload);

    user.refreshToken = refreshToken;
    await user.save({ validateBeforeSave: false });

    logger.info(`User logged in: ${user.email} [${user._id}] from ${ip}`);
    return { user, accessToken, refreshToken };
  }

  // ── REFRESH TOKEN ────────────────────────────────────────
  async refreshToken(token: string): Promise<{ accessToken: string; refreshToken: string }> {
    let payload;
    try {
      payload = verifyRefreshToken(token);
    } catch {
      throw new AppError('Invalid or expired refresh token', 401);
    }

    const user = await User.findById(payload.userId).select('+refreshToken');
    if (!user || user.refreshToken !== token) {
      throw new AppError('Invalid refresh token', 401);
    }

    const newPayload = { userId: user._id.toString(), role: user.role, email: user.email };
    const accessToken = generateAccessToken(newPayload);
    const newRefreshToken = generateRefreshToken(newPayload);

    user.refreshToken = newRefreshToken;
    await user.save({ validateBeforeSave: false });

    return { accessToken, refreshToken: newRefreshToken };
  }

  // ── LOGOUT ──────────────────────────────────────────────
  async logout(userId: string): Promise<void> {
    await User.findByIdAndUpdate(userId, { $unset: { refreshToken: 1 } });
    logger.info(`User logged out: ${userId}`);
  }

  // ── FORGOT PASSWORD ───────────────────────────────────────
  async forgotPassword(email: string): Promise<string> {
    const user = await User.findOne({ email });
    if (!user) throw new AppError('No account with that email', 404);

    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto.createHash('sha256').update(resetToken).digest('hex');

    user.passwordResetToken = hashedToken;
    user.passwordResetExpires = new Date(Date.now() + 10 * 60 * 1000);
    await user.save({ validateBeforeSave: false });

    logger.info(`Password reset requested for: ${email}`);
    return resetToken;
  }

  // ── RESET PASSWORD ────────────────────────────────────────
  async resetPassword(token: string, newPassword: string): Promise<void> {
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const user = await User.findOne({
      passwordResetToken: hashedToken,
      passwordResetExpires: { $gt: new Date() },
    });
    if (!user) throw new AppError('Invalid or expired reset token', 400);

    user.password = newPassword;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    user.refreshToken = undefined;
    await user.save();

    logger.info(`Password reset successful for: ${user.email}`);
  }

  // ── GET PROFILE ──────────────────────────────────────────
  async getProfile(userId: string): Promise<IUser> {
    const user = await User.findById(userId);
    if (!user) throw new AppError('User not found', 404);
    return user;
  }

  // ── UPDATE PROFILE ───────────────────────────────────────
  async updateProfile(
    userId: string,
    data: { name?: string; phone?: string }
  ): Promise<IUser> {
    const user = await User.findByIdAndUpdate(
      userId,
      { $set: { name: data.name, phone: data.phone } },
      { new: true, runValidators: true }
    );
    if (!user) throw new AppError('User not found', 404);
    logger.info(`Profile updated: ${userId}`);
    return user;
  }
}

export const authService = new AuthService();
