import axios from 'axios';
import crypto from 'crypto';
import { PvitPaymentRequest, PvitPaymentResponse, PvitWebhookPayload } from '../types';
import { AppError } from '../utils/AppError';
import { logger, securityLogger } from '../utils/logger';

export class PvitService {
  private readonly baseUrl: string;
  private readonly apiKey: string;
  private readonly secretKey: string;
  private readonly merchantId: string;
  private readonly callbackUrl: string;

  constructor() {
    this.baseUrl = process.env.PVIT_BASE_URL || 'https://api.pvit.com/v1';
    this.apiKey = process.env.PVIT_API_KEY || '';
    this.secretKey = process.env.PVIT_SECRET_KEY || '';
    this.merchantId = process.env.PVIT_MERCHANT_ID || '';
    this.callbackUrl = process.env.PVIT_CALLBACK_URL || '';
  }

  // ── GENERATE SIGNATURE ───────────────────────────────────
  private generateSignature(data: Record<string, unknown>): string {
    const payload = Object.keys(data)
      .sort()
      .map((k) => `${k}=${data[k]}`)
      .join('&');
    return crypto
      .createHmac('sha256', this.secretKey)
      .update(payload)
      .digest('hex');
  }

  // ── VERIFY WEBHOOK SIGNATURE ─────────────────────────────
  verifyWebhookSignature(payload: PvitWebhookPayload): boolean {
    const { signature, ...data } = payload;
    const expectedSignature = this.generateSignature(data as Record<string, unknown>);
    const isValid = crypto.timingSafeEqual(
      Buffer.from(signature, 'hex'),
      Buffer.from(expectedSignature, 'hex')
    );
    if (!isValid) {
      securityLogger.warn('Invalid PVit webhook signature', { payload });
    }
    return isValid;
  }

  // ── INITIATE PAYMENT ─────────────────────────────────────
  async initiatePayment(request: PvitPaymentRequest): Promise<PvitPaymentResponse> {
    const payload = {
      merchantId: this.merchantId,
      amount: request.amount,
      currency: request.currency,
      phoneNumber: request.phoneNumber,
      provider: request.provider,
      orderId: request.orderId,
      merchantRef: request.merchantRef,
      description: request.description,
      callbackUrl: request.callbackUrl,
      timestamp: new Date().toISOString(),
    };

    const signature = this.generateSignature(payload as Record<string, unknown>);

    try {
      // In production, this makes a real API call to PVit
      // For development/staging, we simulate the response
      if (process.env.NODE_ENV !== 'production') {
        logger.info('[PVIT MOCK] Simulating payment initiation', { merchantRef: request.merchantRef });
        return {
          success: true,
          transactionId: `PVIT-${Date.now()}`,
          reference: request.merchantRef,
          status: 'PENDING',
          message: 'Payment initiated. Awaiting customer confirmation.',
        };
      }

      const response = await axios.post(
        `${this.baseUrl}/payments/initiate`,
        { ...payload, signature },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
            'X-Merchant-Id': this.merchantId,
          },
          timeout: 30000,
        }
      );

      logger.info('[PVIT] Payment initiated', {
        transactionId: response.data.transactionId,
        merchantRef: request.merchantRef,
        provider: request.provider,
      });

      return response.data as PvitPaymentResponse;
    } catch (error: unknown) {
      const axiosErr = error as { response?: { data?: { message?: string }; status?: number }; message?: string };
      const errMsg = axiosErr.response?.data?.message || axiosErr.message || 'Payment initiation failed';
      logger.error('[PVIT] Payment initiation error', {
        error: errMsg,
        merchantRef: request.merchantRef,
      });
      throw new AppError(`Payment gateway error: ${errMsg}`, 502);
    }
  }

  // ── CHECK PAYMENT STATUS ─────────────────────────────────
  async checkPaymentStatus(transactionId: string): Promise<{ status: string; message: string }> {
    if (process.env.NODE_ENV !== 'production') {
      return { status: 'SUCCESS', message: 'Payment completed (mock)' };
    }

    try {
      const response = await axios.get(`${this.baseUrl}/payments/${transactionId}/status`, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'X-Merchant-Id': this.merchantId,
        },
        timeout: 15000,
      });
      return response.data as { status: string; message: string };
    } catch (error: unknown) {
      const axiosErr = error as { message?: string };
      throw new AppError(`Status check failed: ${axiosErr.message}`, 502);
    }
  }

  // ── PROCESS AIRTEL MONEY ─────────────────────────────────
  async payAirtelMoney(params: {
    orderId: string;
    merchantRef: string;
    amount: number;
    phoneNumber: string;
    description: string;
  }): Promise<PvitPaymentResponse> {
    return this.initiatePayment({
      ...params,
      currency: 'XAF',
      provider: 'airtel',
      callbackUrl: this.callbackUrl,
    });
  }

  // ── PROCESS MOOV MONEY ───────────────────────────────────
  async payMoovMoney(params: {
    orderId: string;
    merchantRef: string;
    amount: number;
    phoneNumber: string;
    description: string;
  }): Promise<PvitPaymentResponse> {
    return this.initiatePayment({
      ...params,
      currency: 'XAF',
      provider: 'moov',
      callbackUrl: this.callbackUrl,
    });
  }
}

export const pvitService = new PvitService();
