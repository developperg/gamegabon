import { Payment, Order, User, Transaction } from '../models/index';
import { IPayment, PaymentProvider } from '../types';
import { pvitService } from './pvit.service';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';
import mongoose from 'mongoose';

export class PaymentService {
  // ── INITIATE MOBILE MONEY PAYMENT ────────────────────────
  async initiateMobileMoneyPayment(params: {
    orderId: string;
    userId: string;
    provider: 'pvit_airtel' | 'pvit_moov';
    phoneNumber: string;
  }): Promise<IPayment> {
    const order = await Order.findById(params.orderId);
    if (!order) throw new AppError('Order not found', 404);
    if (order.userId.toString() !== params.userId) throw new AppError('Forbidden', 403);
    if (order.status !== 'pending') throw new AppError('Order is not in pending state', 400);

    // Find or create payment record
    let payment = await Payment.findOne({ orderId: params.orderId });
    if (!payment) {
      payment = await Payment.create({
        orderId: params.orderId,
        userId: params.userId,
        provider: params.provider,
        amount: order.finalAmount,
        currency: order.currency,
        status: 'pending',
        phoneNumber: params.phoneNumber,
      });
    }

    // Call PVit gateway
    const pvitProvider = params.provider === 'pvit_airtel' ? 'airtel' : 'moov';
    const pvitResponse = await pvitService.initiatePayment({
      amount: order.finalAmount,
      currency: order.currency,
      phoneNumber: params.phoneNumber,
      provider: pvitProvider,
      orderId: params.orderId,
      merchantRef: order.orderNumber,
      description: `GameTopUp Gabon — ${order.orderNumber}`,
      callbackUrl: process.env.PVIT_CALLBACK_URL!,
    });

    // Update payment with PVit reference
    payment = await Payment.findByIdAndUpdate(
      payment._id,
      {
        pvitTransactionId: pvitResponse.transactionId,
        pvitReference: pvitResponse.reference,
        status: 'processing',
      },
      { new: true }
    ) as IPayment;

    // Update order status
    await Order.findByIdAndUpdate(params.orderId, { status: 'processing' });

    logger.info(`Payment initiated: ${pvitResponse.transactionId} for order ${order.orderNumber}`);
    return payment;
  }

  // ── GET USER PAYMENTS ─────────────────────────────────────
  async getUserPayments(userId: string, page = 1, limit = 10) {
    const [payments, total] = await Promise.all([
      Payment.find({ userId })
        .populate('orderId', 'orderNumber status')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Payment.countDocuments({ userId }),
    ]);
    return { payments, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  // ── ADMIN: GET ALL PAYMENTS ───────────────────────────────
  async getAllPayments(params: { page?: number; limit?: number; status?: string; provider?: string }) {
    const { page = 1, limit = 20, status, provider } = params;
    const query: Record<string, unknown> = {};
    if (status) query.status = status;
    if (provider) query.provider = provider;

    const [payments, total] = await Promise.all([
      Payment.find(query)
        .populate('userId', 'name email phone')
        .populate('orderId', 'orderNumber status finalAmount')
        .sort({ createdAt: -1 })
        .skip((page - 1) * limit)
        .limit(limit)
        .lean(),
      Payment.countDocuments(query),
    ]);

    // Revenue stats
    const stats = await Payment.aggregate([
      { $match: { status: 'success' } },
      {
        $group: {
          _id: '$provider',
          total: { $sum: '$amount' },
          count: { $sum: 1 },
        },
      },
    ]);

    return { payments, total, page, limit, totalPages: Math.ceil(total / limit), stats };
  }

  // ── CHECK PAYMENT STATUS (polling) ───────────────────────
  async checkStatus(paymentId: string, userId: string): Promise<IPayment> {
    const payment = await Payment.findOne({ _id: paymentId, userId });
    if (!payment) throw new AppError('Payment not found', 404);

    if (payment.status === 'processing' && payment.pvitTransactionId) {
      const pvitStatus = await pvitService.checkPaymentStatus(payment.pvitTransactionId);

      if (pvitStatus.status === 'SUCCESS' && payment.status !== 'success') {
        await Payment.findByIdAndUpdate(paymentId, { status: 'success', processedAt: new Date() });
        // Trigger order delivery
        const { orderService } = await import('./order.service');
        await orderService.deliverOrder(payment.orderId.toString());
        return Payment.findById(paymentId) as Promise<IPayment>;
      }

      if (pvitStatus.status === 'FAILED') {
        await Payment.findByIdAndUpdate(paymentId, { status: 'failed', failureReason: pvitStatus.message });
        await Order.findByIdAndUpdate(payment.orderId, { status: 'failed' });
        return Payment.findById(paymentId) as Promise<IPayment>;
      }
    }

    return payment;
  }

  // ── REFUND ────────────────────────────────────────────────
  async refundPayment(paymentId: string, adminId: string): Promise<void> {
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const payment = await Payment.findById(paymentId).session(session);
      if (!payment) throw new AppError('Payment not found', 404);
      if (payment.status !== 'success') throw new AppError('Only successful payments can be refunded', 400);

      await Payment.findByIdAndUpdate(paymentId, { status: 'refunded' }, { session });
      await Order.findByIdAndUpdate(payment.orderId, { status: 'refunded' }, { session });

      // Reverse cashback if any
      const order = await Order.findById(payment.orderId).session(session);
      if (order && order.cashbackEarned > 0) {
        const user = await User.findById(payment.userId).session(session);
        if (user) {
          const newCashback = Math.max(0, user.cashback - order.cashbackEarned);
          await User.findByIdAndUpdate(
            payment.userId,
            { $set: { cashback: newCashback }, $inc: { totalSpent: -order.finalAmount, totalOrders: -1 } },
            { session }
          );
          await Transaction.create([{
            userId: payment.userId,
            type: 'refund',
            amount: order.cashbackEarned,
            currency: order.currency,
            description: `Cashback reversed for refund on order ${order.orderNumber}`,
            referenceId: order._id,
            referenceModel: 'Order',
            balanceBefore: user.cashback,
            balanceAfter: newCashback,
          }], { session });
        }
      }

      await session.commitTransaction();
      logger.info(`Payment refunded: ${paymentId} by admin ${adminId}`);
    } catch (err) {
      await session.abortTransaction();
      throw err;
    } finally {
      session.endSession();
    }
  }
}

export const paymentService = new PaymentService();
