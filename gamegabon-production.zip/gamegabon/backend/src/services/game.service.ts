import { Game, Pack } from '../models/index';
import { IGame, IPack } from '../types';
import { AppError } from '../utils/AppError';
import { logger } from '../utils/logger';

export class GameService {
  // ── PUBLIC ────────────────────────────────────────────────
  async getActiveGames(): Promise<IGame[]> {
    return Game.find({ active: true }).sort({ featured: -1, sortOrder: 1, name: 1 }).lean();
  }

  async getGameWithPacks(slug: string): Promise<{ game: IGame; packs: IPack[] }> {
    const game = await Game.findOne({ slug, active: true }).lean();
    if (!game) throw new AppError('Game not found', 404);
    const packs = await Pack.find({ gameId: game._id, active: true })
      .sort({ sortOrder: 1, priceXAF: 1 })
      .lean();
    return { game, packs };
  }

  // ── ADMIN ─────────────────────────────────────────────────
  async getAllGames(): Promise<(IGame & { packCount: number })[]> {
    const games = await Game.find().sort({ sortOrder: 1, name: 1 }).lean();
    const withCounts = await Promise.all(
      games.map(async (g) => ({
        ...g,
        packCount: await Pack.countDocuments({ gameId: g._id }),
        packs: await Pack.find({ gameId: g._id }).sort({ sortOrder: 1 }).lean(),
      }))
    );
    return withCounts as (IGame & { packCount: number })[];
  }

  async createGame(data: Partial<IGame>): Promise<IGame> {
    const slug = (data.name || '')
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '');
    const existing = await Game.findOne({ slug });
    if (existing) throw new AppError('A game with this name already exists', 409);
    const game = await Game.create({ ...data, slug });
    logger.info(`Game created: ${game.name} [${game._id}]`);
    return game;
  }

  async updateGame(id: string, data: Partial<IGame>): Promise<IGame> {
    const game = await Game.findByIdAndUpdate(id, { $set: data }, { new: true, runValidators: true });
    if (!game) throw new AppError('Game not found', 404);
    logger.info(`Game updated: ${game.name} [${game._id}]`);
    return game;
  }

  async deleteGame(id: string): Promise<void> {
    const game = await Game.findByIdAndDelete(id);
    if (!game) throw new AppError('Game not found', 404);
    await Pack.deleteMany({ gameId: id });
    logger.info(`Game deleted: ${game.name} [${id}]`);
  }

  // ── PACKS ─────────────────────────────────────────────────
  async createPack(gameId: string, data: Partial<IPack>): Promise<IPack> {
    const game = await Game.findById(gameId);
    if (!game) throw new AppError('Game not found', 404);
    const pack = await Pack.create({ ...data, gameId });
    logger.info(`Pack created: ${pack.label} for game ${game.name}`);
    return pack;
  }

  async updatePack(gameId: string, packId: string, data: Partial<IPack>): Promise<IPack> {
    const pack = await Pack.findOneAndUpdate(
      { _id: packId, gameId },
      { $set: data },
      { new: true, runValidators: true }
    );
    if (!pack) throw new AppError('Pack not found', 404);
    return pack;
  }

  async deletePack(gameId: string, packId: string): Promise<void> {
    const pack = await Pack.findOneAndDelete({ _id: packId, gameId });
    if (!pack) throw new AppError('Pack not found', 404);
    logger.info(`Pack deleted: ${pack.label} [${packId}]`);
  }
}

export const gameService = new GameService();
