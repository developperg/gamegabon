import 'express-async-errors';
import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import { connectDB } from './config/database';
import routes from './routes/index';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { logger } from './utils/logger';

// ── Validate critical env vars ────────────────────────────────
const requiredEnv = ['MONGODB_URI', 'JWT_SECRET', 'JWT_REFRESH_SECRET'];
requiredEnv.forEach((key) => {
  if (!process.env[key]) {
    logger.error(`Missing required environment variable: ${key}`);
    process.exit(1);
  }
});

const app = express();
const PORT = parseInt(process.env.PORT || '5000', 10);
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:3000';

// ── Security middleware ───────────────────────────────────────
app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
    },
  },
}));

app.use(cors({
  origin: (origin, callback) => {
    const allowed = [FRONTEND_URL, 'http://localhost:3000', 'http://localhost:3001'];
    if (!origin || allowed.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error(`CORS blocked: ${origin}`));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// ── General middleware ────────────────────────────────────────
app.use(compression());
app.use(cookieParser());

// Raw body for webhook signature verification
app.use('/api/webhooks', express.raw({ type: 'application/json' }));

app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: true, limit: '10kb' }));

// ── Logging ───────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan('combined', {
    stream: { write: (msg) => logger.info(msg.trim()) },
  }));
}

// ── Trust proxy (for rate limiting behind reverse proxy) ──────
app.set('trust proxy', 1);

// ── Routes ────────────────────────────────────────────────────
app.use('/api', routes);

// ── 404 & Error handlers ──────────────────────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

// ── Start server ──────────────────────────────────────────────
const startServer = async (): Promise<void> => {
  await connectDB();
  await seedAdminUser();

  app.listen(PORT, () => {
    logger.info(`🚀 GameTopUp Gabon API started`);
    logger.info(`   Environment : ${process.env.NODE_ENV}`);
    logger.info(`   Port        : ${PORT}`);
    logger.info(`   Frontend    : ${FRONTEND_URL}`);
  });
};

// ── Seed admin user ───────────────────────────────────────────
async function seedAdminUser(): Promise<void> {
  try {
    const { User } = await import('./models/User');
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@gamegabon.com';
    const existing = await User.findOne({ email: adminEmail });
    if (!existing) {
      await User.create({
        name: 'Administrateur GameTopUp',
        email: adminEmail,
        phone: '+241 011 000 000',
        password: process.env.ADMIN_PASSWORD || 'Admin@Gabon2026!',
        role: 'admin',
        status: 'active',
        emailVerified: true,
      });
      logger.info(`✅ Admin user seeded: ${adminEmail}`);
    }
  } catch (error) {
    logger.error('Failed to seed admin user:', error);
  }
}

// ── Graceful shutdown ─────────────────────────────────────────
process.on('SIGTERM', async () => {
  logger.info('SIGTERM received. Shutting down gracefully...');
  const { disconnectDB } = await import('./config/database');
  await disconnectDB();
  process.exit(0);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Rejection:', reason);
  process.exit(1);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

startServer().catch((err) => {
  logger.error('Failed to start server:', err);
  process.exit(1);
});

export default app;
