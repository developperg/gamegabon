import rateLimit from 'express-rate-limit';
import { securityLogger } from '../utils/logger';

const onLimitReached = (req: import('express').Request): void => {
  securityLogger.warn('Rate limit exceeded', {
    ip: req.ip,
    path: req.path,
    userAgent: req.get('User-Agent'),
  });
};

// General API limiter
export const apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '900000'),
  max:      parseInt(process.env.RATE_LIMIT_MAX       || '100'),
  message:  { success: false, message: 'Too many requests. Please slow down.' },
  standardHeaders: true,
  legacyHeaders:   false,
  handler: (req, res) => {
    onLimitReached(req);
    res.status(429).json({ success: false, message: 'Too many requests. Please slow down.' });
  },
});

// Strict auth limiter
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max:      parseInt(process.env.AUTH_RATE_LIMIT_MAX || '10'),
  message:  { success: false, message: 'Too many login attempts. Try again in 15 minutes.' },
  skipSuccessfulRequests: true,
  handler: (req, res) => {
    onLimitReached(req);
    res.status(429).json({ success: false, message: 'Too many login attempts. Try again in 15 minutes.' });
  },
});

// Payment limiter
export const paymentLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max:      5,
  message:  { success: false, message: 'Too many payment attempts. Try again in 10 minutes.' },
  handler: (req, res) => {
    onLimitReached(req);
    res.status(429).json({ success: false, message: 'Too many payment attempts. Try again in 10 minutes.' });
  },
});
