import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { User } from '../models/User';
import { AuthRequest, AuthPayload } from '../types';
import { AppError } from '../utils/AppError';
import { securityLogger } from '../utils/logger';

export const authenticate = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('No token provided. Please login.', 401);
    }

    const token = authHeader.substring(7);
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new AppError('JWT secret not configured', 500);

    let payload: AuthPayload;
    try {
      payload = jwt.verify(token, secret) as AuthPayload;
    } catch (err) {
      if (err instanceof jwt.TokenExpiredError) {
        throw new AppError('Token expired. Please login again.', 401);
      }
      throw new AppError('Invalid token.', 401);
    }

    const user = await User.findById(payload.userId).select('+status');
    if (!user) throw new AppError('User not found.', 401);
    if (user.status === 'suspended') {
      securityLogger.warn('Suspended user attempted access', { userId: user._id, ip: req.ip });
      throw new AppError('Your account has been suspended. Contact support.', 403);
    }

    req.user = { userId: payload.userId, role: user.role, email: user.email };
    next();
  } catch (error) {
    next(error);
  }
};

export const authorize = (...roles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(new AppError('Not authenticated', 401));
      return;
    }
    if (!roles.includes(req.user.role)) {
      securityLogger.warn('Unauthorized access attempt', {
        userId: req.user.userId,
        role: req.user.role,
        requiredRoles: roles,
        path: req.path,
        ip: req.ip,
      });
      next(new AppError('Access denied. Insufficient permissions.', 403));
      return;
    }
    next();
  };
};

export const adminOnly = authorize('admin');
export const adminOrReseller = authorize('admin', 'reseller');
