import { z } from 'zod';

// ── GAME ─────────────────────────────────────────────────────
export const createGameSchema = z.object({
  body: z.object({
    name: z.string().min(1, 'Name required').max(80).trim(),
    currency: z.string().min(1, 'Currency required').max(50).trim(),
    icon: z.string().min(1, 'Icon required').max(10),
    color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, 'Must be a valid hex color'),
    coverImage: z.string().url().optional(),
    description: z.string().max(500).optional(),
    featured: z.boolean().optional(),
    sortOrder: z.number().int().min(0).optional(),
    active: z.boolean().optional(),
  }),
});

export const updateGameSchema = z.object({
  body: z.object({
    name: z.string().min(1).max(80).trim().optional(),
    currency: z.string().min(1).max(50).trim().optional(),
    icon: z.string().max(10).optional(),
    color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
    coverImage: z.string().url().optional().nullable(),
    description: z.string().max(500).optional().nullable(),
    featured: z.boolean().optional(),
    sortOrder: z.number().int().min(0).optional(),
    active: z.boolean().optional(),
  }),
  params: z.object({ id: z.string().min(1) }),
});

// ── PACK ─────────────────────────────────────────────────────
export const createPackSchema = z.object({
  body: z.object({
    label: z.string().min(1, 'Label required').max(100).trim(),
    amount: z.number().int().min(0),
    bonusAmount: z.number().int().min(0).optional().default(0),
    priceXAF: z.number().positive('Price XAF must be positive'),
    priceUSD: z.number().positive('Price USD must be positive'),
    priceEUR: z.number().positive('Price EUR must be positive'),
    popular: z.boolean().optional(),
    sortOrder: z.number().int().min(0).optional(),
    active: z.boolean().optional(),
  }),
  params: z.object({ gameId: z.string().min(1) }),
});

// ── PROMO ─────────────────────────────────────────────────────
export const createPromoSchema = z.object({
  body: z.object({
    code: z.string().min(2, 'Min. 2 characters').max(20).trim().toUpperCase(),
    discountType: z.enum(['percent', 'fixed']),
    discountValue: z.number().positive('Must be positive'),
    minAmount: z.number().min(0).optional().default(0),
    maxDiscount: z.number().positive().optional(),
    applicableGames: z.union([z.literal('all'), z.array(z.string())]).default('all'),
    maxUses: z.number().int().positive('Must be at least 1'),
    expiresAt: z.string().datetime().optional().nullable(),
    active: z.boolean().optional().default(true),
  }).refine(
    (d) => {
      if (d.discountType === 'percent' && d.discountValue > 100) return false;
      return true;
    },
    { message: 'Percentage discount cannot exceed 100%', path: ['discountValue'] }
  ),
});

export const updatePromoSchema = z.object({
  body: z.object({
    code: z.string().min(2).max(20).trim().toUpperCase().optional(),
    discountType: z.enum(['percent', 'fixed']).optional(),
    discountValue: z.number().positive().optional(),
    minAmount: z.number().min(0).optional(),
    maxDiscount: z.number().positive().optional().nullable(),
    applicableGames: z.union([z.literal('all'), z.array(z.string())]).optional(),
    maxUses: z.number().int().positive().optional(),
    expiresAt: z.string().datetime().optional().nullable(),
    active: z.boolean().optional(),
  }),
  params: z.object({ id: z.string().min(1) }),
});

// ── VALIDATE PROMO (public) ───────────────────────────────────
export const validatePromoSchema = z.object({
  body: z.object({
    code:   z.string().min(1, 'Code required').trim().toUpperCase(),
    gameId: z.string().min(1, 'Game ID required'),
    amount: z.number().positive('Amount must be positive'),
  }),
});

// ── USER UPDATE (admin) ───────────────────────────────────────
export const adminUpdateUserSchema = z.object({
  body: z.object({
    name:   z.string().min(2).max(80).trim().optional(),
    phone:  z.string().min(8).trim().optional(),
    role:   z.enum(['admin', 'reseller', 'client']).optional(),
    status: z.enum(['active', 'suspended']).optional(),
  }),
  params: z.object({ id: z.string().min(1) }),
});
