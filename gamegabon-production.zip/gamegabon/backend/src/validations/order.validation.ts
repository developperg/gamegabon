import { z } from 'zod';

export const createOrderSchema = z.object({
  body: z.object({
    gameId: z.string().min(1, 'Game ID is required'),
    packId: z.string().min(1, 'Pack ID is required'),
    playerId: z.string().min(1, 'Player ID is required').max(100, 'Player ID too long').trim(),
    paymentMethod: z.enum(['pvit_airtel', 'pvit_moov', 'card', 'paypal', 'usdt']),
    phoneNumber: z.string().optional(),
    promoCode: z.string().optional(),
    currency: z.enum(['XAF', 'USD', 'EUR']).default('XAF'),
  }),
});

export const updateOrderStatusSchema = z.object({
  body: z.object({
    status: z.enum(['pending', 'processing', 'delivered', 'failed', 'refunded']),
    notes: z.string().optional(),
  }),
  params: z.object({
    id: z.string().min(1),
  }),
});

export const initiatePaymentSchema = z.object({
  body: z.object({
    orderId: z.string().min(1, 'Order ID is required'),
    phoneNumber: z
      .string()
      .min(8, 'Phone number must be at least 8 digits')
      .regex(/^\+?[\d\s-]{8,15}$/, 'Invalid phone number format')
      .optional(),
  }),
});
