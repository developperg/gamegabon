import { Request, Response } from 'express';
import { pvitService } from '../services/pvit.service';
import { orderService } from '../services/order.service';
import { Payment, Order } from '../models/index';
import { PvitWebhookPayload } from '../types';
import { logger, securityLogger } from '../utils/logger';

export const handlePvitWebhook = async (req: Request, res: Response): Promise<void> => {
  // Immediately acknowledge receipt (PVit requirement)
  res.status(200).json({ received: true });

  const payload = req.body as PvitWebhookPayload;

  try {
    // ── 1. Verify signature ──────────────────────────────────
    const isValid = pvitService.verifyWebhookSignature(payload);
    if (!isValid) {
      securityLogger.error('PVit webhook - INVALID SIGNATURE', {
        transactionId: payload.transactionId,
        ip: req.ip,
      });
      return;
    }

    logger.info('[PVIT WEBHOOK] Received', {
      transactionId: payload.transactionId,
      merchantRef: payload.merchantRef,
      status: payload.status,
      amount: payload.amount,
    });

    // ── 2. Find payment by PVit transaction ID ───────────────
    const payment = await Payment.findOne({ pvitTransactionId: payload.transactionId });
    if (!payment) {
      // Try by order number
      const order = await Order.findOne({ orderNumber: payload.merchantRef });
      if (!order) {
        logger.warn('[PVIT WEBHOOK] Order not found', { merchantRef: payload.merchantRef });
        return;
      }
      const paymentByOrder = await Payment.findOne({ orderId: order._id });
      if (!paymentByOrder) {
        logger.warn('[PVIT WEBHOOK] Payment not found', { orderId: order._id });
        return;
      }
      await processWebhookStatus(paymentByOrder.id, payload);
      return;
    }

    await processWebhookStatus(payment.id, payload);
  } catch (error) {
    logger.error('[PVIT WEBHOOK] Processing error', { error, payload });
  }
};

async function processWebhookStatus(paymentId: string, payload: PvitWebhookPayload): Promise<void> {
  const payment = await Payment.findById(paymentId);
  if (!payment) return;

  // Idempotency: skip if already processed
  if (payment.status === 'success' || payment.status === 'failed') {
    logger.info('[PVIT WEBHOOK] Already processed, skipping', { paymentId });
    return;
  }

  // ── SUCCESS ───────────────────────────────────────────────
  if (payload.status === 'SUCCESS') {
    await Payment.findByIdAndUpdate(paymentId, {
      status: 'success',
      callbackData: payload,
      processedAt: new Date(),
    });

    // Deliver the order
    try {
      await orderService.deliverOrder(payment.orderId.toString());
      logger.info('[PVIT WEBHOOK] Order delivered', {
        orderId: payment.orderId,
        transactionId: payload.transactionId,
      });
    } catch (err) {
      logger.error('[PVIT WEBHOOK] Order delivery failed after payment success', {
        orderId: payment.orderId,
        error: err,
      });
    }
  }

  // ── FAILED ────────────────────────────────────────────────
  if (payload.status === 'FAILED') {
    await Payment.findByIdAndUpdate(paymentId, {
      status: 'failed',
      failureReason: 'Payment declined by provider',
      callbackData: payload,
      processedAt: new Date(),
    });

    await Order.findByIdAndUpdate(payment.orderId, { status: 'failed' });

    logger.warn('[PVIT WEBHOOK] Payment failed', {
      orderId: payment.orderId,
      transactionId: payload.transactionId,
    });
  }
}
