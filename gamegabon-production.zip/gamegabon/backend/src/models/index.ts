import mongoose, { Schema } from 'mongoose';
import { IGame, IPack, IPromo, IOrder, IPayment, ITransaction } from '../types';

// ── GAME ─────────────────────────────────────────────────────
const GameSchema = new Schema<IGame>(
  {
    name: { type: String, required: true, trim: true },
    slug: { type: String, required: true, unique: true, lowercase: true },
    currency: { type: String, required: true, trim: true },
    icon: { type: String, required: true },
    color: { type: String, required: true, default: '#00E5FF' },
    coverImage: { type: String },
    description: { type: String },
    active: { type: Boolean, default: true },
    featured: { type: Boolean, default: false },
    sortOrder: { type: Number, default: 0 },
  },
  { timestamps: true }
);
GameSchema.index({ slug: 1 });
GameSchema.index({ active: 1, sortOrder: 1 });
export const Game = mongoose.model<IGame>('Game', GameSchema);

// ── PACK ─────────────────────────────────────────────────────
const PackSchema = new Schema<IPack>(
  {
    gameId: { type: Schema.Types.ObjectId, ref: 'Game', required: true },
    label: { type: String, required: true, trim: true },
    amount: { type: Number, required: true, min: 0 },
    bonusAmount: { type: Number, default: 0, min: 0 },
    priceXAF: { type: Number, required: true, min: 0 },
    priceUSD: { type: Number, required: true, min: 0 },
    priceEUR: { type: Number, required: true, min: 0 },
    active: { type: Boolean, default: true },
    popular: { type: Boolean, default: false },
    sortOrder: { type: Number, default: 0 },
  },
  { timestamps: true }
);
PackSchema.index({ gameId: 1, active: 1, sortOrder: 1 });
export const Pack = mongoose.model<IPack>('Pack', PackSchema);

// ── PROMO ─────────────────────────────────────────────────────
const PromoSchema = new Schema<IPromo>(
  {
    code: { type: String, required: true, unique: true, uppercase: true, trim: true },
    discountType: { type: String, enum: ['percent', 'fixed'], required: true },
    discountValue: { type: Number, required: true, min: 0 },
    minAmount: { type: Number, default: 0 },
    maxDiscount: { type: Number },
    applicableGames: {
      type: Schema.Types.Mixed,
      default: 'all',
    },
    active: { type: Boolean, default: true },
    uses: { type: Number, default: 0 },
    maxUses: { type: Number, required: true, min: 1 },
    expiresAt: { type: Date },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true }
);
PromoSchema.index({ code: 1 });
PromoSchema.index({ active: 1, expiresAt: 1 });
export const Promo = mongoose.model<IPromo>('Promo', PromoSchema);

// ── ORDER ─────────────────────────────────────────────────────
const OrderSchema = new Schema<IOrder>(
  {
    orderNumber: { type: String, required: true, unique: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    gameId: { type: Schema.Types.ObjectId, ref: 'Game', required: true },
    packId: { type: Schema.Types.ObjectId, ref: 'Pack', required: true },
    playerId: { type: String, required: true, trim: true },
    promoId: { type: Schema.Types.ObjectId, ref: 'Promo', default: null },
    originalAmount: { type: Number, required: true, min: 0 },
    discountAmount: { type: Number, default: 0, min: 0 },
    finalAmount: { type: Number, required: true, min: 0 },
    currency: { type: String, default: 'XAF' },
    status: {
      type: String,
      enum: ['pending', 'processing', 'delivered', 'failed', 'refunded'],
      default: 'pending',
    },
    paymentMethod: { type: String, required: true },
    paymentId: { type: Schema.Types.ObjectId, ref: 'Payment', default: null },
    cashbackEarned: { type: Number, default: 0, min: 0 },
    notes: { type: String },
    deliveredAt: { type: Date },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
  }
);
OrderSchema.index({ userId: 1, createdAt: -1 });
OrderSchema.index({ orderNumber: 1 });
OrderSchema.index({ status: 1, createdAt: -1 });
OrderSchema.virtual('game', { ref: 'Game', localField: 'gameId', foreignField: '_id', justOne: true });
OrderSchema.virtual('pack', { ref: 'Pack', localField: 'packId', foreignField: '_id', justOne: true });
OrderSchema.virtual('user', { ref: 'User', localField: 'userId', foreignField: '_id', justOne: true });
export const Order = mongoose.model<IOrder>('Order', OrderSchema);

// ── PAYMENT ─────────────────────────────────────────────────
const PaymentSchema = new Schema<IPayment>(
  {
    orderId: { type: Schema.Types.ObjectId, ref: 'Order', required: true },
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    provider: {
      type: String,
      enum: ['pvit_airtel', 'pvit_moov', 'card', 'paypal', 'usdt'],
      required: true,
    },
    amount: { type: Number, required: true, min: 0 },
    currency: { type: String, default: 'XAF' },
    status: {
      type: String,
      enum: ['pending', 'processing', 'success', 'failed', 'refunded'],
      default: 'pending',
    },
    transactionId: { type: String, unique: true, sparse: true },
    pvitTransactionId: { type: String },
    pvitReference: { type: String },
    phoneNumber: { type: String },
    callbackData: { type: Schema.Types.Mixed },
    failureReason: { type: String },
    processedAt: { type: Date },
  },
  { timestamps: true }
);
PaymentSchema.index({ orderId: 1 });
PaymentSchema.index({ userId: 1, createdAt: -1 });
PaymentSchema.index({ pvitTransactionId: 1 });
PaymentSchema.index({ status: 1 });
export const Payment = mongoose.model<IPayment>('Payment', PaymentSchema);

// ── TRANSACTION ─────────────────────────────────────────────
const TransactionSchema = new Schema<ITransaction>(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      enum: ['credit', 'debit', 'cashback', 'refund'],
      required: true,
    },
    amount: { type: Number, required: true },
    currency: { type: String, default: 'XAF' },
    description: { type: String, required: true },
    referenceId: { type: Schema.Types.ObjectId },
    referenceModel: { type: String },
    balanceBefore: { type: Number, required: true },
    balanceAfter: { type: Number, required: true },
  },
  { timestamps: true }
);
TransactionSchema.index({ userId: 1, createdAt: -1 });
TransactionSchema.index({ type: 1 });
export const Transaction = mongoose.model<ITransaction>('Transaction', TransactionSchema);
