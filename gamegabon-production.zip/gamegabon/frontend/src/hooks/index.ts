import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import toast from 'react-hot-toast';
import { AxiosError } from 'axios';
import { useAuthStore } from '@/store/auth.store';
import { authApi, ordersApi, gamesApi, promoApi, adminApi } from '@/lib/api';
import type { ApiResponse, Order, Analytics, Game, Promo, User } from '@/types';

// ── AUTH HOOKS ───────────────────────────────────────────────
export function useLogin() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);

  return useMutation({
    mutationFn: (data: { email: string; password: string }) => authApi.login(data),
    onSuccess: ({ data }) => {
      setAuth(data.data.user, data.data.accessToken);
      toast.success(`Bienvenue ${data.data.user.name.split(' ')[0]} !`);
      const dest = data.data.user.role === 'admin' ? '/admin' : '/dashboard';
      router.push(dest);
    },
    onError: (err: AxiosError<ApiResponse>) => {
      toast.error(err.response?.data?.message || 'Connexion échouée');
    },
  });
}

export function useRegister() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);

  return useMutation({
    mutationFn: (data: unknown) => authApi.register(data),
    onSuccess: ({ data }) => {
      setAuth(data.data.user, data.data.accessToken);
      toast.success('Compte créé avec succès !');
      router.push('/dashboard');
    },
    onError: (err: AxiosError<ApiResponse>) => {
      const errors = err.response?.data?.errors;
      const msg = errors ? Object.values(errors)[0] : err.response?.data?.message || 'Erreur inscription';
      toast.error(msg);
    },
  });
}

export function useLogout() {
  const router = useRouter();
  const logout = useAuthStore((s) => s.logout);
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: logout,
    onSuccess: () => {
      queryClient.clear();
      toast.success('Déconnecté avec succès');
      router.push('/auth/login');
    },
  });
}

// ── GAMES HOOKS ──────────────────────────────────────────────
export function useGames() {
  return useQuery({
    queryKey: ['games'],
    queryFn: () => gamesApi.getAll().then((r) => r.data.data as Game[]),
    staleTime: 5 * 60 * 1000,
  });
}

export function useGameWithPacks(slug: string) {
  return useQuery({
    queryKey: ['game', slug],
    queryFn: () => gamesApi.getBySlug(slug).then((r) => r.data.data as { game: Game; packs: unknown[] }),
    enabled: !!slug,
    staleTime: 5 * 60 * 1000,
  });
}

// ── PROMO HOOKS ──────────────────────────────────────────────
export function useValidatePromo() {
  return useMutation({
    mutationFn: (data: { code: string; gameId: string; amount: number }) => promoApi.validate(data),
    onError: (err: AxiosError<ApiResponse>) => {
      toast.error(err.response?.data?.message || 'Code promo invalide');
    },
  });
}

// ── ORDER HOOKS ──────────────────────────────────────────────
export function useCreateOrder() {
  const router = useRouter();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: unknown) => ordersApi.create(data),
    onSuccess: ({ data }) => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['me'] });
      const orderId = data.data.order._id;
      router.push(`/checkout/success?orderId=${orderId}`);
    },
    onError: (err: AxiosError<ApiResponse>) => {
      toast.error(err.response?.data?.message || 'Erreur lors de la commande');
    },
  });
}

export function useMyOrders(params?: { page?: number; status?: string }) {
  return useQuery({
    queryKey: ['orders', params],
    queryFn: () => ordersApi.getAll(params as Record<string, unknown>).then((r) => r.data),
    staleTime: 30 * 1000,
  });
}

// ── ADMIN HOOKS ──────────────────────────────────────────────
export function useAnalytics(period: '7d' | '30d' | '90d' = '30d') {
  return useQuery({
    queryKey: ['analytics', period],
    queryFn: () => adminApi.getAnalytics(period).then((r) => r.data.data as Analytics),
    staleTime: 60 * 1000,
  });
}

export function useAdminOrders(params?: Record<string, unknown>) {
  return useQuery({
    queryKey: ['admin-orders', params],
    queryFn: () => adminApi.getOrders(params).then((r) => r.data),
    staleTime: 30 * 1000,
  });
}

export function useAdminGames() {
  return useQuery({
    queryKey: ['admin-games'],
    queryFn: () => adminApi.getGames().then((r) => r.data.data as Game[]),
  });
}

export function useAdminPromos() {
  return useQuery({
    queryKey: ['admin-promos'],
    queryFn: () => adminApi.getPromos().then((r) => r.data.data as Promo[]),
  });
}

export function useAdminUsers(params?: Record<string, unknown>) {
  return useQuery({
    queryKey: ['admin-users', params],
    queryFn: () => adminApi.getUsers(params).then((r) => r.data),
  });
}

export function useUpdateOrderStatus() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, status, notes }: { id: string; status: string; notes?: string }) =>
      adminApi.updateOrderStatus(id, { status, notes }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-orders'] });
      queryClient.invalidateQueries({ queryKey: ['analytics'] });
      toast.success('Commande mise à jour');
    },
    onError: () => toast.error('Erreur mise à jour commande'),
  });
}

export function useDeleteGame() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => adminApi.deleteGame(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-games'] }); toast.success('Jeu supprimé'); },
    onError: () => toast.error('Erreur suppression'),
  });
}

export function useDeletePromo() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => adminApi.deletePromo(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-promos'] }); toast.success('Promo supprimée'); },
  });
}

export function useUpdateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: unknown }) => adminApi.updateUser(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['admin-users'] }); toast.success('Utilisateur mis à jour'); },
    onError: () => toast.error('Erreur mise à jour utilisateur'),
  });
}
