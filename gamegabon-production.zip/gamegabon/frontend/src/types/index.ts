// ── USER ─────────────────────────────────────────────────────
export interface User {
  _id: string;
  name: string;
  email: string;
  phone: string;
  role: 'admin' | 'reseller' | 'client';
  status: 'active' | 'suspended' | 'pending';
  emailVerified: boolean;
  referralCode: string;
  cashback: number;
  totalSpent: number;
  totalOrders: number;
  createdAt: string;
  updatedAt: string;
}

// ── GAME ─────────────────────────────────────────────────────
export interface Game {
  _id: string;
  name: string;
  slug: string;
  currency: string;
  icon: string;
  color: string;
  coverImage?: string;
  description?: string;
  active: boolean;
  featured: boolean;
  sortOrder: number;
  packCount?: number;
  createdAt: string;
}

// ── PACK ─────────────────────────────────────────────────────
export interface Pack {
  _id: string;
  gameId: string;
  label: string;
  amount: number;
  bonusAmount: number;
  priceXAF: number;
  priceUSD: number;
  priceEUR: number;
  active: boolean;
  popular: boolean;
  sortOrder: number;
}

// ── PROMO ─────────────────────────────────────────────────────
export interface Promo {
  _id: string;
  code: string;
  discountType: 'percent' | 'fixed';
  discountValue: number;
  minAmount: number;
  maxDiscount?: number;
  applicableGames: string[] | 'all';
  active: boolean;
  uses: number;
  maxUses: number;
  expiresAt?: string;
  createdAt: string;
}

// ── ORDER ─────────────────────────────────────────────────────
export type OrderStatus = 'pending' | 'processing' | 'delivered' | 'failed' | 'refunded';

export interface Order {
  _id: string;
  orderNumber: string;
  userId: string | User;
  gameId: string | Game;
  packId: string | Pack;
  playerId: string;
  promoId?: string | Promo;
  originalAmount: number;
  discountAmount: number;
  finalAmount: number;
  currency: string;
  status: OrderStatus;
  paymentMethod: string;
  cashbackEarned: number;
  notes?: string;
  deliveredAt?: string;
  createdAt: string;
  updatedAt: string;
  // Populated virtuals
  game?: Game;
  pack?: Pack;
  user?: User;
}

// ── PAYMENT ─────────────────────────────────────────────────
export type PaymentStatus = 'pending' | 'processing' | 'success' | 'failed' | 'refunded';
export type PaymentProvider = 'pvit_airtel' | 'pvit_moov' | 'card' | 'paypal' | 'usdt';

export interface Payment {
  _id: string;
  orderId: string;
  userId: string;
  provider: PaymentProvider;
  amount: number;
  currency: string;
  status: PaymentStatus;
  transactionId?: string;
  pvitTransactionId?: string;
  phoneNumber?: string;
  failureReason?: string;
  processedAt?: string;
  createdAt: string;
}

// ── AUTH ─────────────────────────────────────────────────────
export interface AuthResponse {
  user: User;
  accessToken: string;
}

export interface LoginForm {
  email: string;
  password: string;
}

export interface RegisterForm {
  name: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  referralCode?: string;
}

// ── CHECKOUT ─────────────────────────────────────────────────
export interface CheckoutForm {
  playerId: string;
  paymentMethod: PaymentProvider;
  phoneNumber?: string;
  promoCode?: string;
  currency: 'XAF' | 'USD' | 'EUR';
}

export interface PromoValidation {
  code: string;
  discountType: 'percent' | 'fixed';
  discountValue: number;
  discountAmount: number;
  finalAmount: number;
}

// ── API ───────────────────────────────────────────────────────
export interface ApiResponse<T = unknown> {
  success: boolean;
  message: string;
  data?: T;
  errors?: Record<string, string>;
  pagination?: Pagination;
}

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

// ── ANALYTICS ────────────────────────────────────────────────
export interface Analytics {
  totalRevenue: number;
  totalDelivered: number;
  totalOrders: number;
  conversionRate: string;
  newUsers: number;
  period: string;
  revenueByDay: { _id: string; revenue: number; orders: number }[];
  topGames: { _id: string; revenue: number; orders: number; game: Game }[];
  statusBreakdown: { _id: OrderStatus; count: number }[];
}
