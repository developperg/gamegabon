import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { format, formatDistanceToNow } from 'date-fns';
import { fr } from 'date-fns/locale';
import type { OrderStatus, PaymentStatus } from '@/types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function fmtXAF(amount: number): string {
  return new Intl.NumberFormat('fr-FR').format(amount) + ' FCFA';
}

export function fmtCurrency(amount: number, currency: string = 'XAF'): string {
  if (currency === 'USD') return '$' + (amount / 490).toFixed(2);
  if (currency === 'EUR') return '€' + (amount / 540).toFixed(2);
  return fmtXAF(amount);
}

export function fmtDate(date: string | Date): string {
  return format(new Date(date), 'dd MMM yyyy', { locale: fr });
}

export function fmtDatetime(date: string | Date): string {
  return format(new Date(date), 'dd MMM yyyy à HH:mm', { locale: fr });
}

export function fmtRelative(date: string | Date): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true, locale: fr });
}

export function truncate(str: string, n: number): string {
  return str.length > n ? str.slice(0, n - 1) + '…' : str;
}

export function slugify(str: string): string {
  return str.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
}

export function getInitials(name: string): string {
  return name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2);
}

// ── Order/Payment status helpers ─────────────────────────────
export const ORDER_STATUS_CONFIG: Record<OrderStatus, { label: string; color: string; bg: string }> = {
  pending:    { label: 'En attente',   color: 'text-yellow-400',  bg: 'bg-yellow-400/10 border-yellow-400/30' },
  processing: { label: 'En cours',     color: 'text-blue-400',    bg: 'bg-blue-400/10 border-blue-400/30' },
  delivered:  { label: 'Livré',        color: 'text-green-400',   bg: 'bg-green-400/10 border-green-400/30' },
  failed:     { label: 'Échoué',       color: 'text-red-400',     bg: 'bg-red-400/10 border-red-400/30' },
  refunded:   { label: 'Remboursé',    color: 'text-purple-400',  bg: 'bg-purple-400/10 border-purple-400/30' },
};

export const PAYMENT_STATUS_CONFIG: Record<PaymentStatus, { label: string; color: string }> = {
  pending:    { label: 'En attente',  color: 'text-yellow-400' },
  processing: { label: 'En cours',    color: 'text-blue-400' },
  success:    { label: 'Succès',      color: 'text-green-400' },
  failed:     { label: 'Échoué',      color: 'text-red-400' },
  refunded:   { label: 'Remboursé',   color: 'text-purple-400' },
};

export const PAYMENT_LABELS: Record<string, string> = {
  pvit_airtel: 'Airtel Money',
  pvit_moov:   'Moov Money',
  card:        'Carte bancaire',
  paypal:      'PayPal',
  usdt:        'USDT Crypto',
};

export const PAYMENT_ICONS: Record<string, string> = {
  pvit_airtel: '📱',
  pvit_moov:   '📲',
  card:        '💳',
  paypal:      '🅿️',
  usdt:        '₿',
};
