import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import Cookies from 'js-cookie';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';

export const api = axios.create({
  baseURL: API_URL,
  timeout: 30000,
  withCredentials: true,
  headers: { 'Content-Type': 'application/json' },
});

// ── REQUEST interceptor: attach access token ──────────────────
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const token = Cookies.get('accessToken') || (typeof window !== 'undefined' ? localStorage.getItem('accessToken') : null);
    if (token && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// ── RESPONSE interceptor: refresh token on 401 ───────────────
let isRefreshing = false;
let failedQueue: { resolve: (token: string) => void; reject: (err: unknown) => void }[] = [];

const processQueue = (error: unknown, token: string | null = null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token!)));
  failedQueue = [];
};

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({
            resolve: (token) => {
              if (originalRequest.headers) originalRequest.headers.Authorization = `Bearer ${token}`;
              resolve(api(originalRequest));
            },
            reject,
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const { data } = await axios.post(`${API_URL}/auth/refresh`, {}, { withCredentials: true });
        const newToken: string = data.data.accessToken;
        Cookies.set('accessToken', newToken, { expires: 1 / 96 }); // 15min
        localStorage.setItem('accessToken', newToken);
        if (originalRequest.headers) originalRequest.headers.Authorization = `Bearer ${newToken}`;
        processQueue(null, newToken);
        return api(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError, null);
        Cookies.remove('accessToken');
        localStorage.removeItem('accessToken');
        if (typeof window !== 'undefined') window.location.href = '/auth/login';
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

// ── API helpers ──────────────────────────────────────────────
export const authApi = {
  register: (data: unknown) => api.post('/auth/register', data),
  login: (data: unknown) => api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  refresh: () => api.post('/auth/refresh'),
  getMe: () => api.get('/auth/me'),
  updateMe: (data: unknown) => api.patch('/auth/me', data),
  forgotPassword: (email: string) => api.post('/auth/forgot-password', { email }),
  resetPassword: (token: string, password: string) => api.post('/auth/reset-password', { token, password }),
};

export const gamesApi = {
  getAll: () => api.get('/games'),
  getBySlug: (slug: string) => api.get(`/games/${slug}`),
};

export const ordersApi = {
  create: (data: unknown) => api.post('/orders', data),
  getAll: (params?: Record<string, unknown>) => api.get('/orders', { params }),
  getById: (id: string) => api.get(`/orders/${id}`),
};

export const promoApi = {
  validate: (data: { code: string; gameId: string; amount: number }) => api.post('/promos/validate', data),
};

// Admin
export const adminApi = {
  getAnalytics: (period?: string) => api.get('/admin/analytics', { params: { period } }),

  getOrders: (params?: Record<string, unknown>) => api.get('/admin/orders', { params }),
  updateOrderStatus: (id: string, data: { status: string; notes?: string }) => api.patch(`/admin/orders/${id}/status`, data),

  getGames: () => api.get('/admin/games'),
  createGame: (data: unknown) => api.post('/admin/games', data),
  updateGame: (id: string, data: unknown) => api.patch(`/admin/games/${id}`, data),
  deleteGame: (id: string) => api.delete(`/admin/games/${id}`),
  createPack: (gameId: string, data: unknown) => api.post(`/admin/games/${gameId}/packs`, data),
  updatePack: (gameId: string, packId: string, data: unknown) => api.patch(`/admin/games/${gameId}/packs/${packId}`, data),
  deletePack: (gameId: string, packId: string) => api.delete(`/admin/games/${gameId}/packs/${packId}`),

  getPromos: () => api.get('/admin/promos'),
  createPromo: (data: unknown) => api.post('/admin/promos', data),
  updatePromo: (id: string, data: unknown) => api.patch(`/admin/promos/${id}`, data),
  deletePromo: (id: string) => api.delete(`/admin/promos/${id}`),

  getUsers: (params?: Record<string, unknown>) => api.get('/admin/users', { params }),
  updateUser: (id: string, data: unknown) => api.patch(`/admin/users/${id}`, data),
  deleteUser: (id: string) => api.delete(`/admin/users/${id}`),

  getPayments: (params?: Record<string, unknown>) => api.get('/admin/payments', { params }),
  refundPayment: (id: string) => api.post(`/admin/payments/${id}/refund`),
};
