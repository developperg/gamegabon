'use client';

import React, { forwardRef, ButtonHTMLAttributes, InputHTMLAttributes, SelectHTMLAttributes } from 'react';
import { cn } from '@/lib/utils';
import { Loader2, X } from 'lucide-react';

// ── BUTTON ───────────────────────────────────────────────────
interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  fullWidth?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', loading, fullWidth, children, className, disabled, ...props }, ref) => {
    const base = 'inline-flex items-center justify-center gap-2 font-bold rounded-xl transition-all duration-200 disabled:opacity-40 disabled:cursor-not-allowed select-none';
    const variants = {
      primary:   'bg-gradient-to-r from-brand-500 to-cyan-500 text-gray-950 hover:from-brand-400 hover:to-cyan-400 shadow-lg shadow-brand-500/25',
      secondary: 'bg-gaming-card2 border border-gaming-border text-white hover:border-brand-500/50',
      ghost:     'text-gray-400 hover:text-white hover:bg-white/5',
      danger:    'bg-gradient-to-r from-red-600 to-red-500 text-white shadow-lg shadow-red-500/20',
      outline:   'border border-brand-500/40 text-brand-400 hover:bg-brand-500/10',
    };
    const sizes = {
      sm: 'text-xs px-3 py-2',
      md: 'text-sm px-4 py-2.5',
      lg: 'text-base px-6 py-3',
    };
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(base, variants[variant], sizes[size], fullWidth && 'w-full', className)}
        {...props}
      >
        {loading && <Loader2 className="h-4 w-4 animate-spin" />}
        {children}
      </button>
    );
  }
);
Button.displayName = 'Button';

// ── INPUT ────────────────────────────────────────────────────
interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  hint?: string;
  leftIcon?: React.ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, hint, leftIcon, className, ...props }, ref) => (
    <div className="w-full">
      {label && <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-1.5">{label}</label>}
      <div className="relative">
        {leftIcon && <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">{leftIcon}</div>}
        <input
          ref={ref}
          className={cn(
            'w-full bg-gaming-card2 border border-gaming-border rounded-xl px-3.5 py-3 text-sm text-white placeholder:text-gray-600',
            'outline-none focus:border-brand-500/60 focus:ring-2 focus:ring-brand-500/20 transition-all',
            error && 'border-red-500/60 focus:border-red-500/60',
            leftIcon && 'pl-10',
            className
          )}
          {...props}
        />
      </div>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
      {hint && !error && <p className="mt-1 text-xs text-gray-500">{hint}</p>}
    </div>
  )
);
Input.displayName = 'Input';

// ── SELECT ───────────────────────────────────────────────────
interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  label?: string;
  error?: string;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(
  ({ label, error, className, children, ...props }, ref) => (
    <div className="w-full">
      {label && <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-1.5">{label}</label>}
      <select
        ref={ref}
        className={cn(
          'w-full bg-gaming-card2 border border-gaming-border rounded-xl px-3.5 py-3 text-sm text-white',
          'outline-none focus:border-brand-500/60 transition-all appearance-none',
          error && 'border-red-500/60',
          className
        )}
        {...props}
      >
        {children}
      </select>
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  )
);
Select.displayName = 'Select';

// ── CARD ─────────────────────────────────────────────────────
interface CardProps {
  children: React.ReactNode;
  className?: string;
  padding?: boolean;
  glow?: string;
}

export function Card({ children, className, padding = true, glow }: CardProps) {
  return (
    <div
      className={cn(
        'bg-gaming-card border border-gaming-border rounded-2xl',
        padding && 'p-5',
        glow && `shadow-lg ${glow}`,
        className
      )}
    >
      {children}
    </div>
  );
}

// ── BADGE ────────────────────────────────────────────────────
export function Badge({
  children,
  variant = 'default',
  className,
}: {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple';
  className?: string;
}) {
  const variants = {
    default: 'bg-white/10 text-white',
    success: 'bg-green-400/10 text-green-400 border border-green-400/30',
    warning: 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/30',
    danger:  'bg-red-400/10 text-red-400 border border-red-400/30',
    info:    'bg-brand-500/10 text-brand-400 border border-brand-500/30',
    purple:  'bg-purple-400/10 text-purple-400 border border-purple-400/30',
  };
  return (
    <span className={cn('inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold', variants[variant], className)}>
      {children}
    </span>
  );
}

// ── SKELETON ─────────────────────────────────────────────────
export function Skeleton({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'animate-pulse rounded-xl bg-gradient-to-r from-gaming-card2 via-gaming-card to-gaming-card2 bg-[length:200%_100%]',
        className
      )}
      style={{ backgroundSize: '200% 100%', animation: 'shimmer 2s linear infinite' }}
    />
  );
}

// ── SPINNER ──────────────────────────────────────────────────
export function Spinner({ size = 'md', className }: { size?: 'sm' | 'md' | 'lg'; className?: string }) {
  const sizes = { sm: 'h-4 w-4', md: 'h-6 w-6', lg: 'h-10 w-10' };
  return <Loader2 className={cn('animate-spin text-brand-500', sizes[size], className)} />;
}

// ── MODAL ────────────────────────────────────────────────────
interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg';
}

export function Modal({ open, onClose, title, children, size = 'md' }: ModalProps) {
  if (!open) return null;
  const sizes = { sm: 'max-w-sm', md: 'max-w-lg', lg: 'max-w-2xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className={cn('relative w-full bg-gaming-card border border-gaming-border rounded-t-3xl sm:rounded-2xl shadow-2xl max-h-[90vh] overflow-y-auto', sizes[size])}>
        {title && (
          <div className="flex items-center justify-between p-5 border-b border-gaming-border">
            <h2 className="text-lg font-bold">{title}</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors"><X className="h-5 w-5" /></button>
          </div>
        )}
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

// ── STAT CARD ────────────────────────────────────────────────
export function StatCard({
  label,
  value,
  icon,
  color = 'text-brand-400',
  subtext,
}: {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color?: string;
  subtext?: string;
}) {
  return (
    <Card className="flex items-center gap-4">
      <div className={cn('p-3 rounded-xl bg-white/5', color)}>{icon}</div>
      <div>
        <div className={cn('text-xl font-extrabold', color)}>{value}</div>
        <div className="text-xs text-gray-500 mt-0.5">{label}</div>
        {subtext && <div className="text-xs text-gray-600 mt-0.5">{subtext}</div>}
      </div>
    </Card>
  );
}

// ── CONFIRM DIALOG ───────────────────────────────────────────
export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = 'Confirmer',
  loading,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  loading?: boolean;
}) {
  return (
    <Modal open={open} onClose={onClose} size="sm">
      <div className="text-center">
        <div className="text-5xl mb-4">⚠️</div>
        <h3 className="text-lg font-bold mb-2">{title}</h3>
        <p className="text-sm text-gray-400 mb-6">{message}</p>
        <div className="flex gap-3">
          <Button variant="secondary" fullWidth onClick={onClose}>Annuler</Button>
          <Button variant="danger" fullWidth onClick={onConfirm} loading={loading}>{confirmLabel}</Button>
        </div>
      </div>
    </Modal>
  );
}

// ── EMPTY STATE ──────────────────────────────────────────────
export function EmptyState({ icon = '📭', title, description, action }: {
  icon?: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-5xl mb-4">{icon}</div>
      <h3 className="text-lg font-bold text-gray-300 mb-2">{title}</h3>
      {description && <p className="text-sm text-gray-500 mb-6 max-w-xs">{description}</p>}
      {action}
    </div>
  );
}

// ── PROGRESS BAR ─────────────────────────────────────────────
export function ProgressBar({ value, max, color = '#00e5ff' }: { value: number; max: number; color?: string }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="h-1.5 bg-gaming-border rounded-full overflow-hidden">
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: color }} />
    </div>
  );
}

// ── TABS ─────────────────────────────────────────────────────
export function Tabs({
  tabs,
  active,
  onChange,
}: {
  tabs: { id: string; label: string; icon?: string }[];
  active: string;
  onChange: (id: string) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
      {tabs.map((t) => (
        <button
          key={t.id}
          onClick={() => onChange(t.id)}
          className={cn(
            'flex-shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold border transition-all',
            active === t.id
              ? 'bg-brand-500/15 border-brand-500/60 text-brand-400'
              : 'border-gaming-border text-gray-500 hover:text-gray-300'
          )}
        >
          {t.icon && <span>{t.icon}</span>}
          {t.label}
        </button>
      ))}
    </div>
  );
}
