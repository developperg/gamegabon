'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth.store';
import { Spinner } from '@/components/ui';

interface ProtectedRouteProps {
  children: React.ReactNode;
  adminOnly?: boolean;
}

export function ProtectedRoute({ children, adminOnly }: ProtectedRouteProps) {
  const router = useRouter();
  const { isAuthenticated, user, isLoading, fetchMe } = useAuthStore();

  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      fetchMe().catch(() => router.push('/auth/login'));
    }
  }, [isAuthenticated, isLoading, fetchMe, router]);

  useEffect(() => {
    if (isAuthenticated && adminOnly && user?.role !== 'admin') {
      router.push('/dashboard');
    }
  }, [isAuthenticated, adminOnly, user, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gaming-bg flex items-center justify-center">
        <div className="text-center">
          <Spinner size="lg" className="mx-auto mb-4" />
          <p className="text-sm text-gray-500">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) return null;
  if (adminOnly && user?.role !== 'admin') return null;

  return <>{children}</>;
}
