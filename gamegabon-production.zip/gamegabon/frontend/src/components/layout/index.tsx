'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, ChevronDown, Bell, LogOut, User, LayoutDashboard, ShoppingBag, Gamepad2, Settings, CreditCard } from 'lucide-react';
import { useState } from 'react';
import { useAuthStore } from '@/store/auth.store';
import { useLogout } from '@/hooks/index';
import { cn, getInitials } from '@/lib/utils';

// ── TOP NAV (public landing) ─────────────────────────────────
export function PublicHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { isAuthenticated, user } = useAuthStore();

  return (
    <header className="fixed top-0 inset-x-0 z-50 border-b border-gaming-border bg-gaming-bg/90 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-xl font-black text-gray-950">G</div>
          <div>
            <div className="text-sm font-black leading-none">GameTopUp</div>
            <div className="text-[9px] text-brand-400 font-bold tracking-widest">GABON</div>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-1">
          {[['/', 'Accueil'], ['/games', 'Jeux'], ['/pricing', 'Tarifs']].map(([href, label]) => (
            <Link key={href} href={href} className="px-3 py-1.5 text-sm font-medium text-gray-400 hover:text-white rounded-lg hover:bg-white/5 transition-all">
              {label}
            </Link>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          {isAuthenticated ? (
            <Link href={user?.role === 'admin' ? '/admin' : '/dashboard'}
              className="px-4 py-2 bg-gradient-to-r from-brand-500 to-cyan-400 text-gray-950 font-bold text-sm rounded-xl hover:opacity-90 transition">
              Dashboard →
            </Link>
          ) : (
            <>
              <Link href="/auth/login" className="text-sm font-medium text-gray-400 hover:text-white transition">Se connecter</Link>
              <Link href="/auth/register" className="px-4 py-2 bg-gradient-to-r from-brand-500 to-cyan-400 text-gray-950 font-bold text-sm rounded-xl hover:opacity-90 transition">
                Commencer
              </Link>
            </>
          )}
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-gray-400" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden border-t border-gaming-border bg-gaming-card px-4 py-4 space-y-2">
          {[['/', 'Accueil'], ['/games', 'Jeux'], ['/pricing', 'Tarifs']].map(([href, label]) => (
            <Link key={href} href={href} onClick={() => setMobileOpen(false)} className="block px-3 py-2.5 text-sm font-medium text-gray-300 hover:text-white rounded-lg hover:bg-white/5">
              {label}
            </Link>
          ))}
          <div className="pt-2 border-t border-gaming-border flex flex-col gap-2">
            <Link href="/auth/login" className="block text-center py-2.5 text-sm font-medium text-gray-300 border border-gaming-border rounded-xl">Se connecter</Link>
            <Link href="/auth/register" className="block text-center py-2.5 text-sm font-bold bg-gradient-to-r from-brand-500 to-cyan-400 text-gray-950 rounded-xl">Commencer</Link>
          </div>
        </div>
      )}
    </header>
  );
}

// ── APP HEADER (dashboard) ───────────────────────────────────
export function AppHeader({ onMenuToggle }: { onMenuToggle?: () => void }) {
  const { user } = useAuthStore();
  const { mutate: logout } = useLogout();
  const [userMenuOpen, setUserMenuOpen] = useState(false);

  return (
    <header className="h-14 border-b border-gaming-border bg-gaming-bg/90 backdrop-blur-xl flex items-center justify-between px-4 sticky top-0 z-40">
      <div className="flex items-center gap-3">
        {onMenuToggle && (
          <button onClick={onMenuToggle} className="md:hidden text-gray-400 hover:text-white p-1"><Menu className="h-5 w-5" /></button>
        )}
        <Link href="/" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-sm font-black text-gray-950">G</div>
          <span className="text-sm font-black hidden sm:block">GameTopUp<span className="text-brand-400"> Gabon</span></span>
        </Link>
      </div>

      <div className="flex items-center gap-2">
        <button className="p-2 text-gray-400 hover:text-white transition"><Bell className="h-4 w-4" /></button>
        <div className="relative">
          <button onClick={() => setUserMenuOpen(!userMenuOpen)} className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-xl hover:bg-white/5 transition">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-xs font-black text-gray-950">
              {getInitials(user?.name || 'U')}
            </div>
            <span className="text-sm font-medium hidden sm:block">{user?.name?.split(' ')[0]}</span>
            <ChevronDown className="h-3 w-3 text-gray-500" />
          </button>
          {userMenuOpen && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setUserMenuOpen(false)} />
              <div className="absolute right-0 top-full mt-1 w-52 bg-gaming-card border border-gaming-border rounded-xl shadow-xl z-20 overflow-hidden">
                <div className="px-3 py-2.5 border-b border-gaming-border">
                  <div className="text-sm font-bold">{user?.name}</div>
                  <div className="text-xs text-gray-500">{user?.email}</div>
                </div>
                <div className="p-1">
                  <Link href="/dashboard" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/5 rounded-lg"><LayoutDashboard className="h-4 w-4" />Dashboard</Link>
                  <Link href="/dashboard/profile" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 px-3 py-2 text-sm text-gray-300 hover:text-white hover:bg-white/5 rounded-lg"><User className="h-4 w-4" />Profil</Link>
                  <button onClick={() => logout()} className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-400 hover:bg-red-400/10 rounded-lg"><LogOut className="h-4 w-4" />Déconnexion</button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

// ── SIDEBAR ──────────────────────────────────────────────────
const clientNav = [
  { href: '/dashboard',         icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/games',              icon: Gamepad2,        label: 'Recharger' },
  { href: '/dashboard/orders',   icon: ShoppingBag,     label: 'Mes commandes' },
  { href: '/dashboard/profile',  icon: User,            label: 'Profil' },
];

const adminNav = [
  { href: '/admin',              icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/admin/orders',       icon: ShoppingBag,     label: 'Commandes' },
  { href: '/admin/games',        icon: Gamepad2,        label: 'Jeux & Packs' },
  { href: '/admin/users',        icon: User,            label: 'Utilisateurs' },
  { href: '/admin/promos',       icon: Settings,        label: 'Promotions' },
  { href: '/admin/payments',     icon: CreditCard,      label: 'Paiements' },
];

export function Sidebar({ mobile, onClose }: { mobile?: boolean; onClose?: () => void }) {
  const pathname = usePathname();
  const { user } = useAuthStore();
  const nav = user?.role === 'admin' ? adminNav : clientNav;

  return (
    <aside className={cn(
      'w-56 bg-gaming-card border-r border-gaming-border flex flex-col',
      mobile ? 'h-full' : 'hidden md:flex h-screen sticky top-0'
    )}>
      {/* Logo */}
      <div className="h-14 flex items-center px-4 border-b border-gaming-border">
        <Link href="/" className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-sm font-black text-gray-950">G</div>
          <span className="text-sm font-black">GameTopUp<span className="text-brand-400"> Gabon</span></span>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {nav.map(({ href, icon: Icon, label }) => {
          const active = pathname === href || (href !== '/dashboard' && href !== '/admin' && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              onClick={onClose}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                active
                  ? 'bg-brand-500/15 text-brand-400 border border-brand-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              )}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              {label}
              {active && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-brand-400" />}
            </Link>
          );
        })}
      </nav>

      {/* User info bottom */}
      <div className="p-3 border-t border-gaming-border">
        <div className="flex items-center gap-2.5 px-2 py-1.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-sm font-black text-gray-950 flex-shrink-0">
            {getInitials(user?.name || 'U')}
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold truncate">{user?.name}</div>
            <div className="text-[10px] text-gray-500 truncate capitalize">{user?.role}</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
