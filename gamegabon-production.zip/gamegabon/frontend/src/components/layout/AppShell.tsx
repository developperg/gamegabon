'use client';

import { useState } from 'react';
import { X } from 'lucide-react';
import { AppHeader, Sidebar } from './index';
import { cn } from '@/lib/utils';

export function AppShell({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gaming-bg flex">
      {/* Desktop sidebar */}
      <Sidebar />

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <>
          <div className="fixed inset-0 z-40 bg-black/60 md:hidden" onClick={() => setSidebarOpen(false)} />
          <div className="fixed inset-y-0 left-0 z-50 w-56 md:hidden">
            <div className="relative h-full">
              <button
                onClick={() => setSidebarOpen(false)}
                className="absolute -right-10 top-3 p-2 text-gray-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
              <Sidebar mobile onClose={() => setSidebarOpen(false)} />
            </div>
          </div>
        </>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        <AppHeader onMenuToggle={() => setSidebarOpen(true)} />
        <main className={cn('flex-1 p-4 md:p-6 max-w-7xl w-full mx-auto')}>
          {children}
        </main>
      </div>
    </div>
  );
}
