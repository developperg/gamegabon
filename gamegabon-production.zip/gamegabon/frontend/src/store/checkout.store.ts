import { create } from 'zustand';
import type { Game, Pack, PromoValidation } from '@/types';

interface CheckoutState {
  game: Game | null;
  pack: Pack | null;
  playerId: string;
  paymentMethod: string;
  phoneNumber: string;
  currency: 'XAF' | 'USD' | 'EUR';
  promoCode: string;
  promoValidation: PromoValidation | null;
  step: 1 | 2 | 3 | 4;

  setGame: (game: Game) => void;
  setPack: (pack: Pack) => void;
  setPlayerId: (id: string) => void;
  setPaymentMethod: (method: string) => void;
  setPhoneNumber: (phone: string) => void;
  setCurrency: (c: 'XAF' | 'USD' | 'EUR') => void;
  setPromoCode: (code: string) => void;
  setPromoValidation: (promo: PromoValidation | null) => void;
  setStep: (step: 1 | 2 | 3 | 4) => void;
  reset: () => void;

  getFinalAmount: () => number;
}

const defaultState = {
  game: null,
  pack: null,
  playerId: '',
  paymentMethod: '',
  phoneNumber: '',
  currency: 'XAF' as const,
  promoCode: '',
  promoValidation: null,
  step: 1 as const,
};

export const useCheckoutStore = create<CheckoutState>((set, get) => ({
  ...defaultState,

  setGame: (game) => set({ game, pack: null, promoValidation: null, promoCode: '' }),
  setPack: (pack) => set({ pack }),
  setPlayerId: (playerId) => set({ playerId }),
  setPaymentMethod: (paymentMethod) => set({ paymentMethod }),
  setPhoneNumber: (phoneNumber) => set({ phoneNumber }),
  setCurrency: (currency) => set({ currency }),
  setPromoCode: (promoCode) => set({ promoCode }),
  setPromoValidation: (promoValidation) => set({ promoValidation }),
  setStep: (step) => set({ step }),
  reset: () => set(defaultState),

  getFinalAmount: () => {
    const { pack, promoValidation, currency } = get();
    if (!pack) return 0;
    const basePrice =
      currency === 'USD' ? pack.priceUSD :
      currency === 'EUR' ? pack.priceEUR :
      pack.priceXAF;
    if (promoValidation) return promoValidation.finalAmount;
    return basePrice;
  },
}));
