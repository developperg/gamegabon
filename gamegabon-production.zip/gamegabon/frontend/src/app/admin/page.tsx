'use client';

import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Package, TrendingUp, Users, Clock } from 'lucide-react';
import { useAnalytics, useAdminOrders } from '@/hooks/index';
import { Card, StatCard, Badge, Skeleton, Tabs } from '@/components/ui';
import { fmtXAF, fmtDate, ORDER_STATUS_CONFIG } from '@/lib/utils';
import type { Order, Game } from '@/types';

const PERIOD_TABS = [
  { id: '7d', label: '7 jours' },
  { id: '30d', label: '30 jours' },
  { id: '90d', label: '90 jours' },
];

const STATUS_COLORS: Record<string, string> = {
  delivered: '#00e676',
  pending: '#fbbf24',
  processing: '#60a5fa',
  failed: '#f87171',
  refunded: '#c084fc',
};

export default function AdminDashboardPage() {
  const [period, setPeriod] = useState<'7d' | '30d' | '90d'>('30d');
  const { data: analytics, isLoading } = useAnalytics(period);
  const { data: recentOrdersData } = useAdminOrders({ limit: 8 });
  const recentOrders: Order[] = recentOrdersData?.data || [];

  if (isLoading) {
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
        </div>
        <Skeleton className="h-64 rounded-2xl" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-up">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-black">Dashboard Admin</h1>
        <Tabs tabs={PERIOD_TABS} active={period} onChange={(id) => setPeriod(id as '7d' | '30d' | '90d')} />
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Revenus" value={fmtXAF(analytics?.totalRevenue || 0)} icon={<TrendingUp className="h-5 w-5" />} color="text-green-400"
          subtext={`${analytics?.totalDelivered || 0} livrées`} />
        <StatCard label="Commandes" value={analytics?.totalOrders || 0} icon={<Package className="h-5 w-5" />} color="text-brand-400"
          subtext={`${analytics?.conversionRate || 0}% conversion`} />
        <StatCard label="Nouveaux clients" value={analytics?.newUsers || 0} icon={<Users className="h-5 w-5" />} color="text-yellow-400" />
        <StatCard label="En attente" value={(analytics?.statusBreakdown || []).find(s => s._id === 'pending')?.count || 0}
          icon={<Clock className="h-5 w-5" />} color="text-red-400" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Revenue chart */}
        <Card className="lg:col-span-2">
          <h2 className="font-black text-sm mb-5">📈 Revenus par jour</h2>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={analytics?.revenueByDay || []} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
              <XAxis dataKey="_id" tick={{ fill: '#526080', fontSize: 10 }} axisLine={false} tickLine={false}
                tickFormatter={(v: string) => v.slice(5)} />
              <YAxis tick={{ fill: '#526080', fontSize: 10 }} axisLine={false} tickLine={false}
                tickFormatter={(v: number) => `${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ background: '#0d1420', border: '1px solid #1c2840', borderRadius: 10, fontSize: 12 }}
                formatter={(v: number) => [fmtXAF(v), 'Revenus']}
              />
              <Bar dataKey="revenue" fill="#00e5ff" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Status pie */}
        <Card>
          <h2 className="font-black text-sm mb-4">📊 Statuts commandes</h2>
          <ResponsiveContainer width="100%" height={140}>
            <PieChart>
              <Pie data={analytics?.statusBreakdown || []} dataKey="count" nameKey="_id" innerRadius={40} outerRadius={60}>
                {(analytics?.statusBreakdown || []).map((s) => (
                  <Cell key={s._id} fill={STATUS_COLORS[s._id] || '#526080'} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ background: '#0d1420', border: '1px solid #1c2840', borderRadius: 10, fontSize: 12 }}
                formatter={(v: number, n: string) => [v, ORDER_STATUS_CONFIG[n as keyof typeof ORDER_STATUS_CONFIG]?.label || n]}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {(analytics?.statusBreakdown || []).map((s) => (
              <div key={s._id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ background: STATUS_COLORS[s._id] }} />
                  <span className="text-gray-400">{ORDER_STATUS_CONFIG[s._id as keyof typeof ORDER_STATUS_CONFIG]?.label || s._id}</span>
                </div>
                <span className="font-bold">{s.count}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Top games */}
      {(analytics?.topGames || []).length > 0 && (
        <Card>
          <h2 className="font-black text-sm mb-4">🏆 Top jeux par revenus</h2>
          <div className="space-y-3">
            {analytics!.topGames.map((g, i) => (
              <div key={g._id} className="flex items-center gap-3">
                <span className="text-xs font-black text-gray-500 w-4">#{i + 1}</span>
                <span className="text-xl">{g.game?.icon || '🎮'}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold truncate">{g.game?.name}</span>
                    <span className="font-black text-green-400 ml-2">{fmtXAF(g.revenue)}</span>
                  </div>
                  <div className="h-1.5 bg-gaming-border rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-brand-500 to-cyan-400 transition-all"
                      style={{ width: `${analytics!.totalRevenue > 0 ? Math.max(5, (g.revenue / analytics!.totalRevenue) * 100) : 0}%` }} />
                  </div>
                </div>
                <span className="text-xs text-gray-500 w-16 text-right">{g.orders} cmd</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Recent orders */}
      <Card padding={false}>
        <div className="px-5 py-4 border-b border-gaming-border flex justify-between items-center">
          <h2 className="font-black text-sm">Commandes récentes</h2>
          <a href="/admin/orders" className="text-xs text-brand-400 hover:text-brand-300 transition">Voir tout →</a>
        </div>
        <div className="divide-y divide-gaming-border">
          {recentOrders.map((o: Order) => {
            const game = (o.game || o.gameId) as Game;
            const cfg = ORDER_STATUS_CONFIG[o.status];
            return (
              <div key={o._id} className="flex items-center gap-3 px-5 py-3 hover:bg-white/2 transition">
                <span className="text-xl flex-shrink-0">{game?.icon || '🎮'}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold truncate">{(o.user as any)?.name || '—'}</div>
                  <div className="text-[10px] text-gray-500">{game?.name} · {fmtDate(o.createdAt)}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-bold">{fmtXAF(o.finalAmount)}</div>
                  <Badge variant={o.status === 'delivered' ? 'success' : o.status === 'failed' ? 'danger' : 'warning'} className="text-[10px]">{cfg.label}</Badge>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
