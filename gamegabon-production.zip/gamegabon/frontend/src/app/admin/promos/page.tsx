'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, Edit2, Trash2, Power, PowerOff, Tag } from 'lucide-react';
import { useAdminPromos, useAdminGames, useDeletePromo } from '@/hooks/index';
import { adminApi } from '@/lib/api';
import { useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { Card, Badge, Skeleton, EmptyState, Button, Modal, ConfirmDialog, Input, Select, ProgressBar } from '@/components/ui';
import { fmtDate } from '@/lib/utils';
import type { Promo, Game } from '@/types';

const promoSchema = z.object({
  code:          z.string().min(2, 'Minimum 2 caractères').toUpperCase(),
  discountType:  z.enum(['percent', 'fixed']),
  discountValue: z.number().positive('Valeur positive requise'),
  minAmount:     z.number().min(0),
  maxDiscount:   z.number().optional(),
  maxUses:       z.number().int().positive('Minimum 1'),
  expiresAt:     z.string().optional(),
  games:         z.string(),
});
type PromoFormData = z.infer<typeof promoSchema>;

function PromoForm({ promo, games, onClose }: { promo?: Promo; games: Game[]; onClose: () => void }) {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const { register, handleSubmit, watch, formState: { errors } } = useForm<PromoFormData>({
    resolver: zodResolver(promoSchema),
    defaultValues: {
      code:          promo?.code          || '',
      discountType:  promo?.discountType  || 'percent',
      discountValue: promo?.discountValue || 10,
      minAmount:     promo?.minAmount     || 0,
      maxDiscount:   promo?.maxDiscount,
      maxUses:       promo?.maxUses       || 100,
      expiresAt:     promo?.expiresAt     ? promo.expiresAt.slice(0, 10) : '',
      games:         Array.isArray(promo?.applicableGames) ? promo!.applicableGames[0] : (promo?.applicableGames as string) || 'all',
    },
  });
  const discountType = watch('discountType');

  const onSubmit = async (data: PromoFormData) => {
    setSaving(true);
    const payload = { ...data, code: data.code.toUpperCase(), applicableGames: data.games, expiresAt: data.expiresAt || null };
    try {
      if (promo) await adminApi.updatePromo(promo._id, payload);
      else        await adminApi.createPromo(payload);
      toast.success(promo ? 'Promo modifiée' : 'Promo créée');
      qc.invalidateQueries({ queryKey: ['admin-promos'] });
      onClose();
    } catch { toast.error('Erreur lors de l\'enregistrement'); }
    finally { setSaving(false); }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Input label="Code promo" placeholder="ex: GABON20" error={errors.code?.message}
        {...register('code')} className="uppercase" />

      <Select label="Type de réduction" error={errors.discountType?.message} {...register('discountType')}>
        <option value="percent">% Pourcentage</option>
        <option value="fixed">FCFA Montant fixe</option>
      </Select>

      <div className="grid grid-cols-2 gap-3">
        <Input label={discountType === 'percent' ? 'Réduction (%)' : 'Réduction (FCFA)'}
          type="number" step={discountType === 'percent' ? '1' : '100'}
          error={errors.discountValue?.message} {...register('discountValue', { valueAsNumber: true })} />
        {discountType === 'percent' && (
          <Input label="Réduction max (FCFA)" type="number" placeholder="Optionnel"
            {...register('maxDiscount', { valueAsNumber: true })} />
        )}
        <Input label="Montant min (FCFA)" type="number" error={errors.minAmount?.message}
          {...register('minAmount', { valueAsNumber: true })} />
        <Input label="Nb. utilisations max" type="number" error={errors.maxUses?.message}
          {...register('maxUses', { valueAsNumber: true })} />
      </div>

      <Input label="Date d'expiration (optionnel)" type="date" {...register('expiresAt')} />

      <Select label="Jeux concernés" {...register('games')}>
        <option value="all">Tous les jeux</option>
        {games.map((g: Game) => <option key={g._id} value={g._id}>{g.icon} {g.name}</option>)}
      </Select>

      <div className="flex gap-3 pt-2">
        <Button type="button" variant="secondary" fullWidth onClick={onClose}>Annuler</Button>
        <Button type="submit" fullWidth loading={saving}>{promo ? 'Modifier' : 'Créer'}</Button>
      </div>
    </form>
  );
}

export default function AdminPromosPage() {
  const qc = useQueryClient();
  const { data: promos, isLoading } = useAdminPromos();
  const { data: games }             = useAdminGames();
  const { mutate: deletePromo, isPending: deleting } = useDeletePromo();

  const [promoModal, setPromoModal]   = useState<{ open: boolean; promo?: Promo }>({ open: false });
  const [deletingPromo, setDeletingPromo] = useState<Promo | null>(null);

  const toggleActive = async (p: Promo) => {
    try {
      await adminApi.updatePromo(p._id, { active: !p.active });
      qc.invalidateQueries({ queryKey: ['admin-promos'] });
      toast.success(p.active ? 'Promo désactivée' : 'Promo activée');
    } catch { toast.error('Erreur'); }
  };

  return (
    <div className="space-y-5 animate-fade-up">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black">Promotions</h1>
        <Button onClick={() => setPromoModal({ open: true })}>
          <Plus className="h-4 w-4" /> Créer une promo
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
      ) : !promos || promos.length === 0 ? (
        <EmptyState icon="🎁" title="Aucune promotion" description="Créez votre première promotion pour attirer plus de clients."
          action={<Button onClick={() => setPromoModal({ open: true })}>Créer une promo</Button>} />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {(promos as Promo[]).map((p: Promo) => {
            const usePct = p.maxUses > 0 ? (p.uses / p.maxUses) * 100 : 0;
            const expired = p.expiresAt ? new Date(p.expiresAt) < new Date() : false;
            const gameLabel = p.applicableGames === 'all'
              ? 'Tous les jeux'
              : (games as Game[] || []).find((g: Game) => g._id === (Array.isArray(p.applicableGames) ? p.applicableGames[0] : p.applicableGames))?.name || '—';

            return (
              <Card key={p._id}>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Tag className="h-4 w-4 text-brand-400" />
                    <span className="font-black text-xl tracking-widest text-brand-400">{p.code}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Badge variant={p.active && !expired ? 'success' : 'danger'}>
                      {expired ? '⏱ Expirée' : p.active ? '✓ Active' : '✗ Inactive'}
                    </Badge>
                  </div>
                </div>

                <div className="text-2xl font-black mb-1" style={{ color: p.discountType === 'percent' ? '#fbbf24' : '#00e676' }}>
                  -{p.discountValue}{p.discountType === 'percent' ? '%' : ' FCFA'}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-gray-400 mb-3">
                  <div>Jeu: <span className="text-white font-medium">{gameLabel}</span></div>
                  <div>Min: <span className="text-white font-medium">{p.minAmount ? `${p.minAmount} FCFA` : 'Aucun'}</span></div>
                  <div>Expire: <span className="text-white font-medium">{p.expiresAt ? fmtDate(p.expiresAt) : 'Jamais'}</span></div>
                  <div>Utilisé: <span className="text-white font-medium">{p.uses}/{p.maxUses}</span></div>
                </div>

                <ProgressBar value={p.uses} max={p.maxUses} color={usePct >= 90 ? '#f87171' : '#00e5ff'} />
                <div className="text-xs text-gray-500 mt-1 mb-4">{Math.round(usePct)}% des utilisations</div>

                <div className="flex gap-2">
                  <Button variant="secondary" size="sm" className="flex-1" onClick={() => setPromoModal({ open: true, promo: p })}>
                    <Edit2 className="h-3.5 w-3.5" /> Modifier
                  </Button>
                  <button onClick={() => toggleActive(p)}
                    className={`p-2 rounded-xl border transition ${p.active ? 'border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10' : 'border-green-500/40 text-green-400 hover:bg-green-500/10'}`}>
                    {p.active ? <PowerOff className="h-3.5 w-3.5" /> : <Power className="h-3.5 w-3.5" />}
                  </button>
                  <button onClick={() => setDeletingPromo(p)} className="p-2 rounded-xl border border-red-500/40 text-red-400 hover:bg-red-500/10 transition">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={promoModal.open} onClose={() => setPromoModal({ open: false })}
        title={promoModal.promo ? `Modifier — ${promoModal.promo.code}` : 'Créer une promotion'} size="md">
        <PromoForm promo={promoModal.promo} games={games as Game[] || []} onClose={() => setPromoModal({ open: false })} />
      </Modal>

      <ConfirmDialog
        open={!!deletingPromo}
        onClose={() => setDeletingPromo(null)}
        onConfirm={() => { if (deletingPromo) { deletePromo(deletingPromo._id); setDeletingPromo(null); } }}
        title={`Supprimer le code ${deletingPromo?.code} ?`}
        message="Cette action est irréversible."
        confirmLabel="Supprimer"
        loading={deleting}
      />
    </div>
  );
}
