'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { Card, Badge, Skeleton, Tabs, Button, ConfirmDialog } from '@/components/ui';
import { fmtXAF, fmtDate, PAYMENT_LABELS, PAYMENT_ICONS } from '@/lib/utils';
import type { Payment } from '@/types';
import toast from 'react-hot-toast';

const STATUS_TABS = [
  { id: 'all',        label: 'Tous'          },
  { id: 'success',    label: '✓ Succès'      },
  { id: 'processing', label: '⚙️ En cours'   },
  { id: 'pending',    label: '⏳ En attente'  },
  { id: 'failed',     label: '✗ Échoués'    },
  { id: 'refunded',   label: '↩ Remboursés' },
];

const PROVIDER_TABS = [
  { id: 'all',         label: 'Tous'       },
  { id: 'pvit_airtel', label: '📱 Airtel'  },
  { id: 'pvit_moov',   label: '📲 Moov'    },
  { id: 'card',        label: '💳 Carte'   },
  { id: 'paypal',      label: '🅿️ PayPal'  },
  { id: 'usdt',        label: '₿ USDT'    },
];

const STATUS_BADGE_MAP: Record<string, 'success' | 'warning' | 'danger' | 'info' | 'purple'> = {
  success:    'success',
  processing: 'info',
  pending:    'warning',
  failed:     'danger',
  refunded:   'purple',
};

const STATUS_LABEL_MAP: Record<string, string> = {
  success:    '✓ Succès',
  processing: '⚙️ En cours',
  pending:    '⏳ En attente',
  failed:     '✗ Échoué',
  refunded:   '↩ Remboursé',
};

interface PaymentApiResponse {
  data: Payment[];
  pagination: { total: number; totalPages: number } | null;
  stats: { _id: string; total: number; count: number }[];
}

export default function AdminPaymentsPage() {
  const qc = useQueryClient();
  const [statusFilter,   setStatusFilter]   = useState('all');
  const [providerFilter, setProviderFilter] = useState('all');
  const [page,           setPage]           = useState(1);
  const [refundTarget,   setRefundTarget]   = useState<string | null>(null);

  const { data, isLoading } = useQuery<PaymentApiResponse>({
    queryKey: ['admin-payments', statusFilter, providerFilter, page],
    queryFn: async () => {
      const params: Record<string, unknown> = { page, limit: 15 };
      if (statusFilter   !== 'all') params.status   = statusFilter;
      if (providerFilter !== 'all') params.provider = providerFilter;
      const res = await adminApi.getPayments(params);
      return res.data as PaymentApiResponse;
    },
  });

  const { mutate: refundPayment, isPending: refunding } = useMutation({
    mutationFn: (id: string) => adminApi.refundPayment(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-payments'] });
      qc.invalidateQueries({ queryKey: ['analytics'] });
      toast.success('Remboursement effectué avec succès');
      setRefundTarget(null);
    },
    onError: () => toast.error('Erreur lors du remboursement'),
  });

  const payments   = data?.data        || [];
  const pagination = data?.pagination;
  const stats      = data?.stats       || [];
  const totalRev   = stats.reduce((s, x) => s + x.total, 0);
  const totalTx    = stats.reduce((s, x) => s + x.count, 0);

  return (
    <div className="space-y-5 animate-fade-up">
      <h1 className="text-2xl font-black">Paiements</h1>

      {/* Revenue summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Card className="bg-gradient-to-br from-green-500/10 to-gaming-card border-green-500/20">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs text-green-400 font-bold uppercase tracking-widest">Revenus totaux</div>
              <div className="text-2xl font-black text-green-400 mt-1">{fmtXAF(totalRev)}</div>
              <div className="text-xs text-gray-500 mt-0.5">{totalTx} transactions réussies</div>
            </div>
            <div className="text-4xl opacity-20">💰</div>
          </div>
        </Card>

        {/* Stats by provider */}
        <div className="grid grid-cols-3 gap-2">
          {stats.slice(0, 3).map((s) => (
            <Card key={s._id} className="text-center p-3">
              <div className="text-xl mb-1">{PAYMENT_ICONS[s._id] || '💳'}</div>
              <div className="font-black text-xs text-green-400">{fmtXAF(s.total)}</div>
              <div className="text-[10px] text-gray-500 mt-0.5">{PAYMENT_LABELS[s._id] || s._id}</div>
              <div className="text-[9px] text-gray-600">{s.count} tx</div>
            </Card>
          ))}
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-2">
        <Tabs tabs={STATUS_TABS}   active={statusFilter}   onChange={(id) => { setStatusFilter(id);   setPage(1); }} />
        <Tabs tabs={PROVIDER_TABS} active={providerFilter} onChange={(id) => { setProviderFilter(id); setPage(1); }} />
      </div>

      {/* Payments table */}
      <Card padding={false}>
        {isLoading ? (
          <div className="p-4 space-y-3">
            {Array.from({ length: 7 }).map((_, i) => (
              <Skeleton key={i} className="h-14 rounded-xl" />
            ))}
          </div>
        ) : payments.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-gray-500">
            <div className="text-5xl mb-3">📭</div>
            <p className="text-sm">Aucun paiement pour ces filtres.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gaming-border text-xs text-gray-500 font-bold uppercase tracking-wider">
                  {['Référence', 'Client', 'Montant', 'Méthode', 'Téléphone', 'Statut', 'Date', 'Actions'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gaming-border">
                {payments.map((p) => {
                  const userPop  = (p as unknown as { userId: { name?: string; email?: string } }).userId;
                  const orderPop = (p as unknown as { orderId: { orderNumber?: string } }).orderId;
                  return (
                    <tr key={p._id} className="hover:bg-white/2 transition">
                      <td className="px-4 py-3">
                        <div className="font-mono text-xs text-brand-400 truncate max-w-[150px]">
                          {p.pvitTransactionId || p.transactionId || `…${p._id.slice(-8)}`}
                        </div>
                        {orderPop?.orderNumber && (
                          <div className="text-[10px] text-gray-500 mt-0.5">#{orderPop.orderNumber}</div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="font-medium whitespace-nowrap">{userPop?.name || '—'}</div>
                        <div className="text-xs text-gray-500 truncate max-w-[160px]">{userPop?.email || ''}</div>
                      </td>
                      <td className="px-4 py-3 font-black whitespace-nowrap text-yellow-400">
                        {fmtXAF(p.amount)}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{PAYMENT_ICONS[p.provider] || '💳'}</span>
                          <span className="text-xs text-gray-300">{PAYMENT_LABELS[p.provider] || p.provider}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-400">{p.phoneNumber || '—'}</td>
                      <td className="px-4 py-3">
                        <Badge variant={STATUS_BADGE_MAP[p.status] || 'info'}>
                          {STATUS_LABEL_MAP[p.status] || p.status}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">
                        {fmtDate(p.createdAt)}
                        {p.processedAt && (
                          <div className="text-[10px] text-gray-600">Traité: {fmtDate(p.processedAt)}</div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {p.status === 'success' && (
                          <button
                            onClick={() => setRefundTarget(p._id)}
                            className="text-xs px-2.5 py-1 rounded-lg border border-purple-500/40 text-purple-400 hover:bg-purple-500/10 transition whitespace-nowrap"
                          >
                            ↩ Rembourser
                          </button>
                        )}
                        {p.status === 'failed' && p.failureReason && (
                          <span className="text-xs text-red-400/60 italic truncate max-w-[120px] block">
                            {p.failureReason}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">{pagination.total} paiements au total</span>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
              ← Précédent
            </Button>
            <span className="text-xs text-gray-400 px-3 py-1.5 bg-gaming-card border border-gaming-border rounded-lg">
              {page} / {pagination.totalPages}
            </span>
            <Button variant="secondary" size="sm" disabled={page === pagination.totalPages} onClick={() => setPage((p) => p + 1)}>
              Suivant →
            </Button>
          </div>
        </div>
      )}

      {/* Confirm refund dialog */}
      <ConfirmDialog
        open={!!refundTarget}
        onClose={() => setRefundTarget(null)}
        onConfirm={() => refundTarget && refundPayment(refundTarget)}
        title="Confirmer le remboursement ?"
        message="Le paiement sera remboursé, la commande annulée et le cashback retiré. Action irréversible."
        confirmLabel="Confirmer le remboursement"
        loading={refunding}
      />
    </div>
  );
}
