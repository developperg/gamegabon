'use client';

import { useState } from 'react';
import { Search, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAdminOrders, useUpdateOrderStatus } from '@/hooks/index';
import { Card, Badge, Skeleton, EmptyState, Tabs, Button, Modal, ConfirmDialog } from '@/components/ui';
import { fmtXAF, fmtDate, ORDER_STATUS_CONFIG, PAYMENT_LABELS } from '@/lib/utils';
import type { Order, OrderStatus, Game, Pack, User } from '@/types';

const STATUS_TABS = [
  { id: 'all',        label: 'Toutes'       },
  { id: 'pending',    label: '⏳ En attente' },
  { id: 'processing', label: '⚙️ En cours'   },
  { id: 'delivered',  label: '✓ Livrées'    },
  { id: 'failed',     label: '✗ Échouées'   },
  { id: 'refunded',   label: '↩ Remboursées' },
];

export default function AdminOrdersPage() {
  const [statusFilter, setStatusFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [page, setPage]     = useState(1);
  const [selected, setSelected] = useState<Order | null>(null);
  const [confirmAction, setConfirmAction] = useState<{ id: string; status: OrderStatus; label: string } | null>(null);

  const { data, isLoading, refetch } = useAdminOrders({
    status: statusFilter === 'all' ? undefined : statusFilter,
    search: search || undefined,
    page,
    limit: 15,
  });
  const { mutate: updateStatus, isPending: updating } = useUpdateOrderStatus();

  const orders: Order[]  = data?.data || [];
  const pagination       = data?.pagination;

  const handleSearch = () => { setSearch(searchInput); setPage(1); };
  const handleStatusChange = (orderId: string, status: OrderStatus, label: string) => {
    setConfirmAction({ id: orderId, status, label });
  };
  const confirmUpdate = () => {
    if (!confirmAction) return;
    updateStatus({ id: confirmAction.id, status: confirmAction.status }, { onSuccess: () => setSelected(null) });
    setConfirmAction(null);
  };

  return (
    <div className="space-y-5 animate-fade-up">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-black">Commandes</h1>
        <Button variant="secondary" size="sm" onClick={() => refetch()}>
          <RefreshCw className="h-3.5 w-3.5" /> Actualiser
        </Button>
      </div>

      {/* Filters */}
      <Tabs tabs={STATUS_TABS} active={statusFilter} onChange={(id) => { setStatusFilter(id); setPage(1); }} />

      {/* Search bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <input
            className="w-full bg-gaming-card2 border border-gaming-border rounded-xl pl-9 pr-4 py-2.5 text-sm text-white placeholder:text-gray-600 outline-none focus:border-brand-500/60 transition"
            placeholder="Rechercher par n° commande, client, jeu..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
        </div>
        <Button size="sm" onClick={handleSearch}>Chercher</Button>
        {search && <Button variant="ghost" size="sm" onClick={() => { setSearch(''); setSearchInput(''); setPage(1); }}>×</Button>}
      </div>

      {/* Table */}
      <Card padding={false}>
        {isLoading ? (
          <div className="p-4 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}
          </div>
        ) : orders.length === 0 ? (
          <EmptyState icon="📭" title="Aucune commande" description="Aucune commande ne correspond à vos filtres." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gaming-border text-xs text-gray-500 font-bold uppercase tracking-wider">
                  {['N° Commande', 'Client', 'Jeu / Pack', 'Montant', 'Paiement', 'Statut', 'Date', 'Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gaming-border">
                {orders.map((o: Order) => {
                  const game  = (o.game  || o.gameId)  as Game;
                  const pack  = (o.pack  || o.packId)  as Pack;
                  const user  = (o.user  || o.userId)  as User;
                  const cfg   = ORDER_STATUS_CONFIG[o.status];
                  return (
                    <tr key={o._id} className="hover:bg-white/2 transition">
                      <td className="px-4 py-3">
                        <span className="font-mono text-xs text-brand-400 cursor-pointer hover:underline"
                          onClick={() => setSelected(o)}>
                          {o.orderNumber}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="font-medium">{user?.name || '—'}</div>
                        <div className="text-xs text-gray-500">{user?.email || ''}</div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span>{game?.icon || '🎮'}</span>
                          <div>
                            <div className="font-medium">{game?.name || '—'}</div>
                            <div className="text-xs text-gray-500">{pack?.label || '—'}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <div className="font-black">{fmtXAF(o.finalAmount)}</div>
                        {o.discountAmount > 0 && <div className="text-xs text-green-400">-{fmtXAF(o.discountAmount)}</div>}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-xs text-gray-400">
                        {PAYMENT_LABELS[o.paymentMethod] || o.paymentMethod}
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant={
                          o.status === 'delivered'  ? 'success' :
                          o.status === 'failed'     ? 'danger'  :
                          o.status === 'refunded'   ? 'purple'  : 'warning'
                        }>
                          {cfg.label}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{fmtDate(o.createdAt)}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1.5 flex-wrap">
                          <button className="text-xs px-2 py-1 rounded-lg border border-gaming-border text-gray-400 hover:text-white hover:border-brand-500/40 transition"
                            onClick={() => setSelected(o)}>
                            Détails
                          </button>
                          {(o.status === 'pending' || o.status === 'processing') && (
                            <button className="text-xs px-2 py-1 rounded-lg border border-green-500/40 text-green-400 hover:bg-green-500/10 transition"
                              onClick={() => handleStatusChange(o._id, 'delivered', 'Livrer')}>
                              ✓ Livrer
                            </button>
                          )}
                          {o.status !== 'failed' && o.status !== 'delivered' && o.status !== 'refunded' && (
                            <button className="text-xs px-2 py-1 rounded-lg border border-red-500/40 text-red-400 hover:bg-red-500/10 transition"
                              onClick={() => handleStatusChange(o._id, 'failed', 'Marquer échouée')}>
                              ✗ Échouer
                            </button>
                          )}
                          {o.status === 'delivered' && (
                            <button className="text-xs px-2 py-1 rounded-lg border border-purple-500/40 text-purple-400 hover:bg-purple-500/10 transition"
                              onClick={() => handleStatusChange(o._id, 'refunded', 'Rembourser')}>
                              ↩ Rembourser
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">{pagination.total} commandes</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => p - 1)} disabled={page === 1}
              className="p-1.5 rounded-lg border border-gaming-border text-gray-400 hover:text-white disabled:opacity-40 transition">
              <ChevronLeft className="h-4 w-4" />
            </button>
            <span className="text-xs text-gray-400 px-2">Page {page} / {pagination.totalPages}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={page === pagination.totalPages}
              className="p-1.5 rounded-lg border border-gaming-border text-gray-400 hover:text-white disabled:opacity-40 transition">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}

      {/* Order detail modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title={`Commande — ${selected?.orderNumber}`} size="lg">
        {selected && <OrderDetail order={selected} onStatusChange={handleStatusChange} />}
      </Modal>

      {/* Confirm dialog */}
      <ConfirmDialog
        open={!!confirmAction}
        onClose={() => setConfirmAction(null)}
        onConfirm={confirmUpdate}
        title={confirmAction?.label || 'Confirmer'}
        message={`Voulez-vous vraiment effectuer cette action sur la commande ?`}
        confirmLabel={confirmAction?.label || 'Confirmer'}
        loading={updating}
      />
    </div>
  );
}

function OrderDetail({ order, onStatusChange }: { order: Order; onStatusChange: (id: string, status: OrderStatus, label: string) => void }) {
  const game  = (order.game  || order.gameId)  as Game;
  const pack  = (order.pack  || order.packId)  as Pack;
  const user  = (order.user  || order.userId)  as User;
  const cfg   = ORDER_STATUS_CONFIG[order.status];

  return (
    <div className="space-y-4 text-sm">
      <div className="grid grid-cols-2 gap-3">
        {[
          ['N° Commande', order.orderNumber],
          ['Statut',      <Badge key="s" variant={order.status === 'delivered' ? 'success' : order.status === 'failed' ? 'danger' : 'warning'}>{cfg.label}</Badge>],
          ['Client',      user?.name || '—'],
          ['Email',       user?.email || '—'],
          ['Jeu',         `${game?.icon || ''} ${game?.name || '—'}`],
          ['Pack',        pack?.label || '—'],
          ['ID Joueur',   order.playerId],
          ['Paiement',    PAYMENT_LABELS[order.paymentMethod] || order.paymentMethod],
          ['Montant orig.',fmtXAF(order.originalAmount)],
          ['Réduction',   fmtXAF(order.discountAmount)],
          ['Montant final',fmtXAF(order.finalAmount)],
          ['Cashback',    fmtXAF(order.cashbackEarned)],
          ['Date',        fmtDate(order.createdAt)],
          ...(order.deliveredAt ? [['Livré le', fmtDate(order.deliveredAt)]] : []),
          ...(order.notes ? [['Notes', order.notes]] : []),
        ].map(([l, v]) => (
          <div key={String(l)} className="bg-gaming-card2 rounded-xl p-3">
            <div className="text-xs text-gray-500 mb-0.5">{l}</div>
            <div className="font-bold">{v as React.ReactNode}</div>
          </div>
        ))}
      </div>
      <div className="flex gap-2 pt-2 flex-wrap">
        {(order.status === 'pending' || order.status === 'processing') && (
          <Button onClick={() => onStatusChange(order._id, 'delivered', 'Livrer')} className="flex-1 bg-green-500 text-gray-950 hover:bg-green-400">✓ Marquer livré</Button>
        )}
        {order.status !== 'failed' && order.status !== 'delivered' && order.status !== 'refunded' && (
          <Button variant="danger" onClick={() => onStatusChange(order._id, 'failed', 'Marquer échouée')} className="flex-1">✗ Marquer échoué</Button>
        )}
        {order.status === 'delivered' && (
          <Button variant="secondary" onClick={() => onStatusChange(order._id, 'refunded', 'Rembourser')} className="flex-1 border-purple-500/40 text-purple-400">↩ Rembourser</Button>
        )}
      </div>
    </div>
  );
}
