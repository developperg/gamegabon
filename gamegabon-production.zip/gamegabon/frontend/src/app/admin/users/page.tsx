'use client';

import { useState } from 'react';
import { Search, ChevronLeft, ChevronRight, UserX, UserCheck, Edit2, Trash2 } from 'lucide-react';
import { useAdminUsers, useUpdateUser } from '@/hooks/index';
import { adminApi } from '@/lib/api';
import { useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { Card, Badge, Skeleton, EmptyState, Button, Modal, ConfirmDialog, Tabs, Input, Select } from '@/components/ui';
import { fmtXAF, fmtDate, getInitials } from '@/lib/utils';
import type { User } from '@/types';

const ROLE_TABS = [
  { id: 'all',      label: 'Tous' },
  { id: 'client',   label: '👤 Clients' },
  { id: 'reseller', label: '⭐ Revendeurs' },
  { id: 'admin',    label: '🛡️ Admins' },
];

function EditUserModal({ user, onClose }: { user: User; onClose: () => void }) {
  const { mutate: updateUser, isPending } = useUpdateUser();
  const [form, setForm] = useState({ name: user.name, phone: user.phone, role: user.role, status: user.status });

  const save = () => {
    updateUser({ id: user._id, data: form }, { onSuccess: onClose });
  };

  return (
    <div className="space-y-4">
      <Input label="Nom complet" value={form.name} onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))} />
      <Input label="Téléphone" value={form.phone} onChange={(e) => setForm(f => ({ ...f, phone: e.target.value }))} />
      <Select label="Rôle" value={form.role} onChange={(e) => setForm(f => ({ ...f, role: e.target.value as User['role'] }))}>
        <option value="client">👤 Client</option>
        <option value="reseller">⭐ Revendeur</option>
        <option value="admin">🛡️ Admin</option>
      </Select>
      <Select label="Statut" value={form.status} onChange={(e) => setForm(f => ({ ...f, status: e.target.value as User['status'] }))}>
        <option value="active">✓ Actif</option>
        <option value="suspended">✗ Suspendu</option>
      </Select>
      <div className="flex gap-3 pt-2">
        <Button variant="secondary" fullWidth onClick={onClose}>Annuler</Button>
        <Button fullWidth loading={isPending} onClick={save}>Enregistrer</Button>
      </div>
    </div>
  );
}

function UserDetailModal({ user }: { user: User }) {
  return (
    <div className="space-y-3 text-sm">
      <div className="flex items-center gap-4 p-4 bg-gaming-card2 rounded-xl">
        <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-xl font-black text-gray-950">
          {getInitials(user.name)}
        </div>
        <div>
          <div className="font-black text-base">{user.name}</div>
          <div className="text-gray-400 text-xs">{user.email}</div>
          <div className="flex gap-2 mt-1">
            <Badge variant={user.role === 'admin' ? 'purple' : user.role === 'reseller' ? 'warning' : 'info'}>{user.role}</Badge>
            <Badge variant={user.status === 'active' ? 'success' : 'danger'}>{user.status}</Badge>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {[
          ['Téléphone',      user.phone],
          ['Inscrit le',     fmtDate(user.createdAt)],
          ['Commandes',      user.totalOrders],
          ['Total dépensé',  fmtXAF(user.totalSpent)],
          ['Cashback',       fmtXAF(user.cashback)],
          ['Code parrain',   user.referralCode],
          ['Email vérifié',  user.emailVerified ? '✓ Oui' : '✗ Non'],
        ].map(([l, v]) => (
          <div key={String(l)} className="bg-gaming-card2 rounded-xl p-3">
            <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-0.5">{l}</div>
            <div className="font-bold text-sm">{v as React.ReactNode}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function AdminUsersPage() {
  const qc = useQueryClient();
  const [roleFilter, setRoleFilter]   = useState('all');
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch]           = useState('');
  const [page, setPage]               = useState(1);
  const [detailUser, setDetailUser]   = useState<User | null>(null);
  const [editUser, setEditUser]       = useState<User | null>(null);
  const [deleteUser, setDeleteUser]   = useState<User | null>(null);
  const [deleting, setDeleting]       = useState(false);

  const { data, isLoading } = useAdminUsers({
    role:   roleFilter === 'all' ? undefined : roleFilter,
    search: search || undefined,
    page,
    limit:  15,
  });

  const users: User[] = data?.data || [];
  const pagination    = data?.pagination;

  const toggleStatus = async (u: User) => {
    const newStatus = u.status === 'active' ? 'suspended' : 'active';
    try {
      await adminApi.updateUser(u._id, { status: newStatus });
      qc.invalidateQueries({ queryKey: ['admin-users'] });
      toast.success(newStatus === 'active' ? 'Compte activé' : 'Compte suspendu');
    } catch { toast.error('Erreur'); }
  };

  const confirmDelete = async () => {
    if (!deleteUser) return;
    setDeleting(true);
    try {
      await adminApi.deleteUser(deleteUser._id);
      qc.invalidateQueries({ queryKey: ['admin-users'] });
      toast.success('Utilisateur supprimé');
      setDeleteUser(null);
    } catch { toast.error('Erreur suppression'); }
    finally { setDeleting(false); }
  };

  return (
    <div className="space-y-5 animate-fade-up">
      <h1 className="text-2xl font-black">Utilisateurs</h1>

      <Tabs tabs={ROLE_TABS} active={roleFilter} onChange={(id) => { setRoleFilter(id); setPage(1); }} />

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500" />
          <input
            className="w-full bg-gaming-card2 border border-gaming-border rounded-xl pl-9 pr-4 py-2.5 text-sm text-white placeholder:text-gray-600 outline-none focus:border-brand-500/60 transition"
            placeholder="Rechercher par nom ou email..."
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (setSearch(searchInput), setPage(1))}
          />
        </div>
        <Button size="sm" onClick={() => { setSearch(searchInput); setPage(1); }}>Chercher</Button>
      </div>

      <Card padding={false}>
        {isLoading ? (
          <div className="p-4 space-y-3">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 rounded-xl" />)}</div>
        ) : users.length === 0 ? (
          <EmptyState icon="👥" title="Aucun utilisateur" description="Aucun utilisateur ne correspond aux filtres." />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gaming-border text-xs text-gray-500 font-bold uppercase tracking-wider">
                  {['Utilisateur', 'Rôle', 'Statut', 'Commandes', 'Dépensé', 'Cashback', 'Inscrit', 'Actions'].map(h => (
                    <th key={h} className="px-4 py-3 text-left whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gaming-border">
                {users.map((u: User) => (
                  <tr key={u._id} className="hover:bg-white/2 transition">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-xs font-black text-gray-950 flex-shrink-0">
                          {getInitials(u.name)}
                        </div>
                        <div className="min-w-0">
                          <div className="font-bold truncate max-w-[140px]">{u.name}</div>
                          <div className="text-xs text-gray-500 truncate max-w-[140px]">{u.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={u.role === 'admin' ? 'purple' : u.role === 'reseller' ? 'warning' : 'info'}>
                        {u.role === 'admin' ? '🛡️ Admin' : u.role === 'reseller' ? '⭐ Revendeur' : '👤 Client'}
                      </Badge>
                    </td>
                    <td className="px-4 py-3">
                      <Badge variant={u.status === 'active' ? 'success' : 'danger'}>
                        {u.status === 'active' ? '✓ Actif' : '✗ Suspendu'}
                      </Badge>
                    </td>
                    <td className="px-4 py-3 font-bold">{u.totalOrders}</td>
                    <td className="px-4 py-3 font-bold text-yellow-400">{fmtXAF(u.totalSpent)}</td>
                    <td className="px-4 py-3 text-green-400">{fmtXAF(u.cashback)}</td>
                    <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">{fmtDate(u.createdAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <button title="Détails" onClick={() => setDetailUser(u)} className="p-1.5 rounded-lg border border-gaming-border text-gray-400 hover:text-white transition">
                          <Search className="h-3.5 w-3.5" />
                        </button>
                        <button title="Modifier" onClick={() => setEditUser(u)} className="p-1.5 rounded-lg border border-gaming-border text-gray-400 hover:text-white transition">
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button title={u.status === 'active' ? 'Suspendre' : 'Activer'} onClick={() => toggleStatus(u)}
                          className={`p-1.5 rounded-lg border transition ${u.status === 'active' ? 'border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10' : 'border-green-500/40 text-green-400 hover:bg-green-500/10'}`}>
                          {u.status === 'active' ? <UserX className="h-3.5 w-3.5" /> : <UserCheck className="h-3.5 w-3.5" />}
                        </button>
                        {u.role !== 'admin' && (
                          <button title="Supprimer" onClick={() => setDeleteUser(u)} className="p-1.5 rounded-lg border border-red-500/40 text-red-400 hover:bg-red-500/10 transition">
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">{pagination.total} utilisateurs</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => p - 1)} disabled={page === 1} className="p-1.5 rounded-lg border border-gaming-border text-gray-400 hover:text-white disabled:opacity-40 transition"><ChevronLeft className="h-4 w-4" /></button>
            <span className="text-xs text-gray-400 px-2">Page {page} / {pagination.totalPages}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={page === pagination.totalPages} className="p-1.5 rounded-lg border border-gaming-border text-gray-400 hover:text-white disabled:opacity-40 transition"><ChevronRight className="h-4 w-4" /></button>
          </div>
        </div>
      )}

      {/* Modals */}
      <Modal open={!!detailUser} onClose={() => setDetailUser(null)} title="Détails utilisateur" size="md">
        {detailUser && <UserDetailModal user={detailUser} />}
      </Modal>

      <Modal open={!!editUser} onClose={() => setEditUser(null)} title="Modifier l'utilisateur" size="sm">
        {editUser && <EditUserModal user={editUser} onClose={() => setEditUser(null)} />}
      </Modal>

      <ConfirmDialog
        open={!!deleteUser}
        onClose={() => setDeleteUser(null)}
        onConfirm={confirmDelete}
        title={`Supprimer ${deleteUser?.name} ?`}
        message="Cette action est irréversible. L'utilisateur et ses données seront supprimés."
        confirmLabel="Supprimer définitivement"
        loading={deleting}
      />
    </div>
  );
}
