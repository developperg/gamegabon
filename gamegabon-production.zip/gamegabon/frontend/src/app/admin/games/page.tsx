'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Plus, Edit2, Trash2, Power, PowerOff, ChevronDown, ChevronRight, Package } from 'lucide-react';
import { useAdminGames, useDeleteGame } from '@/hooks/index';
import { adminApi } from '@/lib/api';
import { useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { Card, Button, Input, Modal, ConfirmDialog, Badge, Skeleton } from '@/components/ui';
import { fmtXAF } from '@/lib/utils';
import type { Game, Pack } from '@/types';

// ─── Game form ────────────────────────────────────────────────
function GameForm({ game, onClose }: { game?: Game; onClose: () => void }) {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const { register, handleSubmit, watch, formState: { errors } } = useForm({
    defaultValues: {
      name:        game?.name        || '',
      currency:    game?.currency    || '',
      icon:        game?.icon        || '🎮',
      color:       game?.color       || '#00E5FF',
      description: game?.description || '',
      featured:    game?.featured    || false,
      sortOrder:   game?.sortOrder   || 0,
    },
  });
  const color = watch('color');

  const onSubmit = async (data: Record<string, unknown>) => {
    setSaving(true);
    try {
      if (game) await adminApi.updateGame(game._id, data);
      else       await adminApi.createGame(data);
      toast.success(game ? 'Jeu modifié' : 'Jeu créé');
      qc.invalidateQueries({ queryKey: ['admin-games'] });
      onClose();
    } catch { toast.error('Erreur lors de l\'enregistrement'); }
    finally { setSaving(false); }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <Input label="Nom du jeu" placeholder="ex: Roblox" error={errors.name?.message} {...register('name', { required: 'Requis' })} />
        <Input label="Monnaie" placeholder="ex: Robux" error={errors.currency?.message} {...register('currency', { required: 'Requis' })} />
        <Input label="Icône emoji" placeholder="🎮" {...register('icon')} />
        <Input label="Couleur hex" placeholder="#FF5252" {...register('color')} />
      </div>
      <div style={{ height: 28, borderRadius: 8, background: color, border: '1px solid #1c2840' }} />
      <Input label="Description (optionnel)" placeholder="Description du jeu..." {...register('description')} />
      <div className="grid grid-cols-2 gap-3">
        <Input label="Ordre d'affichage" type="number" {...register('sortOrder', { valueAsNumber: true })} />
        <div className="flex items-center gap-2 pt-6">
          <input type="checkbox" id="featured" {...register('featured')} className="rounded" />
          <label htmlFor="featured" className="text-sm font-medium">Mettre en avant</label>
        </div>
      </div>
      <div className="flex gap-3 pt-2">
        <Button type="button" variant="secondary" fullWidth onClick={onClose}>Annuler</Button>
        <Button type="submit" fullWidth loading={saving}>{game ? 'Modifier' : 'Créer le jeu'}</Button>
      </div>
    </form>
  );
}

// ─── Pack form ────────────────────────────────────────────────
function PackForm({ gameId, pack, onClose }: { gameId: string; pack?: Pack; onClose: () => void }) {
  const qc = useQueryClient();
  const [saving, setSaving] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues: {
      label:       pack?.label       || '',
      amount:      pack?.amount      || 0,
      bonusAmount: pack?.bonusAmount || 0,
      priceXAF:    pack?.priceXAF   || 0,
      priceUSD:    pack?.priceUSD   || 0,
      priceEUR:    pack?.priceEUR   || 0,
      popular:     pack?.popular     || false,
      sortOrder:   pack?.sortOrder   || 0,
    },
  });

  const onSubmit = async (data: Record<string, unknown>) => {
    setSaving(true);
    try {
      if (pack) await adminApi.updatePack(gameId, pack._id, data);
      else       await adminApi.createPack(gameId, data);
      toast.success(pack ? 'Pack modifié' : 'Pack créé');
      qc.invalidateQueries({ queryKey: ['admin-games'] });
      onClose();
    } catch { toast.error('Erreur lors de l\'enregistrement'); }
    finally { setSaving(false); }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <Input label="Label" placeholder="ex: 400 Robux" error={errors.label?.message} {...register('label', { required: 'Requis' })} />
      <div className="grid grid-cols-2 gap-3">
        <Input label="Montant" type="number" {...register('amount', { valueAsNumber: true })} />
        <Input label="Bonus" type="number" {...register('bonusAmount', { valueAsNumber: true })} />
        <Input label="Prix XAF" type="number" error={errors.priceXAF?.message} {...register('priceXAF', { required: 'Requis', valueAsNumber: true })} />
        <Input label="Prix USD" type="number" step="0.01" {...register('priceUSD', { valueAsNumber: true })} />
        <Input label="Prix EUR" type="number" step="0.01" {...register('priceEUR', { valueAsNumber: true })} />
        <Input label="Ordre" type="number" {...register('sortOrder', { valueAsNumber: true })} />
      </div>
      <div className="flex items-center gap-2">
        <input type="checkbox" id="popular" {...register('popular')} />
        <label htmlFor="popular" className="text-sm font-medium">Pack populaire</label>
      </div>
      <div className="flex gap-3 pt-2">
        <Button type="button" variant="secondary" fullWidth onClick={onClose}>Annuler</Button>
        <Button type="submit" fullWidth loading={saving}>{pack ? 'Modifier' : 'Créer le pack'}</Button>
      </div>
    </form>
  );
}

// ─── Main page ────────────────────────────────────────────────
export default function AdminGamesPage() {
  const qc = useQueryClient();
  const { data: games, isLoading } = useAdminGames();
  const { mutate: deleteGame, isPending: deleting } = useDeleteGame();

  const [gameModal, setGameModal] = useState<{ open: boolean; game?: Game }>({ open: false });
  const [packModal, setPackModal] = useState<{ open: boolean; gameId?: string; pack?: Pack }>({ open: false });
  const [deletingGame, setDeletingGame] = useState<Game | null>(null);
  const [expandedGame, setExpandedGame] = useState<string | null>(null);

  const toggleActive = async (g: Game) => {
    try {
      await adminApi.updateGame(g._id, { active: !g.active });
      qc.invalidateQueries({ queryKey: ['admin-games'] });
      toast.success(g.active ? 'Jeu désactivé' : 'Jeu activé');
    } catch { toast.error('Erreur'); }
  };

  const deletePack = async (gameId: string, packId: string) => {
    try {
      await adminApi.deletePack(gameId, packId);
      qc.invalidateQueries({ queryKey: ['admin-games'] });
      toast.success('Pack supprimé');
    } catch { toast.error('Erreur suppression pack'); }
  };

  return (
    <div className="space-y-5 animate-fade-up">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black">Jeux & Packs</h1>
        <Button onClick={() => setGameModal({ open: true })}>
          <Plus className="h-4 w-4" /> Ajouter un jeu
        </Button>
      </div>

      {isLoading ? (
        <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>
      ) : (
        <div className="space-y-3">
          {(games || []).map((g: Game & { packCount?: number }) => (
            <Card key={g._id} padding={false}>
              {/* Game row */}
              <div className="flex items-center gap-3 p-4">
                <button onClick={() => setExpandedGame(expandedGame === g._id ? null : g._id)} className="text-gray-400 hover:text-white transition">
                  {expandedGame === g._id ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                </button>
                <div className="text-3xl">{g.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-black">{g.name}</span>
                    <span className="text-xs font-bold px-2 py-0.5 rounded-full" style={{ color: g.color, background: `${g.color}18` }}>{g.currency}</span>
                    <Badge variant={g.active ? 'success' : 'danger'} className="text-[10px]">{g.active ? 'Actif' : 'Inactif'}</Badge>
                    {g.featured && <Badge variant="warning" className="text-[10px]">⭐ Mis en avant</Badge>}
                  </div>
                  <div className="text-xs text-gray-500 mt-0.5 flex items-center gap-1">
                    <Package className="h-3 w-3" /> {g.packCount ?? 0} packs
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button onClick={() => setGameModal({ open: true, game: g })} className="p-2 rounded-lg border border-gaming-border text-gray-400 hover:text-white hover:border-brand-500/40 transition">
                    <Edit2 className="h-3.5 w-3.5" />
                  </button>
                  <button onClick={() => toggleActive(g)} className={`p-2 rounded-lg border transition ${g.active ? 'border-yellow-500/40 text-yellow-400 hover:bg-yellow-500/10' : 'border-green-500/40 text-green-400 hover:bg-green-500/10'}`}>
                    {g.active ? <PowerOff className="h-3.5 w-3.5" /> : <Power className="h-3.5 w-3.5" />}
                  </button>
                  <button onClick={() => setDeletingGame(g)} className="p-2 rounded-lg border border-red-500/40 text-red-400 hover:bg-red-500/10 transition">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* Packs accordion */}
              {expandedGame === g._id && (
                <div className="border-t border-gaming-border p-4 bg-gaming-card2/50">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-500">Packs</span>
                    <button onClick={() => setPackModal({ open: true, gameId: g._id })}
                      className="flex items-center gap-1 text-xs font-bold text-brand-400 hover:text-brand-300 transition">
                      <Plus className="h-3 w-3" /> Ajouter un pack
                    </button>
                  </div>
                  <div className="space-y-2">
                    {(g as any).packs?.map ? (g as any).packs.map((p: Pack) => (
                      <div key={p._id} className="flex items-center gap-3 bg-gaming-card rounded-xl px-3 py-2.5">
                        <div className="flex-1 min-w-0">
                          <div className="font-bold text-sm">{p.label}</div>
                          <div className="text-xs text-gray-500">
                            {fmtXAF(p.priceXAF)} · ${p.priceUSD} · €{p.priceEUR}
                            {p.bonusAmount > 0 && <span className="text-green-400 ml-1">+{p.bonusAmount} bonus</span>}
                            {p.popular && <span className="text-yellow-400 ml-1">⭐</span>}
                          </div>
                        </div>
                        <Badge variant={p.active ? 'success' : 'danger'} className="text-[10px]">{p.active ? 'Actif' : 'Off'}</Badge>
                        <button onClick={() => setPackModal({ open: true, gameId: g._id, pack: p })}
                          className="p-1.5 text-gray-400 hover:text-white transition"><Edit2 className="h-3 w-3" /></button>
                        <button onClick={() => deletePack(g._id, p._id)}
                          className="p-1.5 text-red-400 hover:text-red-300 transition"><Trash2 className="h-3 w-3" /></button>
                      </div>
                    )) : <p className="text-xs text-gray-500">Aucun pack. Cliquez sur &quot;Ajouter un pack&quot;.</p>}
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      {/* Game modal */}
      <Modal open={gameModal.open} onClose={() => setGameModal({ open: false })}
        title={gameModal.game ? `Modifier — ${gameModal.game.name}` : 'Ajouter un jeu'} size="md">
        <GameForm game={gameModal.game} onClose={() => setGameModal({ open: false })} />
      </Modal>

      {/* Pack modal */}
      <Modal open={packModal.open} onClose={() => setPackModal({ open: false })}
        title={packModal.pack ? `Modifier — ${packModal.pack.label}` : 'Ajouter un pack'} size="md">
        {packModal.gameId && (
          <PackForm gameId={packModal.gameId} pack={packModal.pack} onClose={() => setPackModal({ open: false })} />
        )}
      </Modal>

      {/* Confirm delete game */}
      <ConfirmDialog
        open={!!deletingGame}
        onClose={() => setDeletingGame(null)}
        onConfirm={() => { if (deletingGame) { deleteGame(deletingGame._id); setDeletingGame(null); } }}
        title={`Supprimer ${deletingGame?.name} ?`}
        message="Cette action supprimera définitivement le jeu et tous ses packs."
        confirmLabel="Supprimer"
        loading={deleting}
      />
    </div>
  );
}
