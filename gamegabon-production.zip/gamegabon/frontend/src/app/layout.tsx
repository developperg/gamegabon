import type { Metadata } from 'next';
import { Exo_2, Rajdhani } from 'next/font/google';
import { Toaster } from 'react-hot-toast';
import { Providers } from './providers';
import './globals.css';

const exo2 = Exo_2({
  subsets: ['latin'],
  variable: '--font-exo2',
  weight: ['400', '500', '600', '700', '800', '900'],
});

const rajdhani = Rajdhani({
  subsets: ['latin'],
  variable: '--font-rajdhani',
  weight: ['400', '500', '600', '700'],
});

export const metadata: Metadata = {
  title: { default: 'GameTopUp Gabon — Rechargez vos jeux', template: '%s | GameTopUp Gabon' },
  description: 'Plateforme de recharge gaming au Gabon. Airtel Money, Moov Money, carte bancaire. Roblox, Fortnite, Free Fire et plus.',
  keywords: ['recharge jeux', 'gaming gabon', 'airtel money', 'moov money', 'robux', 'vbucks', 'gabon'],
  openGraph: {
    title: 'GameTopUp Gabon',
    description: 'Rechargez vos jeux préférés en 30 secondes',
    locale: 'fr_FR',
    type: 'website',
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr" className="dark" suppressHydrationWarning>
      <body className={`${exo2.variable} ${rajdhani.variable} font-sans bg-gaming-bg text-white antialiased`}>
        <Providers>
          {children}
          <Toaster
            position="top-center"
            toastOptions={{
              duration: 3500,
              style: {
                background: '#0d1420',
                color: '#fff',
                border: '1px solid #1c2840',
                borderRadius: '12px',
                fontSize: '14px',
                fontWeight: '600',
              },
              success: { iconTheme: { primary: '#00e676', secondary: '#0d1420' } },
              error:   { iconTheme: { primary: '#ff4444', secondary: '#0d1420' } },
            }}
          />
        </Providers>
      </body>
    </html>
  );
}
