'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';
import { Mail, Lock, User, Phone, Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';
import { useRegister } from '@/hooks/index';
import { Button, Input, Card } from '@/components/ui';

const schema = z.object({
  name: z.string().min(2, 'Minimum 2 caractères').max(80),
  email: z.string().email('Email invalide'),
  phone: z.string().min(8, 'Numéro invalide'),
  password: z.string().min(8, 'Min. 8 caractères').regex(/[A-Z]/, 'Une majuscule requise').regex(/[0-9]/, 'Un chiffre requis'),
  confirmPassword: z.string(),
  referralCode: z.string().optional(),
}).refine((d) => d.password === d.confirmPassword, { message: 'Mots de passe différents', path: ['confirmPassword'] });
type FormData = z.infer<typeof schema>;

export default function RegisterPage() {
  const [showPwd, setShowPwd] = useState(false);
  const { mutate: register, isPending } = useRegister();
  const { register: reg, handleSubmit, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = (data: FormData) => {
    const { confirmPassword, ...rest } = data;
    void confirmPassword;
    register(rest);
  };

  return (
    <div className="min-h-screen bg-gaming-bg flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-md animate-fade-up">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-2xl font-black text-gray-950 shadow-lg shadow-brand-500/30">G</div>
            <div className="text-xl font-black">GameTopUp <span className="text-brand-400">Gabon</span></div>
          </Link>
          <p className="text-gray-500 text-sm mt-2">Créez votre compte gratuitement</p>
        </div>

        <Card>
          <div className="flex bg-gaming-card2 rounded-xl p-1 mb-6">
            <Link href="/auth/login" className="flex-1 text-center py-2 text-sm font-bold text-gray-400 hover:text-white transition">Connexion</Link>
            <span className="flex-1 text-center py-2 rounded-lg bg-brand-500 text-gray-950 text-sm font-black">S&apos;inscrire</span>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input label="Nom complet" placeholder="Jean Dupont" leftIcon={<User className="h-4 w-4" />} error={errors.name?.message} {...reg('name')} />
            <Input label="Email" type="email" placeholder="vous@email.com" leftIcon={<Mail className="h-4 w-4" />} error={errors.email?.message} {...reg('email')} />
            <Input label="Téléphone" placeholder="+241 077 000 000" leftIcon={<Phone className="h-4 w-4" />} error={errors.phone?.message} {...reg('phone')} />
            <div className="relative">
              <Input label="Mot de passe" type={showPwd ? 'text' : 'password'} placeholder="Min. 8 car. avec majuscule et chiffre"
                leftIcon={<Lock className="h-4 w-4" />} error={errors.password?.message} {...reg('password')} />
              <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-8 text-gray-500 hover:text-white transition">
                {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <Input label="Confirmer le mot de passe" type="password" placeholder="••••••••"
              leftIcon={<Lock className="h-4 w-4" />} error={errors.confirmPassword?.message} {...reg('confirmPassword')} />
            <Input label="Code de parrainage (optionnel)" placeholder="ex: JEAN12345"
              hint="Entrez le code d'un ami pour profiter d'avantages" {...reg('referralCode')} />
            <Button type="submit" fullWidth size="lg" loading={isPending}>Créer mon compte →</Button>
          </form>

          <p className="text-center text-xs text-gray-500 mt-4">
            En créant un compte vous acceptez nos{' '}
            <Link href="/legal" className="text-brand-400 hover:underline">conditions d&apos;utilisation</Link>
          </p>
        </Card>

        <p className="text-center text-sm text-gray-500 mt-5">
          Déjà un compte ?{' '}
          <Link href="/auth/login" className="text-brand-400 font-bold hover:text-brand-300 transition">Se connecter</Link>
        </p>
      </div>
    </div>
  );
}
