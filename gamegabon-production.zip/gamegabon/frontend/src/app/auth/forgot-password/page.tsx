'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import Link from 'next/link';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';
import { Button, Input, Card } from '@/components/ui';
import { authApi } from '@/lib/api';
import toast from 'react-hot-toast';

const schema = z.object({ email: z.string().email('Email invalide') });
type FormData = z.infer<typeof schema>;

export default function ForgotPasswordPage() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    setLoading(true);
    try {
      await authApi.forgotPassword(data.email);
      setSent(true);
    } catch {
      toast.error('Erreur lors de l\'envoi. Vérifiez votre email.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gaming-bg flex items-center justify-center px-4">
      <div className="w-full max-w-md animate-fade-up">
        <Card>
          {sent ? (
            <div className="text-center py-4">
              <CheckCircle className="h-14 w-14 text-green-400 mx-auto mb-4" />
              <h2 className="text-xl font-black mb-2">Email envoyé !</h2>
              <p className="text-sm text-gray-400 mb-6">Vérifiez votre boîte mail pour réinitialiser votre mot de passe. Le lien expire dans 10 minutes.</p>
              <Link href="/auth/login"><Button fullWidth>Retour à la connexion</Button></Link>
            </div>
          ) : (
            <>
              <Link href="/auth/login" className="inline-flex items-center gap-1.5 text-xs text-gray-500 hover:text-white mb-6 transition">
                <ArrowLeft className="h-3.5 w-3.5" /> Retour
              </Link>
              <h1 className="text-xl font-black mb-1">Mot de passe oublié</h1>
              <p className="text-sm text-gray-400 mb-6">Entrez votre email, nous vous enverrons un lien de réinitialisation.</p>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <Input label="Email" type="email" placeholder="vous@email.com" leftIcon={<Mail className="h-4 w-4" />} error={errors.email?.message} {...register('email')} />
                <Button type="submit" fullWidth loading={loading}>Envoyer le lien</Button>
              </form>
            </>
          )}
        </Card>
      </div>
    </div>
  );
}
