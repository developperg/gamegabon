'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';
import { useLogin } from '@/hooks/index';
import { Button, Input, Card } from '@/components/ui';

const schema = z.object({
  email: z.string().email('Email invalide'),
  password: z.string().min(1, 'Mot de passe requis'),
});
type FormData = z.infer<typeof schema>;

export default function LoginPage() {
  const [showPwd, setShowPwd] = useState(false);
  const { mutate: login, isPending } = useLogin();
  const { register, handleSubmit, formState: { errors }, setValue } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = (data: FormData) => login(data);

  const fillDemo = (email: string, password: string) => { setValue('email', email); setValue('password', password); };

  return (
    <div className="min-h-screen bg-gaming-bg flex items-center justify-center px-4 py-20">
      <div className="w-full max-w-md animate-fade-up">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex flex-col items-center gap-2">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-2xl font-black text-gray-950 shadow-lg shadow-brand-500/30">G</div>
            <div className="text-xl font-black">GameTopUp <span className="text-brand-400">Gabon</span></div>
          </Link>
          <p className="text-gray-500 text-sm mt-2">Connectez-vous à votre compte</p>
        </div>

        <Card>
          {/* Tabs */}
          <div className="flex bg-gaming-card2 rounded-xl p-1 mb-6">
            <span className="flex-1 text-center py-2 rounded-lg bg-brand-500 text-gray-950 text-sm font-black">Connexion</span>
            <Link href="/auth/register" className="flex-1 text-center py-2 text-sm font-bold text-gray-400 hover:text-white transition">S&apos;inscrire</Link>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <Input
              label="Email"
              type="email"
              placeholder="vous@email.com"
              leftIcon={<Mail className="h-4 w-4" />}
              error={errors.email?.message}
              {...register('email')}
            />
            <div className="relative">
              <Input
                label="Mot de passe"
                type={showPwd ? 'text' : 'password'}
                placeholder="••••••••"
                leftIcon={<Lock className="h-4 w-4" />}
                error={errors.password?.message}
                {...register('password')}
              />
              <button type="button" onClick={() => setShowPwd(!showPwd)} className="absolute right-3 top-8 text-gray-500 hover:text-white transition">
                {showPwd ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <div className="text-right">
              <Link href="/auth/forgot-password" className="text-xs text-brand-400 hover:text-brand-300 transition">Mot de passe oublié ?</Link>
            </div>
            <Button type="submit" fullWidth size="lg" loading={isPending}>Se connecter</Button>
          </form>

          {/* Demo accounts */}
          <div className="mt-6 pt-5 border-t border-gaming-border">
            <p className="text-xs text-gray-500 text-center mb-3 uppercase tracking-widest font-bold">Comptes démo</p>
            <div className="space-y-2">
              {[
                { label: '🛡️ Administrateur', email: 'admin@gamegabon.com', pwd: 'Admin@Gabon2026!', color: 'border-purple-500/30 text-purple-400 hover:bg-purple-500/10' },
                { label: '👤 Client démo', email: 'client@demo.com', pwd: 'Demo@12345', color: 'border-brand-500/30 text-brand-400 hover:bg-brand-500/10' },
              ].map((d) => (
                <button key={d.email} type="button" onClick={() => fillDemo(d.email, d.pwd)}
                  className={`w-full text-left px-3 py-2.5 rounded-xl border text-xs font-bold transition ${d.color}`}>
                  {d.label} — {d.email}
                </button>
              ))}
            </div>
          </div>
        </Card>

        <p className="text-center text-sm text-gray-500 mt-5">
          Pas encore de compte ?{' '}
          <Link href="/auth/register" className="text-brand-400 font-bold hover:text-brand-300 transition">S&apos;inscrire gratuitement</Link>
        </p>
      </div>
    </div>
  );
}
