'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowLeft, Tag, CheckCircle2, Smartphone, CreditCard } from 'lucide-react';
import Link from 'next/link';
import { useCheckoutStore } from '@/store/checkout.store';
import { useAuthStore } from '@/store/auth.store';
import { useCreateOrder, useValidatePromo } from '@/hooks/index';
import { Button, Input, Card, Select, Badge } from '@/components/ui';
import { fmtXAF, fmtCurrency, PAYMENT_LABELS, PAYMENT_ICONS } from '@/lib/utils';
import toast from 'react-hot-toast';

const PAYMENT_METHODS = [
  { id: 'pvit_airtel', name: 'Airtel Money', icon: '📱', needsPhone: true, desc: '🇬🇦 Gabon' },
  { id: 'pvit_moov',  name: 'Moov Money',   icon: '📲', needsPhone: true, desc: '🇬🇦 Gabon' },
  { id: 'card',       name: 'Carte bancaire', icon: '💳', needsPhone: false, desc: 'Visa / Mastercard' },
  { id: 'paypal',     name: 'PayPal',         icon: '🅿️', needsPhone: false, desc: 'International' },
  { id: 'usdt',       name: 'USDT Crypto',    icon: '₿',  needsPhone: false, desc: 'TRC-20 / ERC-20' },
];

const CURRENCIES = ['XAF', 'USD', 'EUR'] as const;

const schema = z.object({
  playerId: z.string().min(1, 'ID joueur requis').max(100),
  paymentMethod: z.string().min(1, 'Choisissez un moyen de paiement'),
  phoneNumber: z.string().optional(),
  promoCode: z.string().optional(),
  currency: z.enum(['XAF', 'USD', 'EUR']),
}).refine((d) => {
  const pm = PAYMENT_METHODS.find((p) => p.id === d.paymentMethod);
  if (pm?.needsPhone && !d.phoneNumber?.trim()) return false;
  return true;
}, { message: 'Numéro de téléphone requis pour Mobile Money', path: ['phoneNumber'] });

type FormData = z.infer<typeof schema>;

export default function CheckoutPage() {
  const router = useRouter();
  const { isAuthenticated } = useAuthStore();
  const {
    game, pack, currency, promoValidation,
    setPlayerId, setPaymentMethod, setCurrency, setPromoValidation,
  } = useCheckoutStore();
  const { mutate: createOrder, isPending } = useCreateOrder();
  const { mutate: validatePromo, isPending: validatingPromo } = useValidatePromo();
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [promoInput, setPromoInput] = useState('');

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: { currency: 'XAF' },
  });

  const selectedPayment = watch('paymentMethod');
  const selectedCurrency = watch('currency');
  const needsPhone = PAYMENT_METHODS.find((p) => p.id === selectedPayment)?.needsPhone;

  useEffect(() => {
    if (!isAuthenticated) { router.push('/auth/login'); return; }
    if (!game || !pack) { router.push('/games'); }
  }, [isAuthenticated, game, pack, router]);

  if (!game || !pack) return null;

  const basePrice = selectedCurrency === 'USD' ? pack.priceUSD : selectedCurrency === 'EUR' ? pack.priceEUR : pack.priceXAF;
  const finalPrice = promoValidation ? promoValidation.finalAmount : basePrice;
  const discount = promoValidation ? promoValidation.discountAmount : 0;

  const handlePromo = () => {
    if (!promoInput.trim()) return;
    validatePromo(
      { code: promoInput.trim(), gameId: game._id, amount: pack.priceXAF },
      {
        onSuccess: ({ data }) => {
          setPromoValidation(data.data);
          toast.success(`Code ${data.data.code} appliqué ! -${data.data.discountAmount} FCFA`);
        },
      }
    );
  };

  const onSubmit = (data: FormData) => {
    setPlayerId(data.playerId);
    setPaymentMethod(data.paymentMethod);
    setCurrency(data.currency);
    if (step < 3) { setStep((s) => (s + 1) as 1 | 2 | 3); return; }

    createOrder({
      gameId: game._id,
      packId: pack._id,
      playerId: data.playerId,
      paymentMethod: data.paymentMethod,
      phoneNumber: data.phoneNumber,
      promoCode: promoInput || undefined,
      currency: data.currency,
    });
  };

  const StepIndicator = () => (
    <div className="flex items-center gap-2 mb-6">
      {[1, 2, 3].map((s) => (
        <div key={s} className="flex items-center gap-2">
          <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black transition-all
            ${step >= s ? 'bg-brand-500 text-gray-950' : 'bg-gaming-card2 text-gray-500 border border-gaming-border'}`}>
            {step > s ? <CheckCircle2 className="h-4 w-4" /> : s}
          </div>
          {s < 3 && <div className={`flex-1 h-0.5 w-8 transition-all ${step > s ? 'bg-brand-500' : 'bg-gaming-border'}`} />}
        </div>
      ))}
      <div className="ml-2 text-xs text-gray-400">
        {step === 1 ? 'Détails' : step === 2 ? 'Paiement' : 'Confirmation'}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gaming-bg">
      {/* Header */}
      <div className="border-b border-gaming-border bg-gaming-card/60 backdrop-blur px-4 py-3 flex items-center gap-3">
        <button onClick={() => step > 1 ? setStep((s) => (s - 1) as 1 | 2 | 3) : router.back()} className="text-gray-400 hover:text-white transition">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2">
          <span className="text-lg">{game.icon}</span>
          <span className="font-bold text-sm">{game.name} — {pack.label}</span>
        </div>
      </div>

      <div className="max-w-xl mx-auto px-4 py-8">
        <StepIndicator />

        <form onSubmit={handleSubmit(onSubmit)}>
          {/* ── STEP 1: Player ID + Currency + Promo ─────── */}
          {step === 1 && (
            <div className="space-y-5 animate-fade-up">
              <Card>
                <h2 className="font-black text-lg mb-4">Détails de la recharge</h2>

                {/* Currency switcher */}
                <div className="mb-4">
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">Devise</label>
                  <div className="flex gap-2">
                    {CURRENCIES.map((c) => (
                      <button key={c} type="button" onClick={() => { setCurrency(c); setValue('currency', c); }}
                        className={`flex-1 py-2 rounded-xl text-sm font-bold border transition-all
                          ${selectedCurrency === c ? 'bg-brand-500/15 border-brand-500/60 text-brand-400' : 'border-gaming-border text-gray-500 hover:text-white'}`}>
                        {c}
                      </button>
                    ))}
                  </div>
                </div>

                <Input
                  label="ID Joueur"
                  placeholder={`Votre identifiant ${game.name}`}
                  hint={`Trouvez votre ID dans les paramètres de ${game.name}`}
                  error={errors.playerId?.message}
                  {...register('playerId')}
                />

                {/* Promo code */}
                <div className="mt-4">
                  <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-2">Code promo (optionnel)</label>
                  <div className="flex gap-2">
                    <input
                      className="flex-1 bg-gaming-card2 border border-gaming-border rounded-xl px-3.5 py-3 text-sm text-white placeholder:text-gray-600 outline-none focus:border-brand-500/60 transition"
                      placeholder="ex: GABON10"
                      value={promoInput}
                      onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                    />
                    <Button type="button" variant="outline" size="sm" onClick={handlePromo} loading={validatingPromo} className="px-4">
                      <Tag className="h-4 w-4" />
                    </Button>
                  </div>
                  {promoValidation && (
                    <div className="mt-2 flex items-center gap-2 text-xs font-bold text-green-400">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Code appliqué : -{fmtXAF(promoValidation.discountAmount)}
                    </div>
                  )}
                </div>
              </Card>

              {/* Order summary */}
              <Card>
                <h3 className="font-bold text-sm mb-3">Récapitulatif</h3>
                <div className="space-y-2 text-sm">
                  {[
                    ['Jeu', game.name],
                    ['Pack', pack.label],
                    ['Prix', fmtCurrency(basePrice, selectedCurrency)],
                    ...(discount > 0 ? [['Réduction', `-${fmtXAF(discount)}`]] : []),
                  ].map(([l, v]) => (
                    <div key={l} className="flex justify-between items-center py-1.5 border-b border-gaming-border last:border-0">
                      <span className="text-gray-400">{l}</span>
                      <span className="font-semibold">{v}</span>
                    </div>
                  ))}
                  <div className="flex justify-between items-center pt-1">
                    <span className="font-black">TOTAL</span>
                    <span className="font-black text-lg text-green-400">{fmtCurrency(finalPrice, selectedCurrency)}</span>
                  </div>
                </div>
              </Card>

              <Button type="submit" fullWidth size="lg">Continuer →</Button>
            </div>
          )}

          {/* ── STEP 2: Payment method ───────────────────── */}
          {step === 2 && (
            <div className="space-y-4 animate-fade-up">
              <h2 className="font-black text-lg mb-4">Moyen de paiement</h2>
              {errors.paymentMethod && <p className="text-xs text-red-400">{errors.paymentMethod.message}</p>}

              <div className="space-y-3">
                {PAYMENT_METHODS.map((pm) => (
                  <label key={pm.id} className={`flex items-center gap-4 p-4 rounded-2xl border cursor-pointer transition-all
                    ${selectedPayment === pm.id ? 'border-brand-500/60 bg-brand-500/8' : 'border-gaming-border hover:border-brand-500/30'}`}>
                    <input type="radio" value={pm.id} className="sr-only" {...register('paymentMethod')} />
                    <span className="text-2xl">{pm.icon}</span>
                    <div className="flex-1">
                      <div className="font-bold text-sm">{pm.name}</div>
                      <div className="text-xs text-gray-500">{pm.desc}</div>
                    </div>
                    {selectedPayment === pm.id && <CheckCircle2 className="h-5 w-5 text-brand-400 flex-shrink-0" />}
                  </label>
                ))}
              </div>

              {needsPhone && (
                <Input
                  label="Numéro de téléphone Mobile Money"
                  placeholder="+241 077 000 000"
                  leftIcon={<Smartphone className="h-4 w-4" />}
                  error={errors.phoneNumber?.message}
                  {...register('phoneNumber')}
                />
              )}

              <div className="flex gap-3 mt-2">
                <Button type="button" variant="secondary" fullWidth onClick={() => setStep(1)}>← Retour</Button>
                <Button type="submit" fullWidth>Continuer →</Button>
              </div>
            </div>
          )}

          {/* ── STEP 3: Confirm ──────────────────────────── */}
          {step === 3 && (
            <div className="space-y-4 animate-fade-up">
              <h2 className="font-black text-lg mb-4">Confirmation de commande</h2>

              <Card>
                <div className="space-y-3 text-sm">
                  {[
                    ['Jeu', `${game.icon} ${game.name}`],
                    ['Pack', pack.label],
                    ['ID Joueur', watch('playerId')],
                    ['Paiement', `${PAYMENT_ICONS[watch('paymentMethod')] || ''} ${PAYMENT_LABELS[watch('paymentMethod')] || watch('paymentMethod')}`],
                    ...(watch('phoneNumber') ? [['Téléphone', watch('phoneNumber') as string]] : []),
                    ...(discount > 0 ? [['Réduction', `-${fmtXAF(discount)}`]] : []),
                    ['Devise', selectedCurrency],
                  ].map(([l, v]) => (
                    <div key={l} className="flex justify-between items-center py-2 border-b border-gaming-border last:border-0">
                      <span className="text-gray-400">{l}</span>
                      <span className="font-semibold">{v}</span>
                    </div>
                  ))}
                  <div className="flex justify-between items-center pt-1">
                    <span className="font-black">TOTAL À PAYER</span>
                    <span className="font-black text-xl text-green-400">{fmtCurrency(finalPrice, selectedCurrency)}</span>
                  </div>
                </div>
              </Card>

              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-brand-500/8 border border-brand-500/20 text-xs text-brand-400">
                <CreditCard className="h-4 w-4 flex-shrink-0" />
                <span>Paiement chiffré · Livraison instantanée après confirmation · Conforme PCI DSS</span>
              </div>

              <div className="flex gap-3">
                <Button type="button" variant="secondary" fullWidth onClick={() => setStep(2)}>← Retour</Button>
                <Button type="submit" fullWidth size="lg" loading={isPending} className="bg-green-500 hover:bg-green-400 text-gray-950">
                  🔒 Confirmer et payer
                </Button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
