'use client';

import { useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { CheckCircle, Home, ShoppingBag } from 'lucide-react';
import { useCheckoutStore } from '@/store/checkout.store';
import { Button, Card } from '@/components/ui';
import { fmtXAF } from '@/lib/utils';

export default function CheckoutSuccessPage() {
  const params = useSearchParams();
  const orderId = params.get('orderId');
  const { game, pack, reset } = useCheckoutStore();

  useEffect(() => {
    return () => { reset(); };
  }, [reset]);

  const cashback = pack ? Math.floor(pack.priceXAF * 0.02) : 0;

  return (
    <div className="min-h-screen bg-gaming-bg flex items-center justify-center px-4">
      <div className="w-full max-w-md text-center animate-fade-up">
        {/* Success icon */}
        <div className="relative inline-block mb-6">
          <div className="w-24 h-24 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
            <CheckCircle className="h-12 w-12 text-green-400" />
          </div>
          <div className="absolute inset-0 rounded-full bg-green-500/10 animate-ping" />
        </div>

        <h1 className="text-2xl font-black text-green-400 mb-2">Commande réussie !</h1>
        <p className="text-gray-400 text-sm mb-6">
          Votre recharge {game ? `${game.icon} ${game.name}` : ''} a été livrée automatiquement.
        </p>

        {orderId && (
          <Card className="mb-4 text-left">
            <div className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-1">Numéro de commande</div>
            <div className="font-black text-xl text-brand-400 font-mono">{orderId.split('-').slice(-2).join('-')}</div>
          </Card>
        )}

        {cashback > 0 && (
          <div className="mb-6 p-3 rounded-xl bg-yellow-400/10 border border-yellow-400/30 text-xs font-bold text-yellow-400">
            🎁 +{fmtXAF(cashback)} cashback crédité sur votre compte
          </div>
        )}

        <div className="flex gap-3">
          <Link href="/dashboard/orders" className="flex-1">
            <Button variant="secondary" fullWidth>
              <ShoppingBag className="h-4 w-4" />
              Mes commandes
            </Button>
          </Link>
          <Link href="/games" className="flex-1">
            <Button fullWidth>
              <Home className="h-4 w-4" />
              Nouvelle recharge
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
