'use client';

import Link from 'next/link';
import { ShoppingBag, Zap, Trophy, Gift, ChevronRight, Gamepad2 } from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { useMyOrders, useGames } from '@/hooks/index';
import { Card, StatCard, Badge, Skeleton, EmptyState, ProgressBar } from '@/components/ui';
import { fmtXAF, fmtDate, ORDER_STATUS_CONFIG } from '@/lib/utils';
import type { Order, Game } from '@/types';

export default function DashboardPage() {
  const { user } = useAuthStore();
  const { data: ordersData, isLoading: ordersLoading } = useMyOrders({ limit: 5 });
  const { data: games, isLoading: gamesLoading } = useGames();

  const orders: Order[] = ordersData?.data || [];

  return (
    <div className="space-y-6 animate-fade-up">
      {/* Welcome banner */}
      <div className="relative overflow-hidden bg-gaming-card border border-gaming-border rounded-2xl p-6">
        <div className="absolute inset-0 bg-hero-glow opacity-50 pointer-events-none" />
        <div className="relative">
          <div className="text-xs font-bold text-brand-400 uppercase tracking-widest mb-1">🇬🇦 GameTopUp Gabon</div>
          <h1 className="text-2xl font-black mb-1">Bonjour, {user?.name?.split(' ')[0]} 👋</h1>
          <p className="text-gray-400 text-sm mb-4">Prêt à recharger ? Choisissez votre jeu et rechargez en 30 secondes.</p>
          <Link href="/games" className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-brand-500 to-cyan-400 text-gray-950 font-black rounded-xl text-sm hover:opacity-90 transition">
            <Gamepad2 className="h-4 w-4" /> Recharger maintenant
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Commandes" value={user?.totalOrders || 0} icon={<ShoppingBag className="h-5 w-5" />} color="text-brand-400" />
        <StatCard label="Total dépensé" value={fmtXAF(user?.totalSpent || 0)} icon={<Zap className="h-5 w-5" />} color="text-yellow-400" />
        <StatCard label="Cashback" value={fmtXAF(user?.cashback || 0)} icon={<Gift className="h-5 w-5" />} color="text-green-400" />
        <StatCard label="Statut" value={user?.role === 'reseller' ? '⭐ Revendeur' : '👤 Client'} icon={<Trophy className="h-5 w-5" />} color="text-purple-400" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent orders */}
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-black text-lg">Dernières commandes</h2>
            <Link href="/dashboard/orders" className="text-xs text-brand-400 font-bold flex items-center gap-1 hover:text-brand-300 transition">
              Tout voir <ChevronRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          <Card padding={false}>
            {ordersLoading ? (
              <div className="p-4 space-y-3">
                {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-14 rounded-xl" />)}
              </div>
            ) : orders.length === 0 ? (
              <EmptyState icon="📭" title="Aucune commande" description="Faites votre première recharge gaming !"
                action={<Link href="/games"><div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-500/10 border border-brand-500/30 text-brand-400 rounded-xl text-sm font-bold">Recharger →</div></Link>} />
            ) : (
              <div className="divide-y divide-gaming-border">
                {orders.map((o: Order) => {
                  const cfg = ORDER_STATUS_CONFIG[o.status];
                  const game = o.game || (typeof o.gameId === 'object' ? o.gameId : null);
                  return (
                    <div key={o._id} className="flex items-center gap-3 p-4 hover:bg-white/2 transition">
                      <div className="text-2xl flex-shrink-0">{(game as Game)?.icon || '🎮'}</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm truncate">{(game as Game)?.name || 'Jeu'}</div>
                        <div className="text-xs text-gray-500">{fmtDate(o.createdAt)} · #{o.orderNumber}</div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="font-bold text-sm">{fmtXAF(o.finalAmount)}</div>
                        <Badge variant={o.status === 'delivered' ? 'success' : o.status === 'pending' || o.status === 'processing' ? 'warning' : 'danger'} className="mt-0.5">
                          {cfg.label}
                        </Badge>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Sidebar: cashback + quick games */}
        <div className="space-y-4">
          {/* Cashback card */}
          <Card className="bg-gradient-to-br from-yellow-500/10 to-gaming-card border-yellow-500/20">
            <div className="flex justify-between items-start mb-3">
              <div>
                <div className="text-xs font-bold text-yellow-400 uppercase tracking-widest">Cashback disponible</div>
                <div className="text-2xl font-black text-yellow-400 mt-1">{fmtXAF(user?.cashback || 0)}</div>
              </div>
              <span className="text-2xl">🏆</span>
            </div>
            <ProgressBar value={user?.cashback || 0} max={5000} color="#fbbf24" />
            <div className="text-xs text-gray-500 mt-2">Palier VIP : 5 000 FCFA</div>
            <div className="mt-3 pt-3 border-t border-gaming-border text-xs">
              <div className="text-gray-400">Code parrainage</div>
              <div className="font-black text-white tracking-widest mt-0.5">{user?.referralCode}</div>
              <div className="text-gray-500 mt-0.5">+500 FCFA par ami parrainé</div>
            </div>
          </Card>

          {/* Quick games */}
          <Card>
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-sm">Recharge rapide</h3>
              <Link href="/games" className="text-xs text-brand-400">Tout voir</Link>
            </div>
            {gamesLoading ? (
              <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 rounded-xl" />)}</div>
            ) : (
              <div className="space-y-2">
                {(games || []).slice(0, 5).map((g: Game) => (
                  <Link key={g._id} href={`/games/${g.slug}`}
                    className="flex items-center gap-2.5 p-2.5 rounded-xl hover:bg-white/5 transition group">
                    <span className="text-xl">{g.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-bold group-hover:text-white transition truncate">{g.name}</div>
                      <div className="text-[10px] font-bold" style={{ color: g.color }}>{g.currency}</div>
                    </div>
                    <ChevronRight className="h-3.5 w-3.5 text-gray-600 group-hover:text-gray-400 transition" />
                  </Link>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
