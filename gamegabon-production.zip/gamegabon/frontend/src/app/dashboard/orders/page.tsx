'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Search, Filter } from 'lucide-react';
import { useMyOrders } from '@/hooks/index';
import { Card, Badge, Skeleton, EmptyState, Tabs, Button } from '@/components/ui';
import { fmtXAF, fmtDate, ORDER_STATUS_CONFIG, PAYMENT_LABELS } from '@/lib/utils';
import type { Order, Game, Pack } from '@/types';

const STATUS_TABS = [
  { id: 'all', label: 'Toutes' },
  { id: 'delivered', label: '✓ Livrées' },
  { id: 'pending', label: '⏳ En attente' },
  { id: 'processing', label: '⚙️ En cours' },
  { id: 'failed', label: '✗ Échouées' },
];

export default function OrdersPage() {
  const [status, setStatus] = useState('all');
  const [page, setPage] = useState(1);
  const { data, isLoading } = useMyOrders({ status: status === 'all' ? undefined : status, page, limit: 10 });

  const orders: Order[] = data?.data || [];
  const pagination = data?.pagination;

  return (
    <div className="space-y-5 animate-fade-up">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black">Mes commandes</h1>
        <Link href="/games">
          <Button size="sm"><span className="text-sm">+ Nouvelle recharge</span></Button>
        </Link>
      </div>

      <Tabs tabs={STATUS_TABS} active={status} onChange={(id) => { setStatus(id); setPage(1); }} />

      <Card padding={false}>
        {isLoading ? (
          <div className="p-4 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-xl" />)}
          </div>
        ) : orders.length === 0 ? (
          <EmptyState icon="📭" title="Aucune commande" description="Faites votre première recharge gaming !"
            action={<Link href="/games"><Button>Recharger maintenant</Button></Link>} />
        ) : (
          <div className="divide-y divide-gaming-border">
            {orders.map((o: Order) => {
              const cfg = ORDER_STATUS_CONFIG[o.status];
              const game = (o.game || o.gameId) as Game;
              const pack = (o.pack || o.packId) as Pack;
              return (
                <div key={o._id} className="p-4 hover:bg-white/2 transition">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="text-3xl flex-shrink-0">{game?.icon || '🎮'}</div>
                      <div className="min-w-0">
                        <div className="font-bold text-sm">{game?.name || '—'}</div>
                        <div className="text-xs text-gray-500">{pack?.label || '—'} · ID: {o.playerId}</div>
                        <div className="text-xs text-gray-600 mt-0.5">
                          {PAYMENT_LABELS[o.paymentMethod] || o.paymentMethod} · {fmtDate(o.createdAt)}
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="font-black text-sm">{fmtXAF(o.finalAmount)}</div>
                      {o.discountAmount > 0 && (
                        <div className="text-xs text-green-400 line-through decoration-red-400">{fmtXAF(o.originalAmount)}</div>
                      )}
                      <Badge variant={o.status === 'delivered' ? 'success' : o.status === 'failed' ? 'danger' : 'warning'} className="mt-1">
                        {cfg.label}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-gaming-border/50">
                    <span className="text-[10px] text-gray-600 font-mono">#{o.orderNumber}</span>
                    {o.cashbackEarned > 0 && (
                      <span className="text-[10px] text-yellow-500 font-bold">+{fmtXAF(o.cashbackEarned)} cashback</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Pagination */}
      {pagination && pagination.totalPages > 1 && (
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-500">{pagination.total} commandes au total</span>
          <div className="flex gap-2">
            <Button variant="secondary" size="sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Précédent</Button>
            <span className="px-3 py-1.5 text-xs text-gray-400 bg-gaming-card border border-gaming-border rounded-lg">
              {page} / {pagination.totalPages}
            </span>
            <Button variant="secondary" size="sm" disabled={page === pagination.totalPages} onClick={() => setPage(p => p + 1)}>Suivant →</Button>
          </div>
        </div>
      )}
    </div>
  );
}
