'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { User, Phone, Mail, Lock, Copy, CheckCircle } from 'lucide-react';
import { useAuthStore } from '@/store/auth.store';
import { authApi } from '@/lib/api';
import { Button, Input, Card, Badge } from '@/components/ui';
import { fmtXAF, getInitials } from '@/lib/utils';
import toast from 'react-hot-toast';

const profileSchema = z.object({
  name: z.string().min(2, 'Minimum 2 caractères'),
  phone: z.string().min(8, 'Numéro invalide'),
});

const pwdSchema = z.object({
  currentPassword: z.string().min(1, 'Requis'),
  newPassword: z.string().min(8, 'Min. 8 caractères').regex(/[A-Z]/).regex(/[0-9]/),
  confirmPassword: z.string(),
}).refine((d) => d.newPassword === d.confirmPassword, { message: 'Mots de passe différents', path: ['confirmPassword'] });

export default function ProfilePage() {
  const { user, setAuth, accessToken } = useAuthStore();
  const [saving, setSaving] = useState(false);
  const [pwdSaving, setPwdSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: { name: user?.name || '', phone: user?.phone || '' },
  });

  const { register: regPwd, handleSubmit: handlePwd, reset: resetPwd, formState: { errors: pwdErrors } } = useForm({
    resolver: zodResolver(pwdSchema),
  });

  const saveProfile = async (data: { name: string; phone: string }) => {
    setSaving(true);
    try {
      const res = await authApi.updateMe(data);
      setAuth(res.data.data.user, accessToken!);
      toast.success('Profil mis à jour');
    } catch { toast.error('Erreur mise à jour'); }
    finally { setSaving(false); }
  };

  const changePassword = async (data: { currentPassword: string; newPassword: string }) => {
    setPwdSaving(true);
    try {
      await authApi.updateMe(data);
      toast.success('Mot de passe modifié');
      resetPwd();
    } catch { toast.error('Mot de passe actuel incorrect'); }
    finally { setPwdSaving(false); }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(user?.referralCode || '');
    setCopied(true);
    toast.success('Code copié !');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-2xl space-y-6 animate-fade-up">
      <h1 className="text-2xl font-black">Mon profil</h1>

      {/* Avatar card */}
      <Card className="bg-gradient-to-br from-brand-500/10 to-gaming-card">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-xl font-black text-gray-950 shadow-lg shadow-brand-500/30">
            {getInitials(user?.name || 'U')}
          </div>
          <div>
            <div className="text-xl font-black">{user?.name}</div>
            <div className="text-sm text-gray-400">{user?.email}</div>
            <div className="flex gap-2 mt-2">
              <Badge variant={user?.role === 'admin' ? 'purple' : user?.role === 'reseller' ? 'warning' : 'info'}>
                {user?.role === 'admin' ? '🛡️ Admin' : user?.role === 'reseller' ? '⭐ Revendeur' : '👤 Client'}
              </Badge>
              <Badge variant="success">✓ Actif</Badge>
            </div>
          </div>
        </div>
      </Card>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-4">
        {[
          { l: 'Commandes', v: user?.totalOrders || 0, c: 'text-brand-400' },
          { l: 'Total dépensé', v: fmtXAF(user?.totalSpent || 0), c: 'text-yellow-400' },
          { l: 'Cashback', v: fmtXAF(user?.cashback || 0), c: 'text-green-400' },
        ].map(({ l, v, c }) => (
          <Card key={l} className="text-center p-3">
            <div className={`text-base font-black ${c}`}>{v}</div>
            <div className="text-[10px] text-gray-500 mt-0.5">{l}</div>
          </Card>
        ))}
      </div>

      {/* Edit profile */}
      <Card>
        <h2 className="font-black text-base mb-4 flex items-center gap-2"><User className="h-4 w-4 text-brand-400" /> Informations personnelles</h2>
        <form onSubmit={handleSubmit(saveProfile)} className="space-y-4">
          <Input label="Nom complet" leftIcon={<User className="h-4 w-4" />} error={errors.name?.message} {...register('name')} />
          <Input label="Téléphone" leftIcon={<Phone className="h-4 w-4" />} error={errors.phone?.message} {...register('phone')} />
          <div>
            <label className="block text-xs font-bold uppercase tracking-widest text-gray-500 mb-1.5">Email</label>
            <div className="flex items-center gap-2 bg-gaming-card2 border border-gaming-border rounded-xl px-3.5 py-3 opacity-60">
              <Mail className="h-4 w-4 text-gray-500" />
              <span className="text-sm text-gray-400">{user?.email}</span>
            </div>
            <p className="text-xs text-gray-600 mt-1">L&apos;email ne peut pas être modifié</p>
          </div>
          <Button type="submit" size="md" loading={saving}>Enregistrer les modifications</Button>
        </form>
      </Card>

      {/* Referral */}
      <Card className="bg-gradient-to-br from-purple-500/8 to-gaming-card border-purple-500/20">
        <h2 className="font-black text-base mb-3 flex items-center gap-2">👥 Code de parrainage</h2>
        <div className="flex gap-2">
          <div className="flex-1 bg-gaming-card2 border border-gaming-border rounded-xl px-4 py-3 font-black text-lg tracking-widest text-purple-400">
            {user?.referralCode}
          </div>
          <Button variant="outline" size="sm" onClick={copyCode} className="px-4 border-purple-500/40 text-purple-400">
            {copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
        <p className="text-xs text-gray-500 mt-2">Partagez ce code avec vos amis. Vous gagnez 500 FCFA par ami parrainé qui effectue une recharge.</p>
      </Card>

      {/* Change password */}
      <Card>
        <h2 className="font-black text-base mb-4 flex items-center gap-2"><Lock className="h-4 w-4 text-brand-400" /> Changer le mot de passe</h2>
        <form onSubmit={handlePwd(changePassword)} className="space-y-4">
          <Input label="Mot de passe actuel" type="password" placeholder="••••••••" error={pwdErrors.currentPassword?.message} {...regPwd('currentPassword')} />
          <Input label="Nouveau mot de passe" type="password" placeholder="Min. 8 car. avec majuscule et chiffre" error={pwdErrors.newPassword?.message} {...regPwd('newPassword')} />
          <Input label="Confirmer le nouveau mot de passe" type="password" placeholder="••••••••" error={pwdErrors.confirmPassword?.message} {...regPwd('confirmPassword')} />
          <Button type="submit" variant="secondary" loading={pwdSaving}>Modifier le mot de passe</Button>
        </form>
      </Card>
    </div>
  );
}
