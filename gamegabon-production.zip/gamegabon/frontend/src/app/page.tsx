import Link from 'next/link';
import type { Metadata } from 'next';
import { PublicHeader } from '@/components/layout/index';
import { Shield, Zap, Clock, Users, ChevronRight, Star } from 'lucide-react';

export const metadata: Metadata = {
  title: 'GameTopUp Gabon — Rechargez vos jeux en 30 secondes',
};

const GAMES = [
  { icon: '🎮', name: 'Roblox',      currency: 'Robux',     color: '#FF5252', from: '2 500 FCFA' },
  { icon: '⚡', name: 'Fortnite',    currency: 'V-Bucks',   color: '#00D4FF', from: '4 900 FCFA' },
  { icon: '💎', name: 'Free Fire',   currency: 'Diamants',  color: '#FF4500', from: '900 FCFA'   },
  { icon: '🎯', name: 'PUBG Mobile', currency: 'UC',        color: '#F5A623', from: '600 FCFA'   },
  { icon: '💀', name: 'Call of Duty',currency: 'CP',        color: '#FF6B00', from: '1 200 FCFA' },
  { icon: '⚽', name: 'EA FC 25',    currency: 'FC Points', color: '#00E676', from: '2 900 FCFA' },
  { icon: '🏆', name: 'LoL',         currency: 'RP',        color: '#C89B3C', from: '4 900 FCFA' },
  { icon: '🔫', name: 'Valorant',    currency: 'VP',        color: '#FF4655', from: '2 900 FCFA' },
];

const PAYMENTS = [
  { icon: '📱', name: 'Airtel Money', flag: '🇬🇦' },
  { icon: '📲', name: 'Moov Money',   flag: '🇬🇦' },
  { icon: '💳', name: 'Visa / MC',    flag: '🌍' },
  { icon: '🅿️', name: 'PayPal',       flag: '🌍' },
  { icon: '₿',  name: 'USDT Crypto', flag: '🔐' },
];

const FEATURES = [
  { icon: Zap,    title: 'Livraison instantanée',   desc: 'Vos crédits sont livrés automatiquement en quelques secondes après confirmation du paiement.' },
  { icon: Shield, title: 'Paiement 100% sécurisé',  desc: 'Transactions chiffrées. Intégration officielle PVit pour les paiements Mobile Money au Gabon.' },
  { icon: Clock,  title: 'Disponible 24h/24',        desc: 'Plateforme disponible à toute heure. Support client réactif en cas de problème.' },
  { icon: Users,  title: 'Programme affilié',        desc: 'Gagnez 500 FCFA de cashback par ami parrainé. Cashback 2% sur chaque recharge.' },
];

export default function HomePage() {
  return (
    <>
      <PublicHeader />
      <main className="pt-16">
        {/* ── HERO ─────────────────────────────────────────── */}
        <section className="relative overflow-hidden min-h-[90vh] flex items-center">
          {/* Background glow */}
          <div className="absolute inset-0 bg-hero-glow pointer-events-none" />
          <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-brand-500/8 blur-3xl pointer-events-none" />
          <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-cyan-500/6 blur-3xl pointer-events-none" />

          <div className="max-w-7xl mx-auto px-4 py-24 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-brand-500/30 bg-brand-500/10 text-brand-400 text-xs font-bold mb-8 animate-fade-in">
                <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" />
                🇬🇦 Plateforme officielle de recharge gaming au Gabon
              </div>

              <h1 className="text-4xl sm:text-5xl md:text-6xl font-black leading-tight mb-6 animate-fade-up">
                Rechargez vos jeux<br />
                en <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-cyan-300">30 secondes</span>
              </h1>

              <p className="text-lg text-gray-400 mb-10 max-w-xl mx-auto animate-fade-up" style={{ animationDelay: '0.1s' }}>
                Airtel Money · Moov Money · Carte bancaire · Crypto.<br />
                Livraison instantanée, paiement sécurisé, support 24h/24.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up" style={{ animationDelay: '0.2s' }}>
                <Link href="/games" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-gradient-to-r from-brand-500 to-cyan-400 text-gray-950 font-black rounded-2xl text-base hover:opacity-90 transition shadow-lg shadow-brand-500/25">
                  🎮 Recharger maintenant <ChevronRight className="h-4 w-4" />
                </Link>
                <Link href="/auth/register" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 border border-gaming-border text-gray-300 font-bold rounded-2xl text-base hover:border-brand-500/40 hover:text-white transition">
                  Créer un compte gratuit
                </Link>
              </div>

              {/* Trust indicators */}
              <div className="flex flex-wrap items-center justify-center gap-6 mt-12 text-sm text-gray-500 animate-fade-up" style={{ animationDelay: '0.3s' }}>
                {[['50K+', 'Recharges livrées'], ['12K+', 'Clients actifs'], ['9+', 'Jeux disponibles'], ['< 30s', 'Délai livraison']].map(([v, l]) => (
                  <div key={l} className="text-center">
                    <div className="text-lg font-black text-white">{v}</div>
                    <div className="text-xs">{l}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ── GAMES ────────────────────────────────────────── */}
        <section className="py-20 border-t border-gaming-border">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-black mb-3">Jeux disponibles</h2>
              <p className="text-gray-400">Rechargez vos jeux favoris en quelques clics</p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {GAMES.map((g) => (
                <Link
                  key={g.name}
                  href={`/games/${g.name.toLowerCase().replace(/\s+/g, '-')}`}
                  className="group bg-gaming-card border border-gaming-border rounded-2xl p-5 text-center hover:border-brand-500/40 transition-all hover:-translate-y-1 hover:shadow-lg"
                  style={{ '--game-color': g.color } as React.CSSProperties}
                >
                  <div className="text-4xl mb-3">{g.icon}</div>
                  <div className="font-bold text-sm mb-1">{g.name}</div>
                  <div className="text-xs font-bold mb-2" style={{ color: g.color }}>{g.currency}</div>
                  <div className="text-xs text-gray-500">dès {g.from}</div>
                </Link>
              ))}
            </div>
            <div className="text-center mt-8">
              <Link href="/games" className="inline-flex items-center gap-2 text-sm text-brand-400 font-bold hover:text-brand-300 transition">
                Voir tous les jeux <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* ── PAYMENTS ─────────────────────────────────────── */}
        <section className="py-16 bg-gaming-card/40 border-y border-gaming-border">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-8">Moyens de paiement acceptés</p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              {PAYMENTS.map((p) => (
                <div key={p.name} className="flex items-center gap-2.5 bg-gaming-card border border-gaming-border rounded-xl px-4 py-3">
                  <span className="text-xl">{p.icon}</span>
                  <div>
                    <div className="text-sm font-bold">{p.name}</div>
                    <div className="text-xs text-gray-500">{p.flag}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── FEATURES ─────────────────────────────────────── */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-black mb-3">Pourquoi choisir GameTopUp Gabon ?</h2>
              <p className="text-gray-400">La plateforme de confiance pour les gamers gabonais</p>
            </div>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
              {FEATURES.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="bg-gaming-card border border-gaming-border rounded-2xl p-6">
                  <div className="w-11 h-11 rounded-xl bg-brand-500/10 flex items-center justify-center text-brand-400 mb-4">
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="font-bold text-sm mb-2">{title}</h3>
                  <p className="text-xs text-gray-500 leading-relaxed">{desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── TESTIMONIALS ─────────────────────────────────── */}
        <section className="py-16 bg-gaming-card/30 border-t border-gaming-border">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-black text-center mb-10">Ce que disent nos clients</h2>
            <div className="grid sm:grid-cols-3 gap-5">
              {[
                { name: 'Jean-Pierre M.', role: 'Gamer Libreville', text: 'Super rapide ! J\'ai rechargé mes Robux en moins de 30 secondes avec Airtel Money. Je recommande !', stars: 5 },
                { name: 'Marie N.', role: 'Revendeuse Port-Gentil', text: 'Interface claire et paiements fiables. Je fais mes recharges hebdo sans problème. Le cashback est un plus !', stars: 5 },
                { name: 'Paul O.', role: 'Étudiant Franceville', text: 'Enfin une plateforme qui accepte Moov Money au Gabon. Prix compétitifs et livraison instantanée.', stars: 5 },
              ].map((t) => (
                <div key={t.name} className="bg-gaming-card border border-gaming-border rounded-2xl p-5">
                  <div className="flex text-yellow-400 mb-3">
                    {Array.from({ length: t.stars }).map((_, i) => <Star key={i} className="h-3.5 w-3.5 fill-current" />)}
                  </div>
                  <p className="text-sm text-gray-300 mb-4 leading-relaxed">&ldquo;{t.text}&rdquo;</p>
                  <div className="text-xs font-bold">{t.name}</div>
                  <div className="text-xs text-gray-500">{t.role}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA ──────────────────────────────────────────── */}
        <section className="py-24">
          <div className="max-w-2xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-black mb-4">Prêt à recharger ?</h2>
            <p className="text-gray-400 mb-8">Créez votre compte gratuitement et rechargez en 30 secondes.</p>
            <Link href="/auth/register" className="inline-flex items-center justify-center gap-2 px-10 py-4 bg-gradient-to-r from-brand-500 to-cyan-400 text-gray-950 font-black rounded-2xl text-base hover:opacity-90 transition shadow-lg shadow-brand-500/25">
              Commencer maintenant — C&apos;est gratuit
            </Link>
          </div>
        </section>

        {/* ── FOOTER ───────────────────────────────────────── */}
        <footer className="border-t border-gaming-border py-10">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-gray-500">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-brand-500 to-cyan-400 flex items-center justify-center text-xs font-black text-gray-950">G</div>
              <span className="font-bold text-gray-400">GameTopUp Gabon</span>
            </div>
            <div className="flex gap-6">
              <Link href="/legal" className="hover:text-gray-300 transition">Mentions légales</Link>
              <Link href="/privacy" className="hover:text-gray-300 transition">Confidentialité</Link>
              <Link href="/support" className="hover:text-gray-300 transition">Support</Link>
            </div>
            <div>© {new Date().getFullYear()} GameTopUp Gabon. Tous droits réservés.</div>
          </div>
        </footer>
      </main>
    </>
  );
}
