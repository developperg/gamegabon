import type { Metadata } from 'next';
import { PublicHeader } from '@/components/layout/index';
import GamesGrid from './GamesGrid';

export const metadata: Metadata = { title: 'Jeux disponibles — GameTopUp Gabon' };

export default function GamesPage() {
  return (
    <>
      <PublicHeader />
      <main className="pt-16 min-h-screen bg-gaming-bg">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="mb-8">
            <h1 className="text-3xl font-black mb-2">🎮 Choisissez votre jeu</h1>
            <p className="text-gray-400">Sélectionnez un jeu pour voir les packs disponibles et recharger instantanément.</p>
          </div>
          <GamesGrid />
        </div>
      </main>
    </>
  );
}
