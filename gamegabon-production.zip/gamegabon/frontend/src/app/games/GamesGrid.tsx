'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Search } from 'lucide-react';
import { useGames } from '@/hooks/index';
import { Input, Skeleton } from '@/components/ui';
import type { Game } from '@/types';

export default function GamesGrid() {
  const { data: games, isLoading } = useGames();
  const [search, setSearch] = useState('');

  const filtered = (games || []).filter(
    (g: Game) =>
      g.name.toLowerCase().includes(search.toLowerCase()) ||
      g.currency.toLowerCase().includes(search.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />)}
      </div>
    );
  }

  return (
    <>
      <div className="mb-6 max-w-sm">
        <Input placeholder="Rechercher un jeu..." leftIcon={<Search className="h-4 w-4" />}
          value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>
      {filtered.length === 0 ? (
        <div className="text-center py-20 text-gray-500">
          <div className="text-4xl mb-3">🔍</div>
          <p>Aucun jeu trouvé pour &ldquo;{search}&rdquo;</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {filtered.map((g: Game) => (
            <Link
              key={g._id}
              href={`/games/${g.slug}`}
              className="group bg-gaming-card border border-gaming-border rounded-2xl p-5 text-center hover:border-brand-500/40 transition-all hover:-translate-y-1 hover:shadow-xl hover:shadow-brand-500/10"
            >
              <div className="text-4xl mb-3">{g.icon}</div>
              <div className="font-bold text-sm mb-1 group-hover:text-white transition">{g.name}</div>
              <div className="text-xs font-bold mb-3" style={{ color: g.color }}>{g.currency}</div>
              {g.featured && (
                <span className="inline-block bg-brand-500/10 border border-brand-500/30 text-brand-400 text-[10px] font-bold px-2 py-0.5 rounded-full">
                  ⭐ Populaire
                </span>
              )}
            </Link>
          ))}
        </div>
      )}
    </>
  );
}
