'use client';

import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Zap, Shield, Clock } from 'lucide-react';
import { useGameWithPacks } from '@/hooks/index';
import { useCheckoutStore } from '@/store/checkout.store';
import { useAuthStore } from '@/store/auth.store';
import { Button, Card, Skeleton, Badge } from '@/components/ui';
import { fmtXAF, fmtCurrency } from '@/lib/utils';
import { PublicHeader } from '@/components/layout/index';
import type { Pack } from '@/types';

export default function GameDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const { data, isLoading, isError } = useGameWithPacks(slug);
  const { setGame, setPack, setStep } = useCheckoutStore();
  const { isAuthenticated } = useAuthStore();

  const handleSelectPack = (pack: Pack) => {
    if (!data?.game) return;
    setGame(data.game);
    setPack(pack);
    setStep(2);
    if (!isAuthenticated) {
      router.push('/auth/login');
      return;
    }
    router.push('/checkout');
  };

  if (isLoading) {
    return (
      <>
        <PublicHeader />
        <div className="pt-16 max-w-4xl mx-auto px-4 py-10 space-y-4">
          <Skeleton className="h-10 w-64 rounded-xl" />
          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}
          </div>
        </div>
      </>
    );
  }

  if (isError || !data) {
    return (
      <>
        <PublicHeader />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="text-5xl mb-4">😕</div>
            <p className="text-gray-400 mb-4">Jeu introuvable</p>
            <Link href="/games"><Button>Voir tous les jeux</Button></Link>
          </div>
        </div>
      </>
    );
  }

  const { game, packs } = data as { game: import('@/types').Game; packs: Pack[] };

  return (
    <>
      <PublicHeader />
      <main className="pt-16 min-h-screen bg-gaming-bg">
        <div className="max-w-4xl mx-auto px-4 py-10">
          {/* Back */}
          <Link href="/games" className="inline-flex items-center gap-1.5 text-sm text-gray-400 hover:text-white mb-6 transition">
            <ArrowLeft className="h-4 w-4" /> Retour aux jeux
          </Link>

          {/* Game header */}
          <div className="flex items-center gap-4 mb-8 p-5 rounded-2xl border border-gaming-border"
            style={{ background: `linear-gradient(135deg, ${game.color}15, #0d1420)` }}>
            <div className="text-5xl">{game.icon}</div>
            <div>
              <h1 className="text-2xl font-black">{game.name}</h1>
              <span className="inline-block mt-1 px-3 py-1 rounded-full text-xs font-bold border"
                style={{ color: game.color, background: `${game.color}18`, borderColor: `${game.color}40` }}>
                {game.currency}
              </span>
              {game.description && <p className="text-sm text-gray-400 mt-1">{game.description}</p>}
            </div>
          </div>

          {/* Trust pills */}
          <div className="flex flex-wrap gap-3 mb-8">
            {[
              { icon: Zap, label: 'Livraison instantanée', color: 'text-yellow-400' },
              { icon: Shield, label: 'Paiement sécurisé', color: 'text-green-400' },
              { icon: Clock, label: 'Disponible 24h/24', color: 'text-brand-400' },
            ].map(({ icon: Icon, label, color }) => (
              <div key={label} className="flex items-center gap-2 bg-gaming-card border border-gaming-border rounded-full px-3 py-1.5 text-xs font-medium">
                <Icon className={`h-3.5 w-3.5 ${color}`} />
                <span className="text-gray-300">{label}</span>
              </div>
            ))}
          </div>

          {/* Packs grid */}
          <h2 className="text-lg font-black mb-4">Choisissez votre pack</h2>
          {packs.length === 0 ? (
            <Card><p className="text-center text-gray-500 py-8">Aucun pack disponible actuellement.</p></Card>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4">
              {packs.map((pack: Pack) => (
                <div
                  key={pack._id}
                  className="bg-gaming-card border border-gaming-border rounded-2xl p-5 hover:border-brand-500/40 transition-all hover:-translate-y-0.5 hover:shadow-lg group cursor-pointer"
                  onClick={() => handleSelectPack(pack)}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="font-black text-base">{pack.label}</div>
                      {pack.bonusAmount > 0 && (
                        <div className="text-xs font-bold text-green-400 mt-0.5">+{pack.bonusAmount} Bonus !</div>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="font-black text-lg" style={{ color: game.color }}>{fmtXAF(pack.priceXAF)}</div>
                      <div className="text-xs text-gray-500">~{fmtCurrency(pack.priceXAF, 'USD')}</div>
                    </div>
                  </div>
                  {pack.popular && <Badge variant="info" className="mb-3 text-[10px]">⭐ Populaire</Badge>}
                  <Button fullWidth size="sm" className="group-hover:shadow-lg transition-all">
                    Acheter maintenant
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* How it works */}
          <div className="mt-10 bg-gaming-card border border-gaming-border rounded-2xl p-6">
            <h3 className="font-black mb-4 text-sm">💡 Comment ça marche ?</h3>
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                ['1', 'Choisissez un pack', 'Sélectionnez le montant qui vous convient'],
                ['2', 'Entrez votre ID joueur', 'Trouvez-le dans les paramètres du jeu'],
                ['3', 'Payez & recevez', 'Airtel Money, Moov Money ou carte bancaire'],
              ].map(([n, t, d]) => (
                <div key={n} className="flex gap-3">
                  <div className="w-7 h-7 rounded-full bg-brand-500/20 text-brand-400 flex items-center justify-center text-xs font-black flex-shrink-0">{n}</div>
                  <div>
                    <div className="text-xs font-bold">{t}</div>
                    <div className="text-xs text-gray-500 mt-0.5">{d}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </>
  );
}
