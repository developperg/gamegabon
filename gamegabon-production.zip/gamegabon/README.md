# 🎮 GameTopUp Gabon — Documentation

Plateforme de recharge gaming SaaS pour le Gabon. Stack complète production-ready.

---

## 🗂️ Architecture

```
gamegabon/
├── backend/          # Node.js + Express + TypeScript + MongoDB
│   ├── src/
│   │   ├── controllers/    # Logique HTTP
│   │   ├── services/       # Logique métier
│   │   ├── models/         # Schémas Mongoose
│   │   ├── routes/         # Définition des routes
│   │   ├── middleware/      # Auth, validation, erreurs
│   │   ├── webhooks/       # Webhook PVit
│   │   ├── validations/    # Schémas Zod
│   │   ├── utils/          # JWT, logger, AppError
│   │   └── config/         # DB, variables
│   └── Dockerfile
│
├── frontend/         # Next.js 14 + TypeScript + TailwindCSS
│   ├── src/
│   │   ├── app/            # Pages (App Router)
│   │   │   ├── page.tsx          # Landing page
│   │   │   ├── games/            # Catalogue jeux
│   │   │   ├── checkout/         # Tunnel d'achat
│   │   │   ├── dashboard/        # Espace client
│   │   │   ├── admin/            # Panel admin (protégé)
│   │   │   └── auth/             # Login / Register
│   │   ├── components/     # UI, Layout, Auth
│   │   ├── hooks/          # React Query hooks
│   │   ├── lib/            # API client, utils
│   │   ├── store/          # Zustand (auth, checkout)
│   │   └── types/          # TypeScript types
│   └── Dockerfile
│
└── docker-compose.yml
```

---

## 🚀 Installation locale

### Prérequis
- Node.js 20+
- MongoDB 7.0 (local ou Atlas)
- npm ou yarn

### 1. Backend

```bash
cd backend
cp .env.example .env
# Editez .env avec vos valeurs
npm install
npm run dev        # http://localhost:5000
```

### 2. Frontend

```bash
cd frontend
cp .env.local.example .env.local
# NEXT_PUBLIC_API_URL=http://localhost:5000/api
npm install
npm run dev        # http://localhost:3000
```

---

## 🐳 Docker (production)

```bash
# Copier et éditer les variables d'environnement
cp backend/.env.example backend/.env

# Lancer toute la stack
docker-compose up --build -d

# Logs
docker-compose logs -f backend
docker-compose logs -f frontend
```

---

## 🔐 Comptes par défaut

| Rôle | Email | Mot de passe |
|------|-------|-------------|
| Admin | admin@gamegabon.com | Admin@Gabon2026! |

> L'admin est créé automatiquement au démarrage du backend.  
> Modifiez `ADMIN_EMAIL` et `ADMIN_PASSWORD` dans `.env`.

---

## 🌐 API Endpoints

### Auth
```
POST /api/auth/register
POST /api/auth/login
POST /api/auth/refresh
POST /api/auth/logout
GET  /api/auth/me
POST /api/auth/forgot-password
POST /api/auth/reset-password
```

### Jeux (public)
```
GET /api/games
GET /api/games/:slug
```

### Commandes (authentifié)
```
POST /api/orders
GET  /api/orders
GET  /api/orders/:id
POST /api/promos/validate
```

### Admin (admin only)
```
GET    /api/admin/analytics
GET    /api/admin/orders
PATCH  /api/admin/orders/:id/status
GET    /api/admin/games
POST   /api/admin/games
PATCH  /api/admin/games/:id
DELETE /api/admin/games/:id
POST   /api/admin/games/:gameId/packs
PATCH  /api/admin/games/:gameId/packs/:packId
DELETE /api/admin/games/:gameId/packs/:packId
GET    /api/admin/promos
POST   /api/admin/promos
PATCH  /api/admin/promos/:id
DELETE /api/admin/promos/:id
GET    /api/admin/users
PATCH  /api/admin/users/:id
DELETE /api/admin/users/:id
```

### Webhooks
```
POST /api/webhooks/pvit    # Callback PVit (signature vérifiée)
```

---

## 💳 Intégration PVit (Mobile Money Gabon)

Configurez dans `backend/.env` :

```env
PVIT_BASE_URL=https://api.pvit.com/v1
PVIT_API_KEY=votre_api_key
PVIT_SECRET_KEY=votre_secret_key
PVIT_MERCHANT_ID=votre_merchant_id
PVIT_WEBHOOK_SECRET=votre_webhook_secret
PVIT_CALLBACK_URL=https://votredomaine.com/api/webhooks/pvit
```

En développement, les paiements sont **simulés automatiquement**.  
En production (`NODE_ENV=production`), les appels sont réels vers l'API PVit.

---

## ☁️ Déploiement

### Render (recommandé)
1. Backend : Web Service, `npm run build && npm start`
2. Frontend : Static Site ou Web Service, `npm run build && npm start`
3. DB : MongoDB Atlas (free tier disponible)

### Variables d'environnement production (backend)
```env
NODE_ENV=production
MONGODB_URI=mongodb+srv://...
JWT_SECRET=<64+ chars aléatoires>
JWT_REFRESH_SECRET=<64+ chars aléatoires>
FRONTEND_URL=https://votre-frontend.com
PVIT_API_KEY=...
```

### Variables d'environnement production (frontend)
```env
NEXT_PUBLIC_API_URL=https://votre-api.com/api
```

---

## 🔒 Sécurité

- ✅ JWT Access Token (15min) + Refresh Token (7j) httpOnly cookie
- ✅ Bcrypt password hashing (12 rounds)
- ✅ Helmet security headers
- ✅ Rate limiting (auth: 10/15min, global: 100/15min)
- ✅ CORS strict
- ✅ Validation Zod backend + frontend
- ✅ Vérification signature webhook PVit (HMAC SHA-256)
- ✅ Logs sécurité séparés
- ✅ Protection brute force login
- ✅ Aucune logique métier côté frontend

---

## 📊 Stack technique

| Composant | Technologie |
|-----------|------------|
| Frontend | Next.js 14, TypeScript, TailwindCSS |
| State | Zustand, React Query |
| Forms | React Hook Form + Zod |
| Charts | Recharts |
| Backend | Node.js, Express, TypeScript |
| Base de données | MongoDB + Mongoose |
| Auth | JWT + bcrypt |
| Paiement | PVit (Airtel/Moov Money Gabon) |
| Logs | Winston + Morgan |
| Docker | Docker + docker-compose |
